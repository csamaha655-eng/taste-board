# Reading the numbers, and when to stop

## Measure from the first build

- **Log, from the first build:** every onboarding screen, the paywall views, purchases started, purchases completed, trials started and cancelled, and the first real success. Use TelemetryDeck with fixed event names and never any user text.
- **Read them with their source, dates and denominator,** and never mix counts from different windows into one funnel. Example: Toll's App Store numbers covered 5-9 October, while its in-app analytics only started on 8 October.
- **Remove App Review and your own devices before reading a small funnel.** Reviewers show up before the release time, often with odd device names (Toll's: iPhone99,7) and test purchases they cancel; the owner's phone shows up as his model and region. In Toll 1.4's first days, 8 of 12 "users" were App Review, a tester or the owner, which turned "4 started a purchase, 1 finished" into 3 real people: 2 tapped buy, 1 started the free week.
- **A free trial delays the money.** With a free week, nobody pays before day 8, so "0 paying after 5 days" says nothing yet. Until the first trials end, judge trials started per paywall view. If that is also near zero, the leak is the onboarding or the paywall, not the traffic.
- **Follow each trial, not only the count.** While trials are few, trace each one through the events already logged: the steps to the first real success (in Toll: apps chosen, a rule, the first proof), the days it came back, then the renewal or the cancellation. Where each one stopped says more than the trial rate. With fewer than about 10 trials, one honest answer from a person beats any chart.

## Find the leak before changing anything

Fix the biggest leak first, in this order:
1. **The store page** (tap-through and conversion rates). A low tap-through rate (Toll's was 1.9%) means the icon, the name and the first frame are unclear: fix the store page before spending on ads.
2. **The onboarding** (each screen's drop).
3. **The paywall:** views, purchases started and purchases completed. About half of those who start a purchase should finish. If many start and few finish, look for a bug or a price mismatch. If nobody starts, redesign the paywall to sell the outcome.
4. **The price.**
5. **Traffic.**

Don't judge the price on fewer than about 100 paywall views, or a launch before 2 to 4 weeks.

**A/B tests need volume.** Telling a 10% trial rate from 15% takes about 700 paywall views per version (5% significance, 80% power). Apple's store page test (Product Page Optimization) needs about 8,000 impressions per version to see a 20% lift. Below that, change one thing at a time and compare the weeks before and after, with the same kind of traffic: ad installs and organic search visitors behave differently, so a week of each mixes two causes (Toll's share reaching the price went from 28% to 66% in the same week its traffic went from paid to organic). Make the paywall read RevenueCat's current offering, not a fixed one, so a price test can run later without a new app version.

**Write the stop rule before launch.** Name the success bar and the date (for example: "by 4 weeks after release, at least 2 active trials or $100, from organic posts only"). If the bar is met, keep going; if not, stop and move to the next idea. Don't keep polishing a product the market has answered.


## A worked example (Toll, October 2026)

- **App Store, 5-9 October:** 19,222 impressions, 371 product page views, 57 downloads.
- **In-app, 8-10 October:** 25 people started the onboarding (15 screens), 7 reached the price, 1 started a trial and cancelled it the same day.
- **The leak was the onboarding,** not the price. Seven paywall views can't judge a price.
