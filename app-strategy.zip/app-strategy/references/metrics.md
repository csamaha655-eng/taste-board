# Reading the numbers, and when to stop

## Measure from the first build

- **Log, from the first build:** every onboarding screen, the paywall views, purchases started, purchases completed, trials started and cancelled, and the first real success. Use TelemetryDeck with fixed event names and never any user text.
- **Read them with their source, dates and denominator,** and never mix counts from different windows into one funnel. Example: Toll's App Store numbers covered 5-9 October, while its in-app analytics only started on 8 October.

## Find the leak before changing anything

Fix the biggest leak first, in this order:
1. **The store page** (tap-through and conversion rates). A low tap-through rate (Toll's was 1.9%) means the icon, the name and the first frame are unclear: fix the store page before spending on ads.
2. **The onboarding** (each screen's drop).
3. **The paywall:** views, purchases started and purchases completed. About half of those who start a purchase should finish. If many start and few finish, look for a bug or a price mismatch. If nobody starts, redesign the paywall to sell the outcome.
4. **The price.**
5. **Traffic.**

Don't judge the price on fewer than about 100 paywall views, or a launch before 2 to 4 weeks.

**Write the stop rule before launch.** Name the success bar and the date (for example: "by 4 weeks after release, at least 2 active trials or $100, from organic posts only"). If the bar is met, keep going; if not, stop and move to the next idea. Don't keep polishing a product the market has answered.


## A worked example (Toll, October 2026)

- **App Store, 5-9 October:** 19,222 impressions, 371 product page views, 57 downloads.
- **In-app, 8-10 October:** 25 people started the onboarding (15 screens), 7 reached the price, 1 started a trial and cancelled it the same day.
- **The leak was the onboarding,** not the price. Seven paywall views can't judge a price.
