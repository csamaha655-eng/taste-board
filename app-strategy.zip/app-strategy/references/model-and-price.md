# Business model and prices

## The model: a paywall from day one

**The evidence (verified 2026-10-11):**
- **RevenueCat, State of Subscription Apps** (revenuecat.com/blog/growth/hard-paywall-vs-freemium):
  - median download-to-paid conversion is 10.7% for hard paywalls against 2.1% for freemium;
  - even weak hard-paywall apps (4.2%) beat the freemium median.
- **RevenueCat's own guidance:**
  - stay with a hard paywall if you're bootstrapped, need cash flow, or solve an acute, immediate problem;
  - consider freemium with strong product-market fit, runway to absorb a dip, network effects or user-generated content.

  RevenueCat notes freemium tests that cut subscriber conversion by more than half.
- **Refunds and retention (RevenueCat 2026):** the paywall type moves neither: refunds 2.5% (hard) against 2.9% (freemium), and 27% against 28% of yearly subscribers still paying after a year. A hard paywall earns more without losing people later.
- **The free trial (verified 2026-10-19):**
  - RevenueCat 2026: 37.4% of 5- to 9-day trials become paid against 25.5% of trials of 4 days or less; 55.4% of 3-day trials are cancelled on their first day against 39.8% of 7-day ones.
  - Adapty 2026: people who pay without a trial refund a little less (2.5% of revenue against 3.1%, the one region it publishes), but trial users renew 8-60% better at the first renewal. After a year a Health & Fitness trial user is worth 63.6% more than a direct buyer; in Productivity, 13.7% less.
  - So: a 7-day trial on the yearly plan, by the app's primary category. In a Productivity app, a yearly plan without a trial is worth an A/B test once there is the volume for one (`metrics.md`).
- **Reddit, on the Toll launch:** three people said a hard paywall drives them away from a habit app. That is what people who aren't paying prefer, not data on what earns. It argues for a better demo before the paywall, not for a free app.

**The decision. The owner builds apps to make money, so every app earns from day one:**
- **Default, almost always: a hard paywall with a 7-day free trial on the yearly plan,** right after an onboarding whose interactive demo lets people feel the core result. The data supports it, and so does his situation (solo, bootstrapped, needs cash flow).
- **Never a free app,** never "free until it has users", never ads as the only income, and never a free tier because commenters asked for one.
- **A limited free tier only when it earns more:** the product has network effects or user-generated content (free users are part of what paying users buy), or the owner asks for one. It stays small and leads to Pro; the core result stays paid.
- **When strangers object to the paywall,** improve what comes before it: a clearer first screen, a better demo, the first result inside onboarding. Keep the paywall.
- **Never switch the model or cut the price on comments alone.** Change them only on the app's own numbers after about 100 paywall views: conversion, trial to paid, refunds, retention and net revenue. The question is always which option makes more money.

## Prices for an app with no ratings yet

- **Price from the market, never from a generic ladder.** A round $39.99 / $9.99 / $119.99 ladder looked machine-made to strangers, and $39.99 a year felt steep for an app with no ratings.
- **Price a notch below the category leaders while the app has no ratings,** on a ladder with a reason:
  - monthly x 12 is about 2 to 2.5 times the yearly price;
  - lifetime is about 2.5 times the yearly price.

  Toll's ladder, for example: $29.99 a year with the 7-day trial, $5.99 a month, $79.99 lifetime.
- **Price endings are a taste call, not evidence.** App Store prices are fixed points: in the US, whole dollars and the .49, .90, .95 and .99 endings, so a price like $36.27 doesn't exist. Nothing shows that a "less round" $36.99 sells more subscriptions than $39.99. Retail studies favor prices ending in 9, but Substack's 2023 test of $9.99 against $10 went the other way. It is never a reason to change a live price.
- **The offer is the yearly plan's free week.** Yearly is preselected, with its trial and a "Save X%" chip computed from the real prices. Lifetime stays the visible pay-once option at about 2.5 times the yearly price. Lead with lifetime, which has no trial, only once the app has ratings and its own numbers show lifetime earns more per paywall view. Fake offers (countdowns, strike-through prices, exit offers) stay banned (`taste`, `app-launch.md`).
- **Set euro storefronts by hand** to clean prices (€29.99). Automatic conversion turned $39.99 into €44.99 in France.
- **An approved subscription's price can only change from a future date:** use the earliest date App Store Connect allows for each storefront. Make sure the app version, store text and website that quote the new price go live no earlier than the price does. Check what existing subscribers keep.
- **Enroll in the App Store Small Business Program (15%)** before the first sale.

