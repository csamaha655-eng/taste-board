# Weighing outside feedback

Comments, App Store reviews, testers' notes and rejections are evidence, but not all of it is good. Some is spot on, some is taste, some is wrong, and some is people trying to sell something or provoke. Read all of it; keep only what holds, and only what serves the owner's goal: apps that look premium and make money.

## Keep a comment's concept when

- it is **specific** (it names a screen, a number or a behavior);
- **and** at least one of these is true:
  - the owner's own data agrees;
  - several people say it independently (replies agreeing with one comment count once);
  - it matches a known good practice or a primary source (Apple's guidelines, RevenueCat's reports, a platform's documentation).
- **and** it is still true of the version people get now. A post keeps collecting comments for days: compare each comment's time with the release time of the version that changed that part, then read the new version's own numbers before changing it again.

Then write the concept, never the quote, into the right place:
- design and building → `taste` (`anti-slop.md`, `app-launch.md`, `real-users.md`, `ios.md`, `web.md`);
- ideas, the paywall model, prices, numbers → this skill (`evidence.md` and the matching file);
- store words, ads, posts → `app-marketing`.

## Count it but don't act on it

- **Hostile one-liners** ("slop", "trash"): they only count toward a theme. Five of them about the look mean the look is a problem; one means nothing.
- **Attacks on the concept** ("nobody needs this", "build something else"): market research for `idea.md` and for the owner's own decision. Never a design change.

## Ignore

- **"Make it free" or "it should be cheaper", with no numbers behind it.** People who aren't paying always prefer free. The owner builds to earn: only the app's own conversion, trial-to-paid, refund and revenue numbers move the model or a price (`model-and-price.md`). A paywall complaint can still point at a weak demo or an unclear first screen; fix those.
- **Advice that breaks the owner's laws or the evidence:** gradients, dark glow, keyword stuffing, fake reviews, "spend $300 a day" on a funnel that doesn't convert. Ignore it however many people say it.
- **Self-promotion** (a tool, an agency, a partnership). Take any useful idea in it, ignore the pitch, and never accept an offer to publish someone else's app on the owner's account.
- **Claims with numbers that can't be checked.** Search for a primary source first. If none exists, label it "one person's claim" or leave it out.
- **Jokes, sarcasm and threads about something else.**

## Before adding anything

1. **Is it true?** Check the claim against data or a source.
2. **Is it general?** It must apply to the next app, not only this one.
3. **Does it make the skill better, not just bigger?** Prefer sharpening an existing rule to adding a new one, and never let a new rule contradict an old one without fixing the old one.
4. **Then commit, push and run `package.sh`,** and tell the owner in one line what the skill learned and what was ignored, and why.
