# Evidence: what the Toll launch taught about ideas, models and prices

Paraphrased comments from the October 2026 r/AppBusiness and r/AppStoreOptimization threads (about 85 replies, then 16 on the 18 October update post), plus one investor's advice (2026-10-16), each with the rule it gives. Weighed by `feedback.md`. The design lessons are in the `taste` skill (`references/real-users.md`); the marketing ones are in `app-marketing`.

## 1. The idea and the market (`idea.md`)

| What people said, in short | The rule |
|---|---|
| Many said a thousand apps already do this, that new ones appear daily, and asked why this one is better. | Before building, count the competitors and name the one difference. If it can't be said in one line, don't build yet. |
| The top-voted comment asked why so many people build habit apps, and whether it's the first idea any AI suggests. | Treat the ideas an AI suggests first (habit trackers, to-do lists, journals, calorie counters, blockers) as crowded by default. Building one needs a twist strangers can see at a glance. |
| Several said these apps are easy to build (no backend), so everyone builds them. | Easy to build means easy to copy and crowded. Prefer ideas with a moat: data, a network, hard tech, a niche the big apps ignore, or distribution the owner controls. |
| An investor said to sell a cheap white-label band with the app, so habits prove themselves by location and heart rate, with the band unlocking the app for life. | Keep the goal (less effort per proof) and drop the gadget: the phone and Apple Health give the signal for free, and each band sold costs more than it seems. See `idea.md`, "A device sold with the app". |
| One said the founder built it for his own pain, which is a sample of one; real validation is asking about 50 people with no reason to lie. | Validate with strangers in the target group before months of work: a waitlist page, a 25-person TestFlight, direct questions in a community. The owner's own need is a start, not proof. |
| One asked whether market research, competitor checks, keyword research, screenshot and paywall comparisons and pricing were done before any code. Another said AI research had missed key players. | Run the full research in `idea.md`, with real App Store searches per keyword and per storefront, not memory. Cite sources. |
| One advised studying competitors, downloading them, following their proven core and doing a few things better. | Copy the category's proven conventions (onboarding length, paywall type, screenshot style) and differ on one axis. |
| One said you can't beat the established gym or food trackers at their own core, so you'll never win those users. | Never fight a leader on its main feature. Go where leaders are weak, or to a group they ignore. |
| Several asked whether the free built-in Screen Time already does this, and why an app is needed when it's in Settings. | Check the free built-in alternative first. The product must say, in one line, what the built-in can't do, on screen 1, store frame 2 and the website. |
| Several asked who would pay, especially a subscription, to lock their own phone, and whether any real-world parallel exists. | Check willingness to pay: do people pay competitors, or pay offline for the same job (coaches, trainers, classes)? Use that parallel in the positioning. |
| Some said the mechanic itself adds friction: they want to build habits, not send photos, and the proof belongs to the user. | Test whether target users want to do the core action again and again. A chore or a punishment kills retention. |
| One said the core idea (live photo verification) was genuinely interesting, and the bottleneck was the onboarding. | Find the part strangers praise and lead with it everywhere. |
| A few said it's a trend that will pass, and to solve a real problem instead. | Prefer lasting, specific problems over trends. If the idea rides a trend, know the exit. |
| Several advised dropping it and building something more original. | When the verdict is weak, say so plainly and suggest the better idea next door. The owner decides. |
| One said the market had simply answered: nobody pays for a generic, AI-looking tracker. | Silence after a fair test is the market's verdict. Write the success bar and the stop rule before launch, then follow it instead of polishing forever. |
| One said 5 days is too early to judge. | Give a launch 2-4 weeks and about 100 paywall views before judging the price or the model. Judge the funnel step by step. |
| One agency said that in a saturated category with polished leaders, an app with no truly new feature will be buried. | The verdict states the realistic ceiling. A crowded category also risks rejection under App Review guideline 4.3(b) (spam) unless the app is clearly unique and of high quality. |
| On the update, three more said nobody pays to have their apps locked until they go to the gym. One compared a prayer-lock app, whose unlock is far quicker. | Counted toward the concept theme, not acted on in the design. Checked: every lock-until-you-act app with real traction unlocks in about a minute, anywhere; place-based ones have almost no ratings (`idea.md`, step 9). |

## 2. Paywall and price (`model-and-price.md`)

| What people said, in short | The rule |
|---|---|
| Several said the price was steep for an unproven app with zero reviews. One said the $39.99 / $9.99 / $119.99 ladder looked like an AI made it. | Price below the leaders while the app has no ratings, on a ladder with a reason. Never a generic round ladder. |
| One said seven paywall views are too few to judge the price; fix the drop-off first. | Don't judge the price before about 100 paywall views. |
| One said: track paywall actions. About half of those who start a purchase should finish. If many start and few finish, look for a bug or a price mismatch; if nobody starts, redesign the paywall. | Log paywall view, purchase started and purchased, then diagnose with those three numbers. |
| Several said to sell the user's success and feeling, not features. | The paywall and the screenshots sell the outcome. |
| Several said to push the free trial harder. | The free trial is the main path, shown honestly (the billed price stays most prominent). |
| One said people expect free apps and avoid paying, and suggested subscriptions or feature paywalls. Another said to charge only after the first proved habit. A third, a founder, said a hard paywall is very bad for a habit app: he would leave the moment he saw one. | What people who aren't paying prefer, not data: RevenueCat's median hard paywall converts about five times better than freemium. The model stays a paywall from day one (`model-and-price.md`). Answer the objection before the paywall instead: a clearer first screen, a better demo, the first result inside onboarding. Change the model only on the app's own numbers. |
| On the update, one said to drop the trial for limited free features, since trial users refund much more. | Checked against RevenueCat and Adapty 2026: freemium earns about a fifth per install, the refund gap is small (3.1% against 2.5%), and trial users renew better. The trial stays (`model-and-price.md`). |
| One said 2 trials from 27 paywall views can't yet name the bottleneck, that a switch from paid to organic traffic isn't a clean before and after, and to follow each trial to its first proof, return and renewal. | True and good practice: compare like with like, follow each trial (`metrics.md`). |

## 3. Trust and conduct

| What people said, in short | The rule |
|---|---|
| Several assumed it was a vibe-coded app built only to make money, and that such founders don't support their apps. | Show care: a real founder story, a support page, timely updates and consistent polish. Inconsistent screens are how people spot a vibe-coded app. |
| A stranger offered a 50/50 split to publish their app on the owner's developer account. | Never publish strangers' apps on your account; it puts every app on it at risk. Decline politely. |
| One noted how desperate wording loses trust. | Public replies stay calm, short and specific. |
| A growth-tool founder gave useful advice while promoting his tool. | Take the advice and ignore the pitch. |
| On the update, one said too many things changed at once to know which worked, and two trials prove nothing yet. | True, and already the rule: change one thing at a time, hold the offer until the trials end, and compare weeks with the same kind of traffic (`metrics.md`). |
| On the update, one said to drop the trial and limit free features instead, since trial users refund more. | Ignored for the model: the refund gap is small (2.5% against 3.1% of revenue, Adapty 2026) and trial users renew better at the first renewal; a free tier converts about five times worse (`model-and-price.md`). |
