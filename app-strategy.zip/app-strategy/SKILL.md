---
name: app-strategy
description: The owner's business playbook for his apps, learned from a real launch and checked against data. Judge whether an app idea is worth building or the market is saturated (research and a one-screen verdict before any code), choose the business model (a hard paywall with a trial by default; every app earns from day one), set prices, read the funnel numbers, set and apply a stop rule, and weigh outside feedback (comments, reviews, testers) by evidence instead of opinion. Use automatically when the owner asks for a new app or about an app idea's chances, asks whether a market is saturated, chooses a paywall type or prices, shares launch or funnel numbers, or shares comments or reviews to learn from. Not for design or building (that is the taste skill) and not for ads or marketing (that is the app-marketing skill).
---

# App strategy

The owner builds native iOS apps alone, without investors. This skill decides what is worth building and how it earns money. The `taste` skill decides how it looks and gets built; the `app-marketing` skill (only when he asks) covers ads, store words and posts.

## Who decides

The owner's newest words win. This skill gives a recommendation with the evidence; he decides on the concept, the model and whether to stop.

## When it runs

- **A new app or app idea:** run `references/idea.md` before any code and send the one-screen verdict.
  - If he asked to create the app, the build starts for "Build" or "Build with a twist" and stops for "Don't build".
  - If he only asked a question, answer with the verdict.
  - If he says "just build it", skip the research and name the twist you're betting on.
- **The paywall type or the prices:** `references/model-and-price.md`.
- **Launch numbers, funnel numbers, "is it working?", "should I stop?":** `references/metrics.md`.
- **Comments, reviews, tester notes:** `references/feedback.md` (how to weigh them) and `references/evidence.md` (what the Toll launch taught).

**Never for a brand website or store** (a clothing brand, a shop): the owner gives the products and prices himself. Build it with the `taste` skill.

## Rules that never bend

- **The goal is revenue.** Every app has a paid plan from day one. Never recommend a free app, ads as the only income, or giving the core away to win comments. Requests for free are what non-payers want, not evidence.
- **Evidence over opinion.** A number from the owner's own funnel or a primary source beats any comment. Label every claim as measured, a source, or an opinion.
- **Don't build into a crowded category without a difference a stranger sees at a glance,** and say so plainly.
- **Write the stop rule before launch** and follow it.
- **Never invent numbers, competitors or prices.** Search, cite and date them.
