---
name: app-marketing
description: The owner's marketing playbook for his apps, kept separate so the design skill stays focused. App Store words (name, subtitle, keywords, description, localization), getting the first honest ratings, organic launch posts and short videos, creator (UGC) videos, Reddit posts and giveaways, and paid ads (Apple Search Ads, Meta, TikTok) only once the funnel converts. Use only when the owner asks about marketing, ads, App Store search (ASO), launch posts, ratings or growth; never just because an app is being built or designed. The look of store screenshots belongs to the taste skill, and business decisions (model, prices, stop rule) belong to app-strategy.
---

# App marketing

Load this skill only when the owner asks about marketing. Building an app never loads it.

## Order of work

1. **Store page words:** `references/store-words.md`.
2. **First honest ratings and organic launch:** `references/organic.md`.
3. **Paid ads, only once the funnel converts** (app-strategy, `references/metrics.md`): `references/ads.md`.

## Rules

- **Never pay for traffic before the store page, onboarding and paywall convert.** Toll spent $294 on Apple Ads for 53 installs and earned $0.
- **Lead every surface with the one thing only this app does.**
- **Claims about ads must be verified** (a platform's own documentation, or the owner's own numbers). One commenter's experience is a hypothesis.
- **The evidence behind these rules** is in `references/evidence.md`.
