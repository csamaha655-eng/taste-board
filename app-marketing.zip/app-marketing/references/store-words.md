# Store page words (App Store search)

The look of the screenshots and the icon is in the `taste` skill. This file covers the words.

- **Words:**
  - the title is "Name: what it does in search words" ("Toll: App Blocker for Habits");
  - the subtitle carries more search terms ("Lock In: Earn Your Screen Time");
  - the keyword field is filled to 100 characters (commas, no spaces) with no words already in the title or subtitle;
  - the title and subtitle are 30 characters each, and never stuffed with keywords (guideline 2.3.7);
  - a new app with no ratings won't rank for head terms, so aim at 3 to 5 long-tail phrases where it can reach the top 10, and check those ranks a week after release. Pick them by the app's own promise (what it does that others don't), not the category name, and measure the competition before choosing: the public iTunes Search API returns each term's top results with their rating counts, so a term whose top 10 have few ratings or are off-topic is one a new app can win.
- **Description:** the first lines say what it does, the difference and the honest price ("7 days free, then $29.99 a year"), then a short, real founder story. No hype words.
- **Get honest ratings early** (a page with 0 ratings looks abandoned): `organic.md`, "The first honest ratings".
- **Localize** the name, subtitle, keywords and screenshot captions for every storefront you target, or exclude that storefront from ads. 47% of Toll's ad money went to France for an English-only page.
- **Promotional text** (170 characters) can change without a new version: use it for the current offer or the newest feature: why someone would want the app and the honest price fit in one line. A new version created through the API starts with it empty, so set it on every new version before submitting.
