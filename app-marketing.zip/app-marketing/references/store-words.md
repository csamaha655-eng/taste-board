# Store page words (App Store search)

The look of the screenshots and the icon is in the `taste` skill. This file covers the words.

- **Words:**
  - the title is "Name: what only this app does, in search words" ("Toll: Habit Photos Unlock Apps"). Never the crowded category word ("App Blocker"): nearly every competitor's title has it, a new app can't rank for it, and it hides the difference. The words must still tell a stranger the category ("Unlock Apps" says the apps are locked). Move the category word into the keyword field so phrases that combine it ("scroll blocker", "habit app blocker") still match;
  - the subtitle carries more search terms ("Lock In: Earn Your Screen Time");
  - the keyword field is filled to 100 characters (commas, no spaces) with no words already in the title or subtitle;
  - the title and subtitle are 30 characters each, and never stuffed with keywords (guideline 2.3.7);
  - a new app with no ratings won't rank for head terms, so aim at 3 to 5 long-tail phrases where it can reach the top 10, and check those ranks a week after release. Pick them by the app's own promise (what it does that others don't), not the category name, and measure the competition before choosing: the public iTunes Search API returns each term's top results with their rating counts, so a term whose top 10 have few ratings or are off-topic is one a new app can win.
- **What search reads (Apple, checked 2026-10-19):** the name, subtitle, keyword field, primary category and company name, and since October 2025 each custom product page's own keywords. Never the description or the promotional text. App Store Connect shows no organic search terms (Apple said so at WWDC26; only Apple Ads has a search-terms report), so give each keyword group its own custom product page and compare their search downloads to see which group works.
- **Description:** the first lines say what it does, the difference and the honest price ("7 days free, then $29.99 a year"), then a short, real founder story. No hype words.
- **Get honest ratings early** (a page with 0 ratings looks abandoned): `organic.md`, "The first honest ratings".
- **Localize** the name, subtitle, keywords and screenshot captions for every storefront you target, or exclude that storefront from ads. 47% of Toll's ad money went to France for an English-only page.
- **Promotional text** (170 characters) can change without a new version: use it for the current offer or the newest feature: why someone would want the app and the honest price fit in one line. A new version created through the API starts with it empty, so set it on every new version before submitting.
