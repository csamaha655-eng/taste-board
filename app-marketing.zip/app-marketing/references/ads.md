# Paid ads (only once the funnel converts)

- **Prove the funnel first.** Paid traffic only after the store page, onboarding and paywall convert (app-strategy, `references/metrics.md`). Compare cost per install with revenue per install; stop when it loses money.
- **Apple Search Ads:**
  - exact match on intent phrases, Search Match off;
  - English storefronts only until the page is localized;
  - read the search-terms report every few days: broad terms that name a free built-in feature ("screen time") bring people who wanted Apple's own tool, so exclude them;
  - long-tail phrases are cheaper and convert better for a new app.
- **Meta and TikTok:** an ad set leaves its learning phase after about 50 optimization events in 7 days (Meta's own rule), so the budget is about 50 times the cost of one event. Don't start without it.
- **Meta for a new iOS app (measured on Toll, October 2026):**
  - an App promotion campaign optimized for installs barely delivers until real users send the SDK's events (Toll: approved, $0.20 in 30 hours, flagged for too few events), so ship the SDK a few weeks before the ads;
  - "Maximise link clicks" is refused inside an iOS 14+ App promotion campaign;
  - the Traffic objective with the App destination shows the ads only to people who already have the app (`app_install_state: installed`): never use it to find new users;
  - website traffic ads need a Facebook Page at least 30 days old (error #100.3867089): make the Page a month before the ads.
- **Custom product pages** per ad group, so the page matches the search.
- **Scale slowly:** raise budgets only on campaigns that pay back, and keep a daily cap.
