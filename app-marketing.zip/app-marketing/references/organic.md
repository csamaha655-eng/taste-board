# Organic launch, ratings and posts

- **Short videos and creator (UGC) videos first** in a crowded niche: real people showing the core moment. App blockers grew this way (Brick, Pushscroll, touch grass).
- **Reddit:** post the real story and real numbers, and ask for feedback. Answer every comment calmly and specifically, without arguing. Never post fake reviews or sock-puppet comments.
- **The first honest ratings:**
  - friends;
  - free codes for the first 25 people in the target group, in exchange for feedback;
  - the in-app rating prompt after the first real success.

  Never condition a gift on a review. A page with 0 ratings looks abandoned.
- **A giveaway** (free lifetime codes) gets feedback and first users. Say what you want from them (what confused them, what they'd change).
- **Show you care:** a real founder story, a support page, timely updates and fast replies. People assume a vibe-coded app gets abandoned.
- **Never publish strangers' apps on your developer account**, however the split is offered. It puts every app on that account at risk.
