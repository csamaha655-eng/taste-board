# Evidence: what the Toll launch taught about store words, ads and posts

Paraphrased comments from the October 2026 Reddit threads, each with the rule it gives. Claims that couldn't be verified are labeled as one person's claim.

## 1. Store page and search

| What people said, in short | The rule |
|---|---|
| Several said: put the category ("App Blocker", "Screen Time") in the title, since the subtitle had no search terms. | The title is "Name: category words"; the subtitle and keywords carry searched terms. |
| One said to fix the store listing before ads. | Order: store page, onboarding, paywall, then traffic. |
| One said search indexes only the name, subtitle and keyword field, and asked which terms brought the downloads. | Partly true: Apple also reads the category, the company name and custom product pages' keywords; never the description. Apple gives no organic search terms, so compare custom product pages (`store-words.md`). |
| Several said the page needs honest reviews (friends, or the first 25 target users getting it free for feedback) because zero ratings looks abandoned. | Get early honest ratings without conditions. Ask for a rating after the first real success. |

## 2. Ads and distribution

| What people said, in short | The rule |
|---|---|
| Many said to stop the ads: $5.54 per install with $0 revenue loses money on every install. | No paid ads until the funnel converts. Compare cost per install with revenue per install. |
| Several said the ads were working; the leak was after the install. | Find the leaking step before changing traffic. |
| One said to read the search-terms report, since broad terms like "screen time" bring people who wanted Apple's built-in feature. | Exact match on intent terms only; exclude terms that name a free built-in feature. |
| One said to look for cheaper keywords. | Long-tail terms a new app can win, not head terms. |
| One said ad algorithms need $1,000-3,000 to learn. | Partly verified. Meta's own rule is that an ad set leaves its learning phase after about 50 optimization events in 7 days, so the budget is about 50 times the cost of one event. Apple Search Ads is a keyword auction with no learning phase. Don't start social ads without that budget. |
| A developer making about $10,000 a month said Apple Ads were unprofitable for him too. | One person's experience, not data. Measure cost per install against revenue per install before scaling, and stop when it loses money. |
| Several said organic marketing (short video, Reddit) is the way. One said that in a saturated niche, the money should go to UGC (creators' short videos), not ads. | Plan organic launch posts and short videos from the start. With a budget in a crowded niche, pay small creators for short videos before paying for ads. |
| One suggested $300 a day. | Ignored as advice. Never scale spend on a funnel that doesn't convert. |
| Some wrote in other languages; the ads had bought French traffic for an English-only app. | Localize the store page for every market you target, or exclude it from ads. |
| On the update, a 20-year publisher said store discoverability is close to dead without your own top of funnel; another asked how the users will come. | Partly true: search still brings most downloads, but a new app ranks low. Bring the first visitors from outside the store (`organic.md`). His "DM me" pitch ignored. |

