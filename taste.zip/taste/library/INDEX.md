# Library: extra website examples

Six guides the owner bought (October 2026). They are optional reference material, not the design language. The owner's themes, the style board and the rest of this skill always win.

**How to use it cheaply:**
- Never read a whole PDF.
- Grep the `.txt` copy for what you need. Every page starts with `=== PAGE n ===`.
- Read only those lines, then adapt what you find to the chosen theme.

## What's where

**prompt-vault-50.txt**: 50 ready site briefs by industry. Use it to find the story and sections for a subject the themes don't cover. The briefs are numbered `NN — NAME`; grep the industry.
- 01 AI startup, 02 luxury watch, 03 creative agency, 04 supercar, 05 sneaker, 06 gaming studio, 07 architecture, 08 luxury fashion, 09 headphones, 10 space tech
- 11 coffee, 12 fintech, 13 luxury hotel, 14 perfume, 15 robotics, 16 electric motorcycle, 17 music artist, 18 cybersecurity, 19 luxury real estate, 20 smartphone launch
- 21 creative portfolio, 22 skincare, 23 furniture, 24 drone, 25 beverage, 26 camera, 27 fitness tech, 28 premium travel, 29 tech conference, 30 jewelry
- 31 gaming keyboard, 32 AI SaaS dashboard, 33 production studio, 34 chocolate, 35 virtual world, 36 bicycle, 37 interior design, 38 smart home, 39 car configurator, 40 space tourism
- 41 yacht, 42 speaker, 43 fashion e-commerce, 44 gaming chair, 45 developer portfolio, 46 eyewear, 47 digital bank, 48 cosmetics, 49 solar, 50 experimental 3D
- Pages 15-17: prompts to upgrade any site, fix a cheap-looking site, optimize for mobile, and optimize for performance.

**animation-vault.txt**: 20 effects, each with what it does, where it fits and an instruction.
- 01 scroll reveal, 02 parallax depth, 03 3D card tilt, 04 magnetic button, 05 floating 3D object
- 06 mouse follower, 07 text reveal, 08 image scale on scroll, 09 horizontal scroll, 10 3D hero mouse reaction
- 11 staggered cards, 12 button hover, 13 logo marquee, 14 spotlight card, 15 section transition
- 16 3D product rotation, 17 scroll progress, 18 number counter, 19 depth hover image, 20 cinematic hero entrance
- Pages 11-13: the golden rule, a "make it premium" pass, and a pre-publish checklist.

**animated-websites-guide.txt**: effects with code. Only these parts are useful.
- **Parallax:** p7-9 explain the four kinds (background, multi-layer, horizontal, mouse). Build them with the modern recipes in `references/web.md`, "Parallax and scroll recipes". The guide's code uses scroll listeners and `background-attachment: fixed`, so use it as explanation only.
- **Reveals:** p10-11, scroll reveals and line-mask text reveals. Start them visible, as the skill says.
- **Hover:** p12-13, micro-interactions: magnetic button, subtle tilt, image zoom, underline draw.
- **Scroll storytelling:** p16-17, scroll-scrubbed video, sticky feature showcase, scale on scroll.
- **Before launch:** p24-26, pro tips and the pre-launch checklist.
- **Skipped as useless or against the owner's taste:**
  - builder recommendations (p3-4);
  - generic prompts (p5-6);
  - typewriter, gradient text and scramble (p14-15);
  - page wipes and loaders (p18);
  - gradient backgrounds, Vanta, blobs and noise (p19-20);
  - "complete website" prompts full of gimmicks (p21).

**animation-toolkit.txt**: choosing and integrating animation tools.
- Tools: GSAP p9-11, Motion p11-12, Spline p12-14, Three.js p14-15, Lottie p15-16
- Component libraries: Aceternity UI p5-7, React Bits p7-8
- p17-21: dependency checks; p22-23: sandbox first; p23-25: one motion language
- p25-26: performance, mobile and reduced motion; p28-29: resource map
- p29-30: the 15-step integration workflow; p30-32: integration, debugging and performance prompts

**project-lab.txt**: 10 worked briefs plus quality tests.
- Briefs: AI landing, watch, portfolio, headphones, supercar, fashion, gaming studio, architecture, agency, wearable launch
- Tests: show the page without 3D, without animation, and the 5-second test
- p21-22: final audit; p24-25: scorecard out of 50; p25-26: the 24-hour test and when to stop iterating

**prompting-playbook.txt**: how to brief.
- p2-7: the formula: purpose, audience, visual direction, structure, 3D, motion, constraints
- p8: freeze what works; p8-9: change one variable at a time
- p15-17: directing 3D (object, material, light, camera, motion, role) and directing animation (element, trigger, action, intensity, duration, fallback)
- p20-22: the 5-second, squint, no-animation and slow-internet tests
- Use it when the owner wants a prompt for another AI builder (Lovable, Framer, Bolt).

## What these guides get wrong for this owner (ignore it every time)

- **Color:** their purple and cyan palette (#7C3AED, #06B6D4); any gradient, including gradient text, animated gradient backgrounds, gradient progress bars and gradient flip-card backs.
- **Decoration:**
  - morphing blobs;
  - Vanta particle networks;
  - colored glows and colored spotlights;
  - noise laid over gradients.
- **Gimmicks:**
  - custom cursors and colored cursor followers;
  - typewriter and scramble headlines;
  - loading screens;
  - confetti;
  - colored page-transition wipes;
  - card flips and liquid-fill buttons.
- **Fonts:** pairs like Inter with Bricolage Grotesque. Use one family, as the skill says.
- **Content:** fake stats, fake testimonials, fake client logos, marquees of logos that aren't real.
- **Technique:** `background-attachment: fixed` for parallax (broken on iOS Safari; use transform layers like `.journey` in specimen.html), and `opacity: 0` reveals that wait for JavaScript (start visible instead).
- **Builders:** their builder recommendations (Lovable, Framer, Webflow, Bolt). The owner builds with Claude Code; the stack is in `references/web.md`.
