// site-check: tests a website before it is shown to the owner. No dependencies; uses the Mac's Chrome.
//   node site-check.mjs <url | folder> [out-dir]
// A folder is served on a local port. For every page found (same-origin links, up to 25) at 390 and
// 1440 px wide it records: console errors and uncaught exceptions, failed requests and 4xx/5xx
// responses, broken images, sideways overflow, small touch targets, and what happens when every
// visible button and in-page control is clicked. Download links (files) are checked to exist, not opened.
// Screenshots land in out-dir. Exit code 1 if anything failed.
import { spawn } from 'node:child_process';
import { createServer } from 'node:http';
import { readFile, stat, mkdir, writeFile } from 'node:fs/promises';
import { join, extname, resolve } from 'node:path';

const target = process.argv[2]; const OUT = resolve(process.argv[3] || 'site-check-out');
if (!target) { console.error('usage: node site-check.mjs <url | folder> [out-dir]'); process.exit(2); }
await mkdir(OUT, { recursive: true });
const sleep = ms => new Promise(r => setTimeout(r, ms));

// Serve a folder if given one.
let base = target, server;
if (!/^https?:/.test(target)) {
  const root = resolve(target);
  const types = { '.html':'text/html', '.css':'text/css', '.js':'text/javascript', '.mjs':'text/javascript', '.json':'application/json', '.svg':'image/svg+xml', '.png':'image/png', '.jpg':'image/jpeg', '.jpeg':'image/jpeg', '.webp':'image/webp', '.avif':'image/avif', '.woff2':'font/woff2', '.ico':'image/x-icon', '.mp4':'video/mp4' };
  server = createServer(async (req, res) => {
    let p = join(root, decodeURIComponent(req.url.split('?')[0]));
    try { if ((await stat(p)).isDirectory()) p = join(p, 'index.html'); res.writeHead(200, { 'content-type': types[extname(p)] || 'application/octet-stream' }); res.end(await readFile(p)); }
    catch { res.writeHead(404); res.end('not found'); }
  }).listen(0);
  base = `http://127.0.0.1:${server.address().port}/`;
}

const PORT = 9400 + Math.floor(Math.random() * 400);
const chrome = spawn('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  ['--headless=new', '--disable-gpu', '--hide-scrollbars', `--remote-debugging-port=${PORT}`, `--user-data-dir=/tmp/site-check-${PORT}`, 'about:blank'], { stdio: 'ignore' });
let ws, id = 0; const pending = new Map(); let events = [];
async function connect() {
  for (let i = 0; i < 80; i++) { try {
    const t = (await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json()).find(x => x.type === 'page');
    if (t) { ws = new WebSocket(t.webSocketDebuggerUrl); await new Promise(r => ws.onopen = r);
      ws.onmessage = m => { const d = JSON.parse(m.data); if (d.id && pending.has(d.id)) { pending.get(d.id)(d); pending.delete(d.id); } else if (d.method) events.push(d); }; return; }
  } catch {} await sleep(200); }
  throw new Error('Chrome did not start');
}
const send = (method, params = {}) => new Promise(r => { const i = ++id; pending.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
const js = async e => (await send('Runtime.evaluate', { expression: e, awaitPromise: true, returnByValue: true })).result?.result?.value;
const issues = []; const note = (page, w, kind, msg) => issues.push(`[${w}px] ${page} · ${kind}: ${msg}`);
const drain = (page, w) => { for (const e of events) {
  if (e.method === 'Runtime.exceptionThrown') note(page, w, 'exception', e.params.exceptionDetails.exception?.description?.split('\n')[0] || e.params.exceptionDetails.text);
  if (e.method === 'Runtime.consoleAPICalled' && e.params.type === 'error') note(page, w, 'console error', e.params.args.map(a => a.value ?? a.description).join(' ').slice(0, 200));
  if (e.method === 'Network.loadingFailed' && !e.params.canceled) note(page, w, 'request failed', e.params.errorText);
  if (e.method === 'Network.responseReceived' && e.params.response.status >= 400) note(page, w, `HTTP ${e.params.response.status}`, e.params.response.url);
} events = []; };

try {
  await connect(); await send('Page.enable'); await send('Runtime.enable'); await send('Network.enable');
  const pages = [base]; const seen = new Set([base]);
  for (let p = 0; p < pages.length && p < 25; p++) {
    for (const W of [390, 1440]) {
      const H = W < 600 ? 844 : 900; const tag = `${String(p).padStart(2, '0')}-${W}`;
      await send('Emulation.setDeviceMetricsOverride', { width: W, height: H, deviceScaleFactor: 1, mobile: W < 600 });
      events = []; await send('Page.navigate', { url: pages[p] }); await sleep(3500);
      const r = await send('Page.captureScreenshot', { format: 'png' }); await writeFile(join(OUT, `${tag}.png`), Buffer.from(r.result.data, 'base64'));
      const facts = await js(`(()=>{const out={};
        const de=document.documentElement, vw=de.clientWidth; out.overflow=Math.max(de.scrollWidth, document.body.scrollWidth)>vw+1 ? Math.max(de.scrollWidth, document.body.scrollWidth) : 0;
        out.brokenImgs=[...document.images].filter(i=>i.complete&&i.naturalWidth===0).map(i=>i.src).slice(0,10);
        out.noAlt=[...document.images].filter(i=>!i.hasAttribute('alt')).length;
        const ctl=[...document.querySelectorAll('a,button,[role=button],input,select,summary')].filter(e=>e.offsetParent&&!e.closest('[inert],[aria-hidden="true"]'));
        // A control is small when its box is under 44px both ways AND its real hit area (padding or a ::before
        // that extends it) doesn't reach 22px out from its center in all four directions.
        const hits=(e)=>{e.scrollIntoView({block:'center',inline:'center'});const b=e.getBoundingClientRect(),cx=b.left+b.width/2,cy=b.top+b.height/2;
          return [[cx-21,cy],[cx+21,cy],[cx,cy-21],[cx,cy+21]].every(([x,y])=>{const t=document.elementFromPoint(x,y);return t&&(t===e||e.contains(t));});};
        out.small=ctl.filter(e=>{const b=e.getBoundingClientRect();return b.width>0&&(b.width<44&&b.height<44)&&!hits(e)}).map(e=>(e.innerText||e.getAttribute('aria-label')||e.tagName).trim().slice(0,30)).slice(0,12);
        scrollTo(0,0);
        const isFile=(h)=>/\.(zip|pdf|png|jpe?g|webp|avif|gif|svg|mp4|mov|dmg|ipa|txt|json|csv)$/i.test(new URL(h).pathname);
        out.links=[...document.querySelectorAll('a[href]')].filter(a=>!a.hasAttribute('download')).map(a=>a.href).filter(h=>h.startsWith(location.origin)&&!h.includes('#')&&!isFile(h));
        out.files=[...new Set([...document.querySelectorAll('a[href]')].map(a=>a.href).filter(h=>h.startsWith(location.origin)&&(isFile(h)||[...document.querySelectorAll('a[download]')].some(a=>a.href===h))))];
        out.deadLinks=[...document.querySelectorAll('a')].filter(a=>!a.getAttribute('href')||a.getAttribute('href')==='#').map(a=>a.innerText.trim().slice(0,30)).slice(0,10);
        return out;})()`);
      if (facts.overflow) note(pages[p], W, 'sideways overflow', `page is ${facts.overflow}px wide`);
      facts.brokenImgs.forEach(s => note(pages[p], W, 'broken image', s));
      if (facts.noAlt) note(pages[p], W, 'images without alt', facts.noAlt);
      if (W < 600 && facts.small.length) note(pages[p], W, 'touch targets under 44px', facts.small.join(', '));
      if (facts.deadLinks.length) note(pages[p], W, 'links with no destination', facts.deadLinks.join(', '));
      if (W === 1440) for (const l of facts.links) { const u = l.split('?')[0]; if (!seen.has(u)) { seen.add(u); pages.push(u); } }
      // Download links are checked for existence, not opened as pages.
      if (W === 1440) for (const f of facts.files) { if (seen.has(f)) continue; seen.add(f);
        try { const r = await fetch(f, { method: 'HEAD' }); if (r.status >= 400) note(pages[p], W, `file ${r.status}`, f); } catch (e) { note(pages[p], W, 'file unreachable', f); } }
      drain(pages[p], W);
      // Click every visible control that stays on this page; reload after each so states don't pile up.
      const n = await js(`[...document.querySelectorAll('button,[role=button],summary,a[href^="#"]')].filter(e=>e.offsetParent&&!e.closest('[inert],[aria-hidden="true"]')).length`);
      for (let i = 0; i < Math.min(n, 40); i++) {
        const label = await js(`(()=>{const e=[...document.querySelectorAll('button,[role=button],summary,a[href^="#"]')].filter(e=>e.offsetParent&&!e.closest('[inert],[aria-hidden="true"]'))[${i}]; if(!e) return null; e.scrollIntoView({block:'center'}); return (e.innerText||e.getAttribute('aria-label')||e.className||e.tagName).toString().trim().replace(/\\s+/g,' ').slice(0,40);})()`);
        if (label === null) continue;
        const before = await js('JSON.stringify([document.body.innerHTML.length, location.href])');
        // Let a smooth scroll (scroll-behavior: smooth) settle before measuring where to click.
        let last = '';
        for (let k = 0; k < 20; k++) { await sleep(100); const cur = await js('window.scrollX+","+window.scrollY'); if (cur === last) break; last = cur; }
        const pt = await js(`(()=>{const e=[...document.querySelectorAll('button,[role=button],summary,a[href^="#"]')].filter(e=>e.offsetParent&&!e.closest('[inert],[aria-hidden="true"]'))[${i}]; const b=e.getBoundingClientRect(); if (b.bottom<=0||b.top>=innerHeight||b.right<=0||b.left>=innerWidth) return null; return [b.left+b.width/2,b.top+b.height/2];})()`);
        if (pt === null) continue;   // off-screen until focused, like a skip link: keyboard only
        for (const type of ['mouseMoved', 'mousePressed', 'mouseReleased']) await send('Input.dispatchMouseEvent', { type, x: pt[0], y: pt[1], button: 'left', clickCount: 1 });
        await sleep(450);
        const after = JSON.parse(await js('JSON.stringify([document.body.innerHTML.length, location.href, !!document.querySelector("[aria-expanded=true],[open],dialog[open],.is-open,.open,[data-open],[aria-pressed=true]:focus")])'));
        const had = events.length; drain(pages[p], W);
        if (before === JSON.stringify(after.slice(0, 2)) && !after[2] && !had) note(pages[p], W, 'control did nothing visible', label);
        await send('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Escape', code: 'Escape', windowsVirtualKeyCode: 27 });
        await send('Page.navigate', { url: pages[p] }); await sleep(1500); events = [];
      }
    }
  }
  const report = [`site-check ${new Date().toISOString()} · ${pages.length} page(s) · base ${base}`, issues.length ? `${issues.length} issue(s):` : 'No issues found.', ...issues].join('\n');
  await writeFile(join(OUT, 'report.txt'), report); console.log(report); console.log(`Screenshots: ${OUT}`);
  process.exitCode = issues.length ? 1 : 0;
} finally { try { ws.close(); } catch {} chrome.kill(); server?.close(); }
