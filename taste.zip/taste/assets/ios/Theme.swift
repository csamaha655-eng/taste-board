import SwiftUI

// taste · iOS starter (SwiftUI, Swift 6, iOS 26+)
// Every app uses the same design: the style board's phones. That means a two-tone header,
// frosted sheets stacked with depth, a black pill, a glass week strip and a prompt capsule,
// over one soft atmosphere. Only the palette changes per app: pick a preset or make one
// from the app's own hue, then set it once with `.environment(\.palette, .graphite)`.
// Rules: solid colors, never gradients; Liquid Glass on bars and floating controls; text sits
// on frosted sheets (opaque enough to read) or solid cards; SF Pro, never thin weights.
// Light by default (Steel, Graphite, Paper or the app's own light hue). Dark follows the dark rule in
// references/themes.md: Graphite night; Midnight only when the owner names the night phone.
// Images are real photos or flat marks drawn in code, never rendered 3D, metal or glow (references/ios.md, "Art, images and words").

// MARK: - Palette

struct TastePalette: Sendable {
    var fog: Color            // canvas behind everything
    var surface: Color        // solid cards (settings, forms)
    var ink: Color
    var ink2: Color
    var hairline: Color
    var accent: Color         // selection, links, focus only
    var primary: Color        // the pill
    var onPrimary: Color
    var atmosphere: [Color]   // 0-2 shades of ONE hue, drawn as soft light behind the sheets
    var headerInk: Color      // title over the atmosphere
    var headerInk2: Color     // second line of the two-tone title

    /// Steel: the style board's day phone.
    static let steel = TastePalette(
        fog: Color(hex: 0xEEF0F3), surface: .white, ink: Color(hex: 0x111214), ink2: Color(hex: 0x5E6470),
        hairline: Color(hex: 0xDDE1E7), accent: Color(hex: 0x3E6E91), primary: Color(hex: 0x0A0A0B), onPrimary: .white,
        atmosphere: [Color(hex: 0x6F95B2)], headerInk: .white, headerInk2: .white.opacity(0.66))

    /// Midnight: the style board's night phone.
    static let midnight = TastePalette(
        fog: Color(hex: 0xEEF0F5), surface: .white, ink: Color(hex: 0x111214), ink2: Color(hex: 0x5E6470),
        hairline: Color(hex: 0xDDE1E7), accent: Color(hex: 0x4566D8), primary: Color(hex: 0x0A0A0B), onPrimary: .white,
        atmosphere: [Color(hex: 0x070B16), Color(hex: 0x4566D8)], headerInk: .white, headerInk2: Color(hex: 0x9DB0FF))

    /// Graphite: grey, black and white.
    static let graphite = TastePalette(
        fog: Color(hex: 0xEFEFF0), surface: .white, ink: Color(hex: 0x111214), ink2: Color(hex: 0x5F6168),
        hairline: Color(hex: 0xDEDFE2), accent: Color(hex: 0x111214), primary: Color(hex: 0x0A0A0B), onPrimary: .white,
        atmosphere: [Color(hex: 0x8C8F95)], headerInk: .white, headerInk2: .white.opacity(0.66))

    /// Graphite night: black falling into grey.
    static let graphiteNight = TastePalette(
        fog: Color(hex: 0xEFEFF0), surface: .white, ink: Color(hex: 0x111214), ink2: Color(hex: 0x5F6168),
        hairline: Color(hex: 0xDEDFE2), accent: Color(hex: 0x111214), primary: Color(hex: 0x0A0A0B), onPrimary: .white,
        atmosphere: [Color(hex: 0x0B0B0C), Color(hex: 0x4A4C52)], headerInk: .white, headerInk2: Color(hex: 0xB9BBC0))

    /// Paper: no atmosphere, just the fog canvas. Quietest option.
    static let paper = TastePalette(
        fog: Color(hex: 0xF5F6F8), surface: .white, ink: Color(hex: 0x0E0F12), ink2: Color(hex: 0x686D78),
        hairline: Color(hex: 0xE3E5EA), accent: Color(hex: 0x1F4E79), primary: Color(hex: 0x0E0F12), onPrimary: .white,
        atmosphere: [], headerInk: Color(hex: 0x0E0F12), headerInk2: Color(hex: 0x686D78))
}

extension EnvironmentValues {
    @Entry var palette: TastePalette = .steel
}

extension Color {
    /// Solid sRGB color from a 0xRRGGBB literal.
    init(hex: UInt32, opacity: Double = 1) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue: Double(hex & 0xFF) / 255,
            opacity: opacity
        )
    }
}

// MARK: - Screen and atmosphere

/// One hue as soft light behind the sheets, falling into the fog. Built from blurred solid
/// shapes, not gradient fills. Never on a control.
struct AtmosphereLight: View {
    var colors: [Color]

    var body: some View {
        GeometryReader { proxy in
            let width = proxy.size.width
            ZStack(alignment: .topLeading) {
                if let first = colors.first {
                    Ellipse().fill(first)
                        .frame(width: width * 1.6, height: width * 1.15)
                        .offset(x: -width * 0.35, y: -width * 0.45)
                }
                if colors.count > 1 {
                    Ellipse().fill(colors[1]).opacity(0.5)
                        .frame(width: width * 1.3, height: width * 0.7)
                        .offset(x: -width * 0.15, y: width * 0.45)
                }
            }
            .blur(radius: 60)
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

extension View {
    /// Fixed fog and atmosphere behind the screen, so nothing appears as a band while scrolling.
    func tasteScreen() -> some View {
        modifier(TasteScreen())
    }

    /// Scroll defaults: no indicators, soft top edge.
    func tasteScroll() -> some View {
        scrollIndicators(.hidden)
            .scrollEdgeEffectStyle(.soft, for: .top)
    }
}

private struct TasteScreen: ViewModifier {
    @Environment(\.palette) private var palette

    func body(content: Content) -> some View {
        content.background {
            ZStack {
                palette.fog
                AtmosphereLight(colors: palette.atmosphere)
            }
            .ignoresSafeArea()
        }
    }
}

// MARK: - Sheets and cards

/// The frosted sheet from the style board. Layers get more opaque toward the front.
/// Reduce Transparency turns them solid.
struct FrostedSheet: ViewModifier {
    enum Layer { case back, front, under }
    var layer: Layer = .front
    var radius: CGFloat = 30
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency

    private var whiteOpacity: Double {
        switch layer {
        case .back: 0.4
        case .front: 0.82
        case .under: 0.55
        }
    }

    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: radius, style: .continuous)
        content
            .frame(maxWidth: .infinity, alignment: .leading)
            .background {
                if reduceTransparency {
                    shape.fill(.white)
                } else {
                    ZStack {
                        shape.fill(.ultraThinMaterial)
                        shape.fill(.white.opacity(whiteOpacity))
                    }
                }
            }
            .overlay { shape.strokeBorder(.white.opacity(0.55), lineWidth: 0.5) }
            .shadow(color: Color(hex: 0x141E30).opacity(0.16), radius: 18, y: 10)
    }
}

/// Solid content card for settings, forms and long lists.
struct SolidCard: ViewModifier {
    var radius: CGFloat = 24
    var padding: CGFloat = 16
    @Environment(\.palette) private var palette

    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: radius, style: .continuous)
        content
            .padding(padding)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(palette.surface, in: shape)
            .overlay { shape.strokeBorder(palette.hairline, lineWidth: 0.5) }
    }
}

extension View {
    func frostedSheet(_ layer: FrostedSheet.Layer = .front, radius: CGFloat = 30) -> some View {
        modifier(FrostedSheet(layer: layer, radius: radius))
    }

    func solidCard(radius: CGFloat = 24, padding: CGFloat = 16) -> some View {
        modifier(SolidCard(radius: radius, padding: padding))
    }
}

// MARK: - Type

/// Signature header: line one and line two in two tones, same size.
struct TwoToneTitle: View {
    let primary: String
    let secondary: String
    var onAtmosphere = true
    @Environment(\.palette) private var palette

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text(primary).foregroundStyle(onAtmosphere ? palette.headerInk : palette.ink)
            Text(secondary).foregroundStyle(onAtmosphere ? palette.headerInk2 : palette.ink2)
        }
        .font(.largeTitle.weight(.semibold))
        .tracking(-0.6)
        .accessibilityElement(children: .combine)
    }
}

private struct Eyebrow: ViewModifier {
    @Environment(\.palette) private var palette

    func body(content: Content) -> some View {
        content
            .font(.footnote)
            .foregroundStyle(palette.ink2)
    }
}

extension View {
    /// Small quiet label at the top of a sheet ("Today's focus").
    func eyebrow() -> some View { modifier(Eyebrow()) }
}

// MARK: - Controls

/// The primary pill: black with a white label. One per screen.
struct PrimaryPillStyle: ButtonStyle {
    @Environment(\.palette) private var palette

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.subheadline.weight(.semibold))
            .foregroundStyle(palette.onPrimary)
            .padding(.horizontal, 18)
            .frame(minHeight: 44)
            .background(palette.primary, in: .capsule)
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .animation(.snappy(duration: 0.18), value: configuration.isPressed)
    }
}

extension ButtonStyle where Self == PrimaryPillStyle {
    static var primaryPill: PrimaryPillStyle { PrimaryPillStyle() }
}

/// Round glass icon button for headers and floating controls.
struct GlassIconButton: View {
    let systemImage: String
    let label: String
    let action: () -> Void
    @Environment(\.palette) private var palette

    var body: some View {
        Button(action: action) {
            Image(systemName: systemImage)
                .font(.system(size: 17, weight: .semibold))
                .frame(width: 30, height: 30)
        }
        .buttonStyle(.glass)
        .buttonBorderShape(.circle)
        .foregroundStyle(palette.headerInk)
        .accessibilityLabel(label)
    }
}

/// Thin solid progress ring. Never a gradient stroke.
struct ProgressRing: View {
    var progress: Double
    var tint: Color
    var lineWidth: CGFloat = 2.5

    var body: some View {
        ZStack {
            Circle().stroke(tint.opacity(0.18), lineWidth: lineWidth)
            Circle()
                .trim(from: 0, to: min(max(progress, 0), 1))
                .stroke(tint, style: StrokeStyle(lineWidth: lineWidth, lineCap: .round))
                .rotationEffect(.degrees(-90))
        }
        .animation(.smooth, value: progress)
        .accessibilityElement()
        .accessibilityLabel("Progress")
        .accessibilityValue(Text(progress, format: .percent.precision(.fractionLength(0))))
    }
}

/// Week strip: the selected day is a raised white capsule; dots mark days with items.
struct WeekStrip: View {
    let days: [Date]
    @Binding var selection: Date
    var marked: Set<Date> = []
    @Environment(\.palette) private var palette

    var body: some View {
        HStack(spacing: 0) {
            ForEach(days, id: \.self) { day in
                let isOn = Calendar.current.isDate(day, inSameDayAs: selection)
                let hasItems = marked.contains { Calendar.current.isDate($0, inSameDayAs: day) }
                Button { selection = day } label: {
                    VStack(spacing: 3) {
                        Text(day, format: .dateTime.weekday(.narrow))
                            .font(.caption2)
                            .foregroundStyle(palette.ink2)
                        Text(day, format: .dateTime.day())
                            .font(.body.weight(.medium))
                            .monospacedDigit()
                            .foregroundStyle(palette.ink)
                        Circle()
                            .fill(palette.ink2)
                            .frame(width: 4, height: 4)
                            .opacity(hasItems ? 1 : 0)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                    .background {
                        if isOn {
                            Capsule().fill(.white).shadow(color: .black.opacity(0.12), radius: 8, y: 4)
                        }
                    }
                }
                .buttonStyle(.plain)
                .accessibilityLabel(day.formatted(date: .complete, time: .omitted))
                .accessibilityAddTraits(isOn ? .isSelected : [])
            }
        }
        .padding(8)
        .frostedSheet(.under, radius: 28)
    }
}

/// Small floating glass capsule at the bottom: the AI or quick-add entry point.
struct PromptCapsule: View {
    @Binding var text: String
    var placeholder: String
    var onSubmit: () -> Void
    @Environment(\.palette) private var palette

    var body: some View {
        HStack(spacing: 10) {
            TextField(placeholder, text: $text)
                .font(.subheadline)
                .submitLabel(.send)
                .onSubmit(onSubmit)
            Button(action: onSubmit) {
                Image(systemName: "arrow.up")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(palette.onPrimary)
                    .frame(width: 32, height: 32)
                    .background(palette.primary, in: .circle)
            }
            .accessibilityLabel("Send")
        }
        .padding(.leading, 18)
        .padding(.trailing, 6)
        .frame(minHeight: 44)
        .glassEffect(.regular.interactive(), in: .capsule)
    }
}

// MARK: - Sample: the style board's day phone

struct TasteSampleScreen: View {
    @Environment(\.palette) private var palette
    @State private var day = Date.now
    @State private var prompt = ""

    private var week: [Date] {
        let start = Calendar.current.dateInterval(of: .weekOfYear, for: .now)?.start ?? .now
        return (0..<7).compactMap { Calendar.current.date(byAdding: .day, value: $0, to: start) }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                HStack(alignment: .top) {
                    TwoToneTitle(
                        primary: "Today",
                        secondary: Date.now.formatted(.dateTime.weekday(.abbreviated).month(.abbreviated).day())
                    )
                    Spacer()
                    GlassIconButton(systemImage: "slider.horizontal.3", label: "Filters") {}
                }
                .padding(.horizontal, 10)
                .padding(.bottom, 4)

                VStack(spacing: -26) {
                    HStack(spacing: 10) {
                        ProgressRing(progress: 0.62, tint: palette.ink).frame(width: 16, height: 16)
                        Text("Overall progress")
                        Spacer()
                        Text(0.62, format: .percent.precision(.fractionLength(0))).monospacedDigit()
                    }
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(palette.ink)
                    .padding(.horizontal, 18).padding(.top, 14).padding(.bottom, 40)
                    .frostedSheet(.back)

                    VStack(alignment: .leading, spacing: 8) {
                        Text("Today's focus").eyebrow()
                        Text("Ship the onboarding flow")
                            .font(.title2.weight(.semibold))
                            .tracking(-0.4)
                            .foregroundStyle(palette.ink)
                            .padding(.top, 8)
                        Text("Final pass on the questionnaire screens, then send the build to TestFlight.")
                            .font(.footnote)
                            .foregroundStyle(palette.ink2)
                        HStack {
                            Button {} label: { Label("Start task", systemImage: "play.fill") }
                                .buttonStyle(.primaryPill)
                            Spacer()
                            Label("2h", systemImage: "clock")
                                .font(.footnote.monospacedDigit())
                                .foregroundStyle(palette.ink2)
                        }
                        .padding(.top, 14)
                    }
                    .padding(18)
                    .frostedSheet(.front)
                    .zIndex(2)

                    HStack(spacing: 6) {
                        Text("Next up").foregroundStyle(palette.ink2)
                        Text("Paywall copy review").fontWeight(.semibold).foregroundStyle(palette.ink)
                    }
                    .font(.footnote)
                    .padding(.horizontal, 18).padding(.top, 38).padding(.bottom, 14)
                    .frostedSheet(.under)
                    .zIndex(1)
                }

                WeekStrip(days: week, selection: $day, marked: Set(week.prefix(5)))
            }
            .padding(.horizontal, 12)
            .padding(.bottom, 24)
        }
        .tasteScroll()
        .tasteScreen()
        .safeAreaBar(edge: .bottom) {
            PromptCapsule(text: $prompt, placeholder: "Plan my afternoon", onSubmit: {})
                .padding(.horizontal, 64)
                .padding(.bottom, 8)
        }
        .tint(palette.accent)
    }
}

#Preview("Steel") { TasteSampleScreen() }
#Preview("Graphite") { TasteSampleScreen().environment(\.palette, .graphite) }
#Preview("Midnight") { TasteSampleScreen().environment(\.palette, .midnight) }
