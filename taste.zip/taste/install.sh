#!/bin/sh
# Installs the taste skill for Claude Code (and Codex, if it's installed) and links the global rules.
# Run it from a clone at ~/.claude/skills/taste, or from an unzipped taste folder anywhere.
set -e

SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/.claude/skills/taste"
TARGET="$HOME/.claude/CLAUDE.md"
STAMP="$(date +%Y%m%d-%H%M%S)"
# Backups live outside ~/.claude/skills so Claude never loads a second copy of the skill.
BACKUP="$HOME/.claude/backups/taste-$STAMP"

mkdir -p "$HOME/.claude/skills"

if [ "$SRC" != "$DEST" ]; then
  if [ -e "$DEST" ]; then
    mkdir -p "$BACKUP"
    mv "$DEST" "$BACKUP/skill"
    echo "Old skill backed up to $BACKUP/skill"
  fi
  cp -R "$SRC" "$DEST"
fi

# The companion skills (app-strategy, app-marketing) live inside this folder; link each one next to it.
for SUB in "$DEST"/skills/*/; do
  [ -f "$SUB/SKILL.md" ] || continue
  NAME="$(basename "$SUB")"
  LINK="$HOME/.claude/skills/$NAME"
  if [ -e "$LINK" ] && [ ! -L "$LINK" ]; then
    mkdir -p "$BACKUP"; mv "$LINK" "$BACKUP/$NAME"; echo "Old $NAME backed up to $BACKUP/$NAME"
  fi
  ln -sfn "${SUB%/}" "$LINK"
  COMPANIONS="$COMPANIONS $NAME"
done

# Claude Code: the global rules load in every terminal, and they tell Claude to use the skills.
if [ -e "$TARGET" ] && [ ! -L "$TARGET" ]; then
  mkdir -p "$BACKUP"
  cp "$TARGET" "$BACKUP/CLAUDE.md"
  echo "Old global CLAUDE.md backed up to $BACKUP/CLAUDE.md"
fi
ln -sfn "$DEST/global-CLAUDE.md" "$TARGET"

# Codex (optional): it already finds skills in ~/.claude/skills; give it the same global rules.
if [ -d "$HOME/.codex" ]; then
  CODEX_RULES="$HOME/.codex/AGENTS.md"
  if [ -e "$CODEX_RULES" ] && [ ! -L "$CODEX_RULES" ]; then
    mkdir -p "$BACKUP"
    cp "$CODEX_RULES" "$BACKUP/AGENTS.md"
    echo "Old Codex AGENTS.md backed up to $BACKUP/AGENTS.md"
  fi
  ln -sfn "$DEST/global-CLAUDE.md" "$CODEX_RULES"
  mkdir -p "$HOME/.agents/skills"
  [ -e "$HOME/.agents/skills/taste" ] || ln -s "$DEST" "$HOME/.agents/skills/taste"
  for NAME in $COMPANIONS; do [ -e "$HOME/.agents/skills/$NAME" ] || ln -s "$DEST/skills/$NAME" "$HOME/.agents/skills/$NAME"; done
  CODEX_DONE="yes"
fi

echo "Done."
echo "  Skill:        $DEST"
[ -n "$COMPANIONS" ] && echo "  Companions:  $COMPANIONS (linked next to it)"
echo "  Global rules: $TARGET -> $DEST/global-CLAUDE.md"
[ -n "$CODEX_DONE" ] && echo "  Codex:        ~/.codex/AGENTS.md -> $DEST/global-CLAUDE.md, ~/.agents/skills/taste"
echo "Open a new Claude terminal to use it."
