# Organic launch, ratings and posts

- **Short videos and creator (UGC) videos first** in a crowded niche: real people showing the core moment. App blockers grew this way (Brick, Pushscroll, touch grass).
- **Reddit:** post the real story and real numbers, and ask for feedback. Answer every comment calmly and specifically, without arguing. Never post fake reviews or sock-puppet comments.
  - **Read each subreddit's rules first** (`/r/<sub>/about/rules.json`). Checked October 2026: the subreddits of the target users (r/nosurf, r/digitalminimalism, r/productivity, r/selfimprovement, r/getdisciplined, r/GetStudying) ban app posts and ban the poster. App posts are allowed in r/iosapps (the monthly App Shelf megathread in Answer/Better/Cost format, unless the app has 20+ ratings), r/SideProject, r/indiehackers (once, Self Promotion flair), r/studytips (with real tips first) and r/EntrepreneurRideAlong. r/apple bans giveaways; r/AppHookup needs 500+ lifetime codes.
  - **Apps built mainly with AI code:** say so where a subreddit asks (r/iosapps flair "Vibe Coded"; r/ProductivityApps bans them).
  - **One post a day, each in its own words, from one account.** The same link in five subreddits within an hour reads as spam. Codes go by private message, never in public comments.
- **The first honest ratings:**
  - friends;
  - free codes for the first 25 people in the target group, in exchange for feedback;
  - the in-app rating prompt after the first real success.

  Never condition a gift on a review. A page with 0 ratings looks abandoned.
- **A giveaway** (free lifetime codes) gets feedback and first users. Say what you want from them (what confused them, what they'd change).
- **Show you care:** a real founder story, a support page, timely updates and fast replies. People assume a vibe-coded app gets abandoned.
- **Never publish strangers' apps on your developer account**, however the split is offered. It puts every app on that account at risk.
