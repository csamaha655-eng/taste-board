#!/bin/sh
# Run after every push: sh package.sh
# 1. Builds taste.zip (a taste/ folder, the layout claude.ai and Claude Code expect) from the last commit:
#    every file in the repo, the bought guides included (the owner's own downloads, 2026-10-11).
#    Publishes it as the "latest" release of the private repo, with the two companion skills as their own
#    zips for claude.ai. Copies land in ~/Downloads.
# 2. Publishes the style board to the public taste-board repo (GitHub Pages,
#    https://csamaha655-eng.github.io/taste-board/), with the same taste.zip behind its Download button,
#    so the board and GitHub always hold the same version.
set -e

ROOT="$(cd "$(dirname "$0")" && pwd)"
REPO="csamaha655-eng/claude-taste"
BOARD="csamaha655-eng/taste-board"
REV="$(git -C "$ROOT" rev-parse --short HEAD)"
TMP="$(mktemp -d)"
if [ -n "$(git -C "$ROOT" status --porcelain)" ]; then echo "Uncommitted changes: commit and push first, so the zip matches GitHub."; exit 1; fi

mkdir "$TMP/taste"
git -C "$ROOT" archive HEAD | tar -x -C "$TMP/taste"
(cd "$TMP" && zip -r -q -X taste.zip taste -x "*.DS_Store")
# The two companion skills as their own zips (claude.ai takes one skill per upload).
for NAME in app-strategy app-marketing; do
  mkdir -p "$TMP/c/$NAME" && cp -R "$TMP/taste/skills/$NAME/." "$TMP/c/$NAME/"
  (cd "$TMP/c" && zip -r -q -X "../$NAME.zip" "$NAME" -x "*.DS_Store")
done
mkdir -p "$HOME/Downloads" && cp "$TMP/taste.zip" "$TMP/app-strategy.zip" "$TMP/app-marketing.zip" "$HOME/Downloads/"
echo "Copies in ~/Downloads: taste.zip (everything), app-strategy.zip, app-marketing.zip"

gh release delete latest --repo "$REPO" --yes --cleanup-tag >/dev/null 2>&1 || true
gh release create latest "$TMP/taste.zip" "$TMP/app-strategy.zip" "$TMP/app-marketing.zip" --repo "$REPO" --target main \
  --title "Latest skill" --latest \
  --notes "Built from $REV. Unzip taste.zip and run sh taste/install.sh, or upload it on claude.ai." >/dev/null
echo "Published taste.zip ($REV) to the latest release of $REPO"

gh repo clone "$BOARD" "$TMP/board" -- -q
WEB="$TMP/taste/assets/web"
python3 - "$WEB/specimen.html" "$TMP/board/index.html" "$REV" <<'PY'
import sys
html = open(sys.argv[1]).read()
meta = '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">'
html = html.replace(meta, meta + '\n<meta name="robots" content="noindex, nofollow">', 1)
html = html.replace('<span class="rev">this version</span>', f'<span class="rev">commit {sys.argv[3]}</span>', 1)
open(sys.argv[2], 'w').write(html)
PY
cp "$WEB/tokens.css" "$WEB/stipple.js" "$TMP/board/"
cp "$TMP/taste.zip" "$TMP/app-strategy.zip" "$TMP/app-marketing.zip" "$TMP/board/"
echo "$REV" > "$TMP/board/version.txt"
if [ -n "$(git -C "$TMP/board" status --porcelain --untracked-files=all)" ]; then
  git -C "$TMP/board" add -A
  git -C "$TMP/board" -c user.name="charbel" -c user.email="csamaha27@ic.edu.lb" \
    commit -q -m "Update the style board from claude-taste $REV"
  git -C "$TMP/board" push -q
  echo "Style board updated: https://csamaha655-eng.github.io/taste-board/ (live in about a minute)"
else
  echo "Style board already up to date: https://csamaha655-eng.github.io/taste-board/"
fi

rm -rf "$TMP"
