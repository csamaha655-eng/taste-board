---
name: taste
description: The owner's design and building skill, used automatically for every app and website he builds (mostly native SwiftUI iOS apps and their sites). Premium, calm, light by default; native Liquid Glass; solid colors, never gradients; product websites copy spacefs.com (about 90%, white glass, its menu and gentle parallax); clothing brands follow a black-and-white store blueprint; every site works on phones and is tested first; zero AI slop, checked against what real users called AI-made. Use whenever the owner asks for a new app or website, or designs, builds, redesigns or polishes anything user-facing: a SwiftUI app or screen, onboarding, paywall, widget, website, landing page, web app, dashboard, store screenshots, icon or logo; when choosing colors, fonts, layout or motion; before any App Store submission; and when he shares a design reference. Companion skills: app-strategy (ideas, saturation, model, prices) and app-marketing (only when he asks). Skip for backend, build errors, data or logic-only work.
---

# Taste

The owner builds native iOS apps (SwiftUI, iOS 26+, Liquid Glass, XcodeGen, RevenueCat paywalls, widgets) and the web around them: a landing and legal site for each app, sometimes a full web app. Everything must feel premium and expensive: calm, restrained and full of real content. Never maximalist, never generic, never "AI slop".

This skill is for **building**: how things look, read and flow, including what about 85 strangers taught the owner about design when one of his apps launched (`references/real-users.md`). Two companion skills keep it focused: `app-strategy` (is the idea worth building, the business model, prices, the numbers, weighing feedback) and `app-marketing` (store words, ads and posts, only when he asks).

**What are you building? Read the matching blueprint** (one skill, several blueprints, so the laws stay shared and only the right blueprint is read):

| Building | Read |
|---|---|
| An iOS app | `references/ios.md` (+ `app-launch.md` for onboarding, the paywall screen and store visuals) |
| A website or web app for a product, or a site with no style named | `references/spacefs.md` (+ `web.md`) |
| A clothing, streetwear or fashion brand store | `references/fashion.md` (+ `web.md`) |
| Any other kind of site (a restaurant, a portfolio, travel) | `references/themes.md` and the matching brief in `library/` (+ `web.md`) |
| Parallax, scroll stories, 3D, a turning product | the recipes in `web.md`, inside whichever blueprint applies |

Every website must work on phones and pass `web.md`, "Before you hand over any website", before the owner sees it.

**iOS apps are always native SwiftUI.** Never React Native, Expo, Flutter, Capacitor, Ionic or a web view wrapped as an app. Use UIKit only for an API SwiftUI lacks, wrapped in `UIViewRepresentable`.

## Who decides

1. **The owner's newest words.** They override earlier rules and this file. Prompts are often dictated, so names get mangled ("Open"/"Opel" = Opal, "Zwift" = Swift, "liquid class" = Liquid Glass, "Space FS" = spacefs.com).
2. **The project's own design system** (its CLAUDE.md, `Theme.swift`, site CSS). An existing app keeps its look unless the owner asks for a change. Apply the laws below inside that system, and if it carries AI-slop tells (`anti-slop.md`), name them in one line so he can decide.
3. **This skill's defaults.**

## The ten laws

1. **Rich, never busy. Calm, never empty.** Every screen is full of real, purposeful content: data, imagery, the product itself. No dead bands, lone elements or "20% of the screen for no reason". No clutter either: no sprinkled badges, no info overload. Premium means less chrome, not less substance.
2. **No gradient colors. Ever.** Fills are solid. No color-to-color blends on buttons, text, icons, cards, borders, rings, progress bars or backgrounds. The exact rule and its few allowances are in `references/anti-slop.md`.
3. **One accent at most.** Ink, one quieter gray, hairlines and a canvas do the work. The primary action is an ink-black pill on light themes and a white pill on dark ones. The accent is for selection, links, focus and state, and words in the accent need 4.5:1 contrast. Pick it from the accent library in `references/themes.md`. Never purple or violet, neon, or generic SaaS blue: strangers read those as AI-made (the full list is under "Looks that read as AI-made").
4. **Glass is the navigation layer.** On iOS, native Liquid Glass goes on tab bars, toolbars and floating controls, and text sits on the readable frosted sheets of the app design (or on solid cards). On the web, glass goes on the floating nav, menus, popovers, prompt capsules and cards that float over imagery. Never on every box.
5. **Bold, never skinny.** One typeface per product (SF Pro on iOS; one family on the web). Headings 500-700, body 400 at 15-17 px or larger. Never Thin or Light, and never tiny gray text people must read. Tight tracking on big type. Signature move: the two-tone headline, line one in ink and line two in gray.
6. **Depth from light, not color.** Hairline rings (0.5-1 px), soft layered shadows with negative spread, a faint inner top highlight. No heavy drop shadows, neon glows or bevels.
7. **Real craft over decoration.**
   - **Mockups and data:** pixel-faithful product mockups and real numbers. No lorem, no fake stats or testimonials, no emoji (SF Symbols or one line-icon set).
   - **Images:** real photos (licensed or made for the product, with credits kept) or flat marks drawn in code. Never decorative rendered 3D, metal or glossy objects, coins, medals, glowing art or generic stock: strangers read all of these as AI-made. The one exception is an interactive 3D model of the actual product, when the owner asks for it. Never use the owner's personal photos unless he hands them over for that use.
   - **Words:** plain words a 10-year-old understands, saying who does what. Never a metaphor the reader must decode, never motivational filler, one consistent term for each concept everywhere.
   - **Facts:** never invent features, prices, stats, reviews, names or links; take them from the app's code or ask. Sample content inside a product mockup (a task, a date, a habit) may be realistic. Anything unknown gets a visible placeholder ([PRICE]) listed under "To replace" when you show the work.
8. **Quiet, physical motion.** Ease-out (`cubic-bezier(.22,1,.36,1)`) or iOS springs, 160-560 ms (spacefs's 1.1 s hero-rise on load is the one longer exception). Hover nudges, numeric transitions, scroll-driven reveals; at most one orchestrated moment per page. No animated splash screens, confetti, bouncing, typing effects or scroll-jacking. Respect Reduce Motion. Default motion is spacefs's:
   - start-visible reveals;
   - the gentle hero drift;
   - the menu that grows from a pill;
   - on a product site, its one sticky product story.

   Heavier parallax, more scroll storytelling or 3D only when the owner asks ("parallax", "3D", "like Apple") or a photo-led subject needs it (travel, fashion, places). "Not scrolling" means quiet.
9. **Seamless scrolling.** No bands or blocks that appear on scroll, no black overscroll, no visible scroll indicators on iOS, no images cropped at the top or bottom, no logos sitting in white boxes, no art that looks pasted on with visible edges.
10. **Light by default; the theme follows the subject.** Strangers read a dark app lit by colored glow as AI-made. Dark follows the dark rule in `references/themes.md`: only when the owner asks, or for a product used mostly in a dark room, and always flat.
    - **Websites:** follow the order in `references/themes.md`, "Websites: pick in this order": a named style; a product (spacefs, about 90%, white glass); a clothing brand (`fashion.md`); a subject with its own world (its brief and photography); anything unclear (spacefs). Parallax, 3D or dark when asked, with spacefs's tokens around it. Every site works on phones as well as desktop.
    - **iOS apps:** every app uses the style board's phone design (two-tone header, stacked frosted sheets, black pill, glass strip, prompt capsule), and only the palette changes: Steel, Graphite, Paper, Photo or the app's own light hue. Under the dark rule it is Graphite night; Midnight only when he names the night phone (`references/themes.md`, "iOS apps"). The strip and the capsule always carry a real function of the app (week, filters, categories; search, quick add, AI). Never ship a dead control just to match the look.

**Calibration:** spacefs.com is the owner's favorite website ("I love, love, love it"). The style board in `assets/web/specimen.html` is his working demonstration of every component ("it's so nice, I love it"). Together they are the quality bar for every page. The owner's own past apps are not design references.

## Workflow

**0. A new app idea:** run `app-strategy` first (its `references/idea.md`); build only after its verdict says Build or Build with a twist, or when he says "just build it". "Start building" with no design named means: don't ask design questions; use the defaults here and `references/app-launch.md` for the onboarding, paywall screen and store page.

For any UI task:
1. **Brief.** For a new product or a redesign, write it in your plan:
   - the subject and audience;
   - the chosen theme and why;
   - the one accent, and light (dark only under the dark rule);
   - the sections and the hero moment;
   - what moves and why, and what to avoid;
   - the one-sentence answer to "what does it do?" that the first screen must pass.

   For a product website, start from `references/spacefs.md`; for a clothing brand, `references/fashion.md`. For any other kind of site, first check `library/INDEX.md` for the matching industry brief and borrow its story and sections, not its look. Decide; the owner delegates taste calls ("you pick, I want the best"). When the owner names no theme or design, apply the order in `references/themes.md`, pick the accent and motion level by subject, say it in one line, and build without asking. Ask only when his own words conflict.
2. **Load only what you need.** The owner dislikes tokens spent on irrelevant context.
   - `references/real-users.md`: the evidence behind the rules; read it when starting a new app, when a choice feels like taste against evidence, and when adding new feedback
   - `references/app-launch.md`: any new app, onboarding, the paywall screen, store screenshots and icon, and before every submission (the business model and prices come from `app-strategy`)
   - `references/web.md`: any website or web app (it includes a full Quiet Glass spec for web apps: shell, tables, forms, plans and billing)
   - `references/ios.md`: SwiftUI, and HTML mockups of iOS screens
   - `references/fashion.md`: every clothing or fashion brand store (the reference store's system, drawers, product card and page, cart; the turning-product effect on request)
   - `references/spacefs.md`: every product website (the page, section by section; the menu that grows from a pill into a glass panel; the hero parallax; the phone layout)
   - `references/themes.md`: choosing or applying a theme; the website order; the dark rule; the accent library; colors that work together; the palettes that read as AI-made
   - `references/anti-slop.md`: always, before showing anything
   - `references/logo.md`: whenever a logo or app icon is needed and the owner hasn't given one (the spacefs-style mark)
   - `references/inspiration.md`: analyzing or recalling references
   - `library/INDEX.md`: extra examples the owner bought (50 industry site briefs, 20 effects, parallax/3D/scroll recipes, quality tests). Use it for a subject or effect the themes don't cover. Grep the `.txt` copies for the page you need; never read a whole PDF. It is reference only: the themes win, and its gradients and gimmicks are banned.
   - Starters: `assets/web/tokens.css` (spacefs's measured values), `assets/web/stipple.js`, `assets/ios/Theme.swift`. `assets/web/specimen.html` is the working style board (tokens, the spacefs menu, cards, rows, pricing, parallax). Where it differs from the spacefs measurements in `spacefs.md` and `web.md`, the measurements win. `assets/web/site-check.mjs` tests a site before it is shown.
3. **Build in phases**, screen by screen or section by section. Don't one-shot a whole app.
4. **Look before you show.** Take real screenshots and inspect them at full size: the Simulator for iOS (`xcrun simctl io booted screenshot`), a headless browser for the web at 1440 and 390 wide (every website must work on phones: no horizontal scroll, a working menu, readable type, 44 px targets), light and dark, at rest and mid-scroll. Look at every screen, sheet and state, not only the main ones: old art hides in sheets. Run the checklist in `references/anti-slop.md` and fix what fails.
5. **Show it short.** Before/after screenshots when an existing screen changed, 2-3 plain lines that lead with the verdict, and exactly what to check on the device. No long reports, no emoji, no exclamation marks. Before any App Store submission, send the owner the contact sheet of every screen (`references/app-launch.md`, "Before every submission").
6. **Change one thing at a time.** Freeze what already works, fix the single biggest problem, compare, repeat. Stop when it's clear, consistent, fast and works on phones; endless regeneration makes it worse.
7. **Never worse than before.** When redesigning, compare against the screen as it was. Wherever the old one wins, keep that part. Don't strip things the owner liked because a critic called them busy.

## New references

When the owner sends a site, a Dribbble shot or app screenshots, capture it (screenshots; CSS tokens for a website) and add an entry to `references/inspiration.md`: what makes it premium, which theme it feeds (or a new theme in `themes.md`), and what never to copy. Take layout and quality. Never copy words, names, art or signature objects: App Store guideline 4.1 (copycats), and the owner's own rule, "don't copy it 100%".

The two exceptions, on the owner's word (2026-10-11): spacefs.com for product sites and reframedclothing.com for clothing brands. Their design systems are copied closely (about 90%), never their content, logos or photos.

## Learning from feedback (keep this skill growing)

When he shares outside feedback (comments, reviews, testers' notes, rejections, his own reaction on a device), weigh it with `app-strategy`'s `references/feedback.md`: keep only what is specific and backed by data, several independent people or known good practice, and what serves his goal (premium apps that make money). Ignore advice that breaks the laws, sales pitches and "make it free". Apply what holds to the current project, write the concept (never the quote) into the right file, prefer sharpening a rule to adding one, then commit, push and run `package.sh`, and tell him in one line what was learned and what was ignored.

## Backup

This folder is the owner's private GitHub repo `csamaha655-eng/claude-taste`, and `~/.claude/CLAUDE.md` is a link to `global-CLAUDE.md` in it, so every new Claude Code terminal reads the global rules and knows to use this skill.

After changing anything here, or the global rules, commit and push, then run `sh package.sh`. The owner asked for this backup to stay current. The script rebuilds `taste.zip` from the last commit (every file, the bought guides included) and publishes the same file to the private repo's latest release and behind the Download button of the live style board at https://csamaha655-eng.github.io/taste-board/ (public repo `taste-board`, hidden from search), so GitHub and the board always hold the same version.

To install on a new machine, follow `README.md`.
