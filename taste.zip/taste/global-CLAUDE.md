# Platforms

iOS apps are always native SwiftUI (Swift 6, iOS 26+, Liquid Glass). Never React Native, Expo, Flutter, Capacitor or a web view wrapped as an app. UIKit only for an API SwiftUI lacks.

# The owner's skills: used automatically, never asked for

Three skills live in `~/.claude/skills`. Load them without being asked:
- **`taste` (design and building):** a new app or website; any screen, onboarding, paywall screen, widget, website, store screenshot, icon or logo; colors, fonts, layout or motion; before any App Store submission. Skip it for backend, build errors, data or logic-only work with no user-facing effect.
- **`app-strategy` (the business side):** a new app idea or "is it saturated?"; the paywall type or prices; launch or funnel numbers; "keep going or stop?"; outside feedback to weigh.
- **`app-marketing` (ads, store words, posts):** only when the owner asks about marketing, ads, App Store search, launch posts or growth. Never while just building.

**What happens automatically:**
- **A new app idea:** research it first (`app-strategy`, `references/idea.md`): competitors, the free alternative, whether it's saturated, the one difference. Send a one-screen verdict. If he asked to create the app, build on "Build" or "Build with a twist" and stop on "Don't build"; if he only asked a question, answer with the verdict; "just build it" skips the research.
- **"Start building", or any app or site with no design named:** don't ask design questions. Choose the theme, layout, accent and motion yourself by subject, state the choice in one line and build. Missing content (names, prices, photos) gets marked placeholders, listed at the end.
- **A website:** follow the taste skill's order (`references/themes.md`, "Websites: pick in this order"):
  - a style he names;
  - **a product** (an app, a tool, a download page, a SaaS, a web app), or anything unclear: spacefs.com, about 90% copied (`references/spacefs.md`): white glass, its type and spacing, the three-piece nav, the Menu pill that grows into a glass panel, the gentle hero parallax, its pills, cards, pricing and FAQ. Never its words or logo. An app's own site adds the app rules in `references/web.md`, "App site";
  - **a clothing or fashion brand:** `references/fashion.md` (black and white, blurred see-through glass, drawers, product cards, cart). He gives the name, logo, products and prices: no market research for a brand site;
  - **a subject with its own world** (a restaurant, travel, a portfolio): its industry brief in `library/` and real photography, with spacefs's tokens and nav;
  - parallax, 3D or dark when he asks, with spacefs's tokens around it.
- **Before showing any website:** it works on phones as well as desktop. Read every line you wrote, run `assets/web/site-check.mjs` (it clicks every button and reports errors, broken links, overflow and small targets at 390 and 1440 px), fix what it finds, and walk the main flows (`references/web.md`, "Before you hand over any website").
- **Before any App Store submission:** capture and look at every screen, sheet and state, not just the main tabs, and send the owner the contact sheet.
- **Outside feedback:** weigh every comment with `app-strategy`'s `references/feedback.md`. Keep only what is specific and backed by data, several independent people or good practice; ignore advice that breaks these rules, sales pitches and "make it free" (he builds apps to make money). Write the concept, never the quote, into the right skill, then commit, push and run `package.sh`.

## The core, in case nothing else is loaded

**Look**
- **Overall:** premium, calm, minimal glassmorphism. Full of real content, never busy and never empty.
- **Light by default.** Dark only when the owner asks, or for a product used mostly in a dark room (sleep, astronomy, cinema; never focus, screen time, finance or "premium"), and then flat, with no glow. Strangers read a dark app lit by colored glow as AI-made.
- **No gradients, ever:** no color-to-color blends on anything. Solid colors, one accent at most, and an ink-black pill for the main action.
- **Never the AI-made palettes** (full list in `references/themes.md`): purple or violet as the brand color, a dark ground lit by colored glow, neon on black, glass over colorful blobs, cream-serif-terracotta "premium", generic SaaS blue as the whole brand. The accent comes from the skill's accent library: a deep, calm hue picked by the subject, readable as text.
- **Type:** one typeface per product, bold not skinny (headings 500-700). Never Thin or Light, and no tiny gray text people must read. Signature move: a two-tone headline, line one in ink and line two in gray.
- **Glass:** for navigation and floating controls. On iOS, native Liquid Glass bars, with text on readable frosted sheets or solid cards, never thin clear glass.
- **Images:** real photos (licensed, credits kept) or flat marks drawn in code. Never decorative rendered 3D, metal or glossy coins and medals, glowing art or generic stock. Never the owner's personal photos unless he gives them for that use.

**Words:** plain words a 10-year-old understands, saying who does what. Never a metaphor the reader must decode ("the gate", "the toll"). No hype or motivational filler, one term for each concept, and errors that say what to do.

**Clarity:** from the icon, the name and the first screen (or first store screenshot, or hero), a stranger can say what it does within 2 seconds.

**Never:** emoji in the UI; fake stats or testimonials; animated splash or loading screens, confetti, typing effects; bands that appear when scrolling.

**iOS apps (always the same design).** Every app looks like the style board's day phone (the night phone only when he names it):
- a two-tone header over one soft atmosphere;
- stacked frosted sheets;
- a black pill;
- a glass week or filter strip and a floating capsule at the bottom, when the app has a real use for them; never a dead control.

Only the colors change, by subject or by the owner: Steel blue, Graphite (grey, black and white), Paper, Photo, or the app's own light hue. Start from the skill's `assets/ios/Theme.swift`.

**An app that converts** (full rules in the taste skill's `references/app-launch.md`; the model and prices in `app-strategy`, a paywall from day one):
- **Onboarding:** at most 4 tap-only screens before the paywall. Screen 1 says what it does and answers the free alternative; then an interactive demo of the core result. Each permission is asked when its purpose is clear, with a primer.
- **The paywall screen:** the billed amount is the largest price; the trial only for eligible users; never "free" on the button.
- **Store visuals:** light screenshots with big captions about the outcome; frame 1 is the core moment, understood without the title, never a zero state.
- **Analytics** on every screen from the first build; a rating ask only after the first real success.

**Web stack:** a one-page site in plain HTML/CSS/JS; a multi-page site in Astro; a web app in Vite + React + TypeScript, or Next.js. Start from the skill's `assets/web/tokens.css` (spacefs's measured values). The hero says what it is in plain words, for whom, and the difference.

**Motion:** calm by default: hover nudges, start-visible reveals, the gentle hero drift, the menu that grows from a pill, and on product sites one sticky product story. Heavier parallax, scroll storytelling and 3D only when asked or for photo-led subjects.
- Every animation has a job (guide attention, explain, give feedback or create depth); otherwise cut it.
- One motion language and one big moment per page.
- The page must look finished with all motion off, and 3D must explain the product and never be required.
- Nothing depends on hover on phones, and Reduce Motion means static.

**Website ideas and effects library:** `~/.claude/skills/taste/library/INDEX.md` (the owner's bought guides: 50 industry site briefs, 20 effects, parallax, 3D and scroll recipes). Find the matching brief or effect, read only that part and rebuild it in the chosen theme. Its gradients, glows and gimmicks are banned.

**Logos and icons:** if the owner gives none, follow the skill's `references/logo.md`.
- **An app icon** shows what the app does (a padlock for a locker; the initial can live inside the object), drawn flat: one ink color on one solid ground, bold simple shapes, readable at 16 px. Blind-test it before it ships: an image model or a person who sees only the icon must say what the app does.
- **A website or company mark** may use the spacefs-style mark: two bold organic shapes, often rotated 180° from each other, with the letter in the negative space. Never a copy.

**Who wins:** the owner's newest words beat everything. A project's own CLAUDE.md design rules win inside that project.
