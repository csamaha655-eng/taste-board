# Platforms

iOS apps are always native SwiftUI (Swift 6, iOS 26+, Liquid Glass). Never React Native, Expo, Flutter, Capacitor or a web view wrapped as an app. UIKit only for an API SwiftUI lacks.

# The taste skill: used automatically, never asked for

The owner's design language and app-shipping playbook is the `taste` skill (`~/.claude/skills/taste`). Load it without being asked whenever the task is any of these:
- a new app or website;
- an app idea or market question ("is it saturated?", "should I build this?");
- any screen, onboarding, paywall, price, widget, website, App Store page, screenshot, icon or logo;
- any App Store submission;
- outside feedback to learn from (Reddit comments, reviews, testers).

Skip it for backend, build errors, data or logic-only work with no user-facing effect.

**What happens automatically:**
- **A new app idea:** research first (`references/app-idea.md`): competitors, the free alternative, whether it's saturated and the one difference. Send a one-screen verdict.
  - If he asked to create the app, build when the verdict is "Build" or "Build with a twist", and stop when it is "Don't build".
  - If he only asked a question ("is it saturated?"), answer with the verdict and don't build.
  - If he says "just build it", skip the research.
- **"Start building" with no design named:** don't ask design questions. iOS gets the style-board phone design in a light palette chosen by subject, plus the onboarding, paywall and store rules in `references/app-launch.md`. State the choice in one line and build.
- **A website:** spacefs.com's design copied exactly, whatever the subject (Quiet Glass: its type scale, colors, spacing, nav, pills and glass cards; never its words or logo). The subject alone never switches the theme or adds parallax, 3D or dark. Only when the owner asks for one of those, use that recipe with spacefs's tokens and type around it.
- **Before any App Store submission:** capture and look at every screen, sheet and state (not just the main tabs), send the owner the contact sheet, then submit.
- **Outside feedback:** read every comment. Apply what holds to the project. Write the concept (never the quote) into the skill. Commit, push and run `package.sh`.

## The core, in case nothing else is loaded

**Look**
- **Overall:** premium, calm, minimal glassmorphism. Full of real content, never busy and never empty.
- **Light by default.** Strangers read a dark app lit by colored glow as AI-made, and light screenshots won more impressions. Dark only when the owner asks, or for a product used mostly in a dark room (sleep, astronomy, cinema; never focus, screen time, finance or "premium"), and then flat, with no glow.
- **No gradients, ever:** no color-to-color blends on anything. Solid colors, one accent at most, and an ink-black pill for the main action.
- **Never the AI-made palettes:**
  - purple or violet as the brand color;
  - a dark ground lit by colored glow;
  - neon or acid green, cyan or magenta on black;
  - glass over colorful blobs;
  - cream, serif and terracotta "premium";
  - generic SaaS blue as the whole brand.

  The accent comes from the skill's accent library (`references/themes.md`): deep, calm hues picked by the subject, readable as text.
- **Type:** one typeface per product, bold not skinny (headings 500-700; the one exception is a website hero at 400, as spacefs sets it). Never Thin or Light, and no tiny gray text people must read. Signature move: a two-tone headline, line one in ink and line two in gray.
- **Glass:** for navigation and floating controls. On iOS, use native Liquid Glass bars, and put text on readable frosted sheets or solid cards, never thin clear glass.
- **Images:** real photos (licensed, credits kept) or flat marks drawn in code. Never decorative rendered 3D, metal or glossy coins and medals, glowing art or generic stock: strangers read them as AI-made. Never the owner's personal photos unless he gives them for that use.

**Words**
- Plain words a 10-year-old understands, saying who does what.
- Never a metaphor the reader must decode ("the gate", "the toll").
- No hype or motivational filler, one consistent term for each concept, and errors that say what to do.

**Clarity**
- From the icon, the name and the first screen (or first store screenshot, or hero), a stranger can say what it does within 2 seconds.

**Never**
- emoji in the UI, fake stats or testimonials;
- animated splash or loading screens, confetti, typing effects;
- bands that appear when scrolling.

**Themes by subject**
- **Websites and web apps:** always Quiet Glass, which is spacefs.com, whatever the subject. Parallax Journey (photos and parallax) only when the owner asks for it. Nocturne (dark) only when asked.
- **iOS apps:** the style-board design (Atmos Glass layout) in a light palette chosen by subject.

**iOS apps (always the same design)**

Every app looks like the style board's day phone (the night phone only when he asks for dark):
- a two-tone header over one soft atmosphere;
- stacked frosted sheets;
- a black pill;
- a glass week or filter strip, and a floating capsule at the bottom, when the app has a real use for them (days, filters, search, quick add, AI); never a dead control.

Only the colors change, chosen by subject or by the owner: Steel blue, Graphite (grey, black and white), Paper, Photo, or the app's own light hue. Midnight is for when he asks for dark. Start from the skill's `assets/ios/Theme.swift`.

**Shipping an app** (full rules in `references/app-launch.md`)
- **Onboarding:** at most 4 tap-only screens before the price. Screen 1 says what it does and answers the free alternative; then an interactive demo of the core result.
- **Paywall (default for a subscription app):** a hard paywall with a 7-day trial on the annual plan, adjusted to the app's market. The billed amount is the largest price. The trial is shown only to eligible users, and "free" never appears on the button.
- **Permissions:** each asked when its purpose is clear, with a primer. If the product is useless without one, make sure it can be granted before taking money, or give a clear refund path.
- **First real use:** the first real action on day 0. Ask for a rating after the first success.
- **Analytics:** on every screen from the first build.
- **Prices:** set from competitors and value, never a generic ladder. A starting point for a subscription app with no ratings: about $29.99 a year, $5.99 a month and $79.99 lifetime. Set euro prices by hand.
- **Store page:** the name carries the category word ("Name: App Blocker for Habits"). Screenshots are light, with big captions about the outcome; the first one is the core moment, never a zero state.
- **Ads:** none until the funnel is measured.

**Web**
- **Stack:** a one-page site in plain HTML/CSS/JS; a multi-page site in Astro; a web app in Vite + React + TypeScript, or Next.js. Start from the skill's `assets/web/tokens.css` (spacefs's measured values).
- **Hero:** says what it is in plain words, for whom, and the difference.

**Motion:** calm by default: spacefs's hover nudges, start-visible reveals and its sticky product scroll story on websites. Parallax, other scroll storytelling and 3D only when asked.

**Motion and 3D rules** (from the owner's website guides)
- Every animation has a job (guide attention, explain, give feedback or create depth); otherwise cut it.
- One motion language and one big moment per page.
- The page must look finished with all motion off.
- 3D must explain the product, and the page must still work without it.
- Nothing depends on hover on phones, and Reduce Motion means static.

**Website ideas and effects library:** `~/.claude/skills/taste/library/INDEX.md`, if present (the owner's bought guides; not in shared copies). It holds 50 industry site briefs, 20 effects with instructions, and parallax, 3D and scroll recipes.
- For a new website that isn't an app's own site, find the matching industry brief and any requested effect there. A brief only picks which spacefs sections appear and what they say. An app's own site follows `references/web.md`, "App marketing site blueprint".
- Read only that part, then rebuild it in the chosen theme.
- Its gradients, glows and gimmicks are banned.

**Logos and icons:** if the owner gives none, or asks for one, follow the skill's `references/logo.md`.
- **App icon:** shows what the app does (a padlock for a locker, a drop for water), drawn flat in the spacefs spirit: one ink color on one solid ground, bold simple shapes, readable at 16 px. No gradients, 3D or clichés. The initial can live inside the object (the T in Toll's keyhole).
- **Website or company mark:** the spacefs-style mark is allowed: two bold organic shapes, often rotated 180° from each other, with the letter in the negative space. Never a copy.

Blind-test every app icon before it ships: ask an image model and a person who see only the icon what the app does.

**When the owner doesn't specify:** if he asks for a website or app without naming a theme or design, choose everything yourself:
- a website gets Quiet Glass (spacefs), with the accent, sections and photos picked by the subject;
- an app gets the style-board design in a light palette picked by the subject. State the choice in one line and start building. Don't ask design questions. Missing content (names, prices, photos) gets clearly marked placeholders, listed at the end for him to replace.

**Who wins:** the owner's newest words beat everything. A project's own CLAUDE.md design rules win inside that project.
