# taste

My design language and app-shipping playbook for Claude: premium, calm, light, Liquid Glass, never gradients, spacefs.com for websites, plus what real users taught me about AI slop, onboarding, paywalls, prices, store pages and app ideas. Claude Code uses it automatically for every app and website I build (the global rules in `global-CLAUDE.md` load in every terminal).

- Style board (live): https://csamaha655-eng.github.io/taste-board/ (also on claude.ai: https://claude.ai/artifact/EUqU72opYptW16qZtzu5aB)
- Latest download: [taste.zip](https://github.com/csamaha655-eng/claude-taste/releases/latest/download/taste.zip) (rebuilt with `sh package.sh` after each push)

## Install on a new Mac or a new Claude Code account

```sh
git clone https://github.com/csamaha655-eng/claude-taste.git ~/.claude/skills/taste
sh ~/.claude/skills/taste/install.sh
```

That puts the skill in `~/.claude/skills/taste` and links my global rules (`global-CLAUDE.md`) as `~/.claude/CLAUDE.md`. Any existing file is backed up first. Then open a new Claude terminal.

From the zip instead: unzip `taste.zip` and run `sh taste/install.sh`.

## Codex

`install.sh` also sets up Codex when `~/.codex` exists: Codex already finds skills in `~/.claude/skills`, and the script links the same global rules as `~/.codex/AGENTS.md` (and the skill into `~/.agents/skills/taste`). Claude Code is the main target; Codex gets the same rules.

## Share it with a friend

`sh package.sh` leaves two zips in `~/Downloads` and on the latest release:
- `taste.zip` is yours, complete;
- `taste-share.zip` is for a friend, with everything except `library/` (the bought guides aren't yours to share).

Your friend unzips it and runs `sh taste/install.sh`, or uploads the zip on claude.ai (below).

## Use it on claude.ai (web and desktop chats)

1. Download `taste.zip` (style board footer, or the link above).
2. On claude.ai, open Settings → Capabilities → Skills, choose Upload skill and select the zip.
3. Optional: paste the "The core, in case nothing else is loaded" section of `global-CLAUDE.md` into your profile preferences on claude.ai.

## What's inside

| Path | What it is |
|---|---|
| `SKILL.md` | The rules: who decides, the ten laws, the workflow |
| `references/` | Themes (spacefs.com measured for websites), web, iOS, logos, anti-slop checklist, inspiration, and what real users taught (Reddit, Oct 2026): `app-idea.md` (is an idea worth building or saturated), `app-launch.md` (onboarding, paywall, price, store page, launch checks) |
| `assets/web/` | `tokens.css`, `stipple.js`, `specimen.html` (the style board) |
| `assets/ios/` | `Theme.swift`: the app design with palettes (Steel, Midnight, Graphite, Paper) |
| `library/` | The website guides I bought, with an index. This is why the repo stays **private**. |
| `global-CLAUDE.md` | My global Claude rules (linked as `~/.claude/CLAUDE.md`) |
| `install.sh` | The installer (Claude Code, plus Codex when installed) |
| `package.sh` | Rebuilds `taste.zip` as the latest release and republishes the live style board |
