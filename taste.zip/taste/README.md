# taste (and two companion skills)

My design language and app-shipping playbook for Claude: premium, calm, light, Liquid Glass, never gradients, spacefs.com for websites, plus what real users taught me about AI slop, onboarding, paywalls, prices, store pages and app ideas. Claude Code uses it automatically for every app and website I build (the global rules in `global-CLAUDE.md` load in every terminal).

- Style board (live): https://csamaha655-eng.github.io/taste-board/ (also on claude.ai: https://claude.ai/artifact/EUqU72opYptW16qZtzu5aB)
- Latest download: [taste.zip](https://csamaha655-eng.github.io/taste-board/taste.zip) on the board, the same file as this repo's [latest release](https://github.com/csamaha655-eng/claude-taste/releases/latest) (both rebuilt by `sh package.sh` after each push)

## Install on a new Mac or a new Claude Code account

```sh
git clone https://github.com/csamaha655-eng/claude-taste.git ~/.claude/skills/taste
sh ~/.claude/skills/taste/install.sh
```

That puts the skill in `~/.claude/skills/taste`, links the two companion skills next to it (`~/.claude/skills/app-strategy`, `~/.claude/skills/app-marketing`), and links my global rules (`global-CLAUDE.md`) as `~/.claude/CLAUDE.md`. Any existing file is backed up first. Then open a new Claude terminal.

From the zip instead: unzip `taste.zip` and run `sh taste/install.sh`.

## Codex

`install.sh` also sets up Codex when `~/.codex` exists: Codex already finds skills in `~/.claude/skills`, and the script links the same global rules as `~/.codex/AGENTS.md` (and the skill into `~/.agents/skills/taste`). Claude Code is the main target; Codex gets the same rules.

## Download from the style board

The board's Download button (footer, and in its Menu) gets `taste.zip`: every file in this repo at the last `package.sh`, the bought guides included, for my own use on another computer or another Claude account. The footer shows the commit it was built from, and `version.txt` on the board holds the same hash. The board is public but hidden from search; this repo stays private.

## Use it on claude.ai (web and desktop chats)

1. Download `taste.zip` (style board footer, or the link above). claude.ai takes one skill per upload, so also download `app-strategy.zip` and `app-marketing.zip` from the footer.
2. On claude.ai, open Settings → Capabilities → Skills, choose Upload skill and select each zip.
3. Optional: paste the "The core, in case nothing else is loaded" section of `global-CLAUDE.md` into your profile preferences on claude.ai.

## What's inside

| Path | What it is |
|---|---|
| `SKILL.md` | The design and building skill: who decides, the ten laws, the workflow |
| `skills/app-strategy/` | Companion skill: is an idea worth building or saturated, the business model (a paywall from day one, with the data), prices, the numbers, the stop rule, how to weigh feedback |
| `skills/app-marketing/` | Companion skill, only on request: store words (ASO), first ratings, organic and creator videos, Reddit posts, ads |
| `references/` | The blueprints (`ios.md`, `spacefs.md` for product websites, `fashion.md` for clothing brands), `themes.md` (themes, palettes, accent library), `web.md`, `anti-slop.md`, `logo.md`, `inspiration.md`, and what real users taught about design (`real-users.md`, `app-launch.md`) |
| `assets/web/` | `tokens.css`, `stipple.js`, `specimen.html` (the style board), `site-check.mjs` (tests every page and button before a site is shown) |
| `assets/ios/` | `Theme.swift`: the app design with palettes (Steel, Midnight, Graphite, Paper) |
| `library/` | The website guides I bought, with an index. This is why the repo stays **private**; the board's download includes them for my own use. |
| `global-CLAUDE.md` | My global Claude rules (linked as `~/.claude/CLAUDE.md`) |
| `install.sh` | The installer (Claude Code, plus Codex when installed) |
| `package.sh` | Rebuilds `taste.zip` from the last commit, publishes it as the latest release and on the live style board, so both hold the same version |
