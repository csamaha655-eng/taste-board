# Web

## Stack

- **One-page landing site:** static HTML, one CSS file and a little vanilla JS. This is how the style board is built, and it's the fastest possible page.
- **Multi-page marketing site** (pricing, legal, blog, changelog): Astro with the plain CSS from tokens.css. It ships zero JS by default and reuses components across pages.
- **Hosting:** free on Cloudflare Pages or GitHub Pages (Vercel when the owner asks). The owner wants $0 running costs.
- **Web apps** (logins, dashboards, live data): Vite + React + TypeScript, or Next.js when server rendering is needed. Use Tailwind only if the project already does.
- **Not Gatsby:** don't start new projects on it, even though spacefs.com uses it (Gatsby + Tailwind behind Cloudflare); it has been barely maintained since 2023.
- **Don't add a framework a page doesn't need.** The look comes from the tokens and patterns, not the framework.
- **Every project starts from `assets/web/tokens.css`.** Switch themes with a class on `<html>` (`theme-atmos`, `theme-nocturne`). `assets/web/specimen.html` has a working version of every pattern below; copy from it rather than reinventing.

## Type

One family per site. The default is Google Sans:

```html
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Google+Sans:wght@400..700&family=Google+Sans+Code:wght@400..600&display=swap">
```

Geist, Instrument Sans and Onest have the same calm, for when a product needs its own voice. Don't default to Inter, Poppins, Montserrat, Space Grotesk or a serif-plus-sans pair; they read as generic.

This is spacefs.com's scale, measured on 2026-10-11 (see `themes.md`, Quiet Glass). Copy it exactly.

| Role | Size | Weight | Tracking | Line height |
|---|---|---|---|---|
| display (hero h1) | clamp(44px, 5.03vw, 76px) | 500 | -0.035em | 1.02 |
| title (big section h2) | clamp(36px, 3.97vw, 60px) | 500 | -0.035em | 1.04 |
| title-2 (section h2) | clamp(32px, 3.57vw, 54px) | 500 | -0.03em | 1.04 |
| heading (row h3) | clamp(24px, 2.25vw, 34px) | 500 | -0.025em | 1.25 |
| lede | 17px | 400 | 0 | 1.625 |
| body | 15-16px | 400 | 0 | 1.625 |
| button, pill | 14px | 500 | 0 | 20px |
| meta line | 12px | 400 | 0.3px | 16px |
| label (uppercase) | 12px | 500 | 0.14em | 1.2 |

- **Two-tone headline:** two block spans, with the second in `--ink-2` (`.two-tone` in tokens.css).
- **Measure and wrapping:** keep text near 60-70 characters per line. Use `text-wrap: balance` on headings and `pretty` on paragraphs.
- **Numbers:** `font-variant-numeric: tabular-nums` for prices and stats.

## Color

Use tokens only.

- The page canvas is a cool off-white, never pure white; cards are white.
- One accent, for focus rings, links and selection.
- A black pill for the primary action.
- Body copy and captions in `--ink-2` for calm; headlines in `--ink`. `--ink-3` is decoration only (icons, rings, disabled states), never readable text.
- Check gray text on the canvas for at least 4.5:1 contrast.

**Dark mode:** Quiet Glass sites follow the OS, with light and dark both designed. Design and review light first, and show light in every screenshot, OG image and store visual: real users read dark pages with colored light as AI-made. Atmos Glass and Parallax Journey lock to light; Nocturne locks to dark (only when asked). Lock with the theme class and `data-theme` on `<html>`.

## Surfaces

- **Card:** `--surface`, radius 20-28, `--shadow-2` (a hairline ring, a soft layered shadow and an inner top highlight). Never pair a visible border with a heavy shadow.
- **Glass** (`.glass`): for the floating nav, menus, popovers, prompt capsules and cards over imagery.
  ```css
  background: var(--glass-fill);
  backdrop-filter: blur(24px) saturate(1.6);
  box-shadow: 0 0 0 .5px var(--glass-rim), 0 8px 24px -10px rgb(0 0 0 / .18), inset 0 .5px 0 var(--glass-highlight);
  ```
  - tokens.css already includes a solid fallback for `@supports not (backdrop-filter)` and `prefers-reduced-transparency`.
  - Never put `backdrop-filter` on a very tall element (it can fail to paint); make those opaque.
- **Radii:** pills and buttons 9999, small elements 12, cards 20-28, device frames 40+. Siblings share one radius.

## Components (all live in specimen.html)

- **Floating nav:** circle logo, glass link pill, black pill CTA, with a feathered progressive-blur band behind it (`.feather`; over full-bleed photos use `.feather.clear`, blur with no tint).
- **Hero:**
  - trust chip (only if real), two-tone display headline, lede;
  - one black pill CTA, plus an optional glass secondary;
  - a meta line underneath;
  - sized to its content, not `100vh`.
- **Hero words (what strangers need, in this order):**
  - line one says what it is or does, plainly (spacefs: "The infinite AI-native filesystem"; Toll: "Locks your apps until you work out.");
  - the lede says for whom, the pain it removes and the one difference;
  - if a free built-in alternative exists, answer it in one short line.

  No metaphor the reader must decode, and no mood line. It must pass the 5-second test in `anti-slop.md`.
- **Product mockup:**
  - an iPhone or macOS frame showing real screens (HTML, or a transparent PNG);
  - never a screenshot with a white box or visible edges;
  - in sticky scrollytelling, the mockup changes state at each step.
- **Editorial rows:** title left, text right, hairline dividers. Number them only if they are a real sequence.
- **Other blocks:**
  - link cards with a circle arrow;
  - pricing cards with a segmented toggle;
  - FAQ rows built on `<details>` with a circle plus;
  - footer columns, optionally ending in a dot-matrix wordmark.
- **Prompt capsule** for AI features: small and glass, centered at the bottom of its context.
- **Icons:** one set, either Lucide or Phosphor (regular, 1.5 px stroke) or SF Symbols exported as SVG. Never emoji, never mixed sets.

## Ornament (one family per page)

Quiet Glass pages use the stipple field and the dot-matrix wordmark; the two count as one family. Parallax Journey pages use photography only: no stipple, and the wordmark is optional at the very bottom.

- **Stippled dot field.** `assets/web/stipple.js` draws solid dots in two hues on a canvas, with density following a wave. It drifts slowly, pauses offscreen, and is static under Reduce Motion.
- **Dot-matrix wordmark.** Text filled with a hard-edged dot pattern (`background-clip: text`), cropped at the bottom of the footer.
- **Photography** (Parallax Journey). Real, edited, with one consistent color grade.

## Motion

- **Tokens:** `--ease-out: cubic-bezier(.22,1,.36,1)` and `--ease-std: cubic-bezier(.4,0,.2,1)`. Durations: 160 ms for hover, 320 ms for UI, 560 ms for reveals.
- **Hover:** arrows translate 4 px, links fade to 70%, buttons press to scale .97. No glow on hover.
- **Scroll reveals:**
  - use CSS scroll-driven animations (Chrome, Edge, Safari 26+);
  - wrap them in `@supports (animation-timeline: view())` and `prefers-reduced-motion: no-preference`;
  - start from a visible state (opacity at least .4, translate at most 24 px). Nothing sits invisible waiting for JS.
- **Sticky scrollytelling:**
  - a tall section (250-400vh) holds a `position: sticky` stage;
  - the steps switch the mockup's state by scroll progress, using a view timeline or IntersectionObserver;
  - keep both columns occupied: each step holds real content, spaced so the next one enters as the last one leaves, with no empty column.
- **Parallax:**
  - 2-4 layers inside a sticky stage, each translating at its own rate on a named `view-timeline`;
  - working code is `.journey` in specimen.html;
  - without support, or under Reduce Motion, the scene is static and complete.
- **Never:** scroll-jacking, auto-advancing carousels, animated intros, typing-effect headlines, cursor trails.

## Motion and 3D rules (from the owner's website guides; recipes in `library/`)

**The motion language:**
- Every effect has a job: guide attention, explain, show hierarchy, give feedback, create depth or tell the story.
- One easing, one set of durations and one hover intensity across the whole site.
- At most one orchestrated moment per page.
- If the product isn't remembered after 5 seconds, the effects are too loud.

**Choosing the tool:**

| Need | Tool |
|---|---|
| Reveals, parallax, sticky effects | CSS scroll-driven animations |
| Coordinated timelines or pinned scrubbing | GSAP + ScrollTrigger (free, plugins included) |
| React component motion | Motion |
| Custom 3D | Three.js (React Three Fiber in React) |
| Designer-made scenes | Spline |
| A spinnable product or AR | `<model-viewer>` |
| Small vector animations | dotLottie |
| Page transitions | the View Transitions API |

Choose the experience first, then the tool.

**3D:**
- 3D is used only when the owner asks for it and the subject is a physical product or the brand itself is the object. Decorative 3D (abstract renders, glossy blobs, metal badges) is never used.
- Direct it by six things: object, material, light, camera, motion and role. It never overlaps the headline or CTA.
- The look:
  - neutral studio lighting from an environment map;
  - true-to-life materials;
  - the background is the page canvas, with a soft contact shadow;
  - no neon or emissive glow.
- Loading and fallbacks:
  - a poster image shows until WebGL is ready;
  - models are GLB, compressed with gltf-transform (meshopt or Draco), about 3 MB at most for a hero;
  - pixel ratio capped at 2 (1.5 on phones);
  - rendering pauses offscreen;
  - a static pose under Reduce Motion;
  - a lighter scene or the poster on phones.

**Parallax and scroll recipes** (the four kinds from the owner's guide, rebuilt the modern way):

All of these go inside `@supports (animation-timeline: view())` and `@media (prefers-reduced-motion: no-preference)`. Without support, the page stays static and complete. Animate only `transform` and `opacity`.

1. **Multi-layer parallax** (the classic "depth" effect, used in Parallax Journey).
   - Structure: a tall scene with a sticky stage; 2-4 layers move at different speeds; the far layer moves least.
   - The working version is `.journey` in specimen.html.
   ```css
   .scene { height: 200vh; view-timeline: --scene block; }
   .stage { position: sticky; top: 0; height: 100vh; overflow: clip; }
   .layer { animation: drift linear both; animation-timeline: --scene; animation-range: contain 0% contain 100%; }
   .far { --y0: 3%; --y1: -3%; }  .mid { --y0: 9%; --y1: -9%; }  .near { --y0: 18%; --y1: -18%; }
   @keyframes drift { from { transform: translate3d(0, var(--y0), 0); } to { transform: translate3d(0, var(--y1), 0); } }
   ```
   Give each layer's fill a block below it, so lifting a layer never shows a gap.

2. **Background (hero photo) parallax.**
   - Never use `background-attachment: fixed`: it's broken on iOS Safari and janky elsewhere.
   - Put an `<img>` inside an `overflow: clip` hero and drift it slower than the page while it settles from 1.08 to 1.
   ```css
   .hero-photo { animation: settle linear both; animation-timeline: view(); animation-range: exit 0% exit 100%; }
   @keyframes settle { from { transform: translateY(0) scale(1.08); } to { transform: translateY(14%) scale(1); } }
   ```

3. **Horizontal scroll section.** Scrolling down moves a row of panels sideways.
   - Use a pinned stage. The track slides by its own overflow; JS measures it once and sets `--shift` (track width minus viewport width).
   ```css
   .hscroll { height: calc(100vh + var(--shift, 0px)); view-timeline: --h block; }
   .hscroll .stage { position: sticky; top: 0; height: 100vh; overflow: clip; display: flex; align-items: center; }
   .track { display: flex; gap: 24px; animation: slide linear both; animation-timeline: --h; animation-range: contain 0% contain 100%; }
   @keyframes slide { to { transform: translateX(calc(-1 * var(--shift, 0px))); } }
   ```
   - On phones, skip the pinning: use a normal swipe rail with `scroll-snap` (`.rail`).

4. **Mouse parallax** (hero layers react to the cursor).
   - Desktop with a precise pointer only; never on phones or under Reduce Motion.
   - Ease toward the target every frame. Keep it small: about 4 px for far layers, up to 14 px for near ones.
   ```js
   if (matchMedia('(pointer: fine) and (prefers-reduced-motion: no-preference)').matches) {
     const layers = [...document.querySelectorAll('[data-depth]')]; let tx = 0, ty = 0, x = 0, y = 0;
     addEventListener('pointermove', e => { tx = e.clientX / innerWidth - .5; ty = e.clientY / innerHeight - .5; });
     (function loop() { x += (tx - x) * .08; y += (ty - y) * .08;
       for (const l of layers) l.style.transform = `translate3d(${x * l.dataset.depth}px, ${y * l.dataset.depth}px, 0)`;
       requestAnimationFrame(loop); })();
   }
   ```
   Set `data-depth` from 4 to 14 per layer, and pause the loop when the hero is offscreen.

**Other scroll effects that fit the look:**
- **Image scale on scroll:** `animation-timeline: view(); animation-range: entry 0% cover 50%`, scaling from 1.08 to 1 inside a fixed frame.
- **Sticky scrollytelling** (spacefs's Finder window):
  - a pinned mockup;
  - an IntersectionObserver on each step sets `data-step` on the mockup;
  - CSS transitions move it to that step's state;
  - both columns always hold content.
- **Section color shift:** the page background moves from one solid token to the next as a section enters, via a view timeline. It's a transition in time, never a gradient on screen.

**Browsers without scroll-driven animations** (older Firefox): leave the page static. If the effect is essential, set a `--p` (0-1) progress variable from a `requestAnimationFrame` loop with cached rects, and drive the same transforms from `--p`.

**Scroll-scrubbed video (Apple style):**
- Encode every frame as a keyframe (`ffmpeg -g 1`), or use an image sequence on a canvas.
- Show a poster first.
- On phones, play it muted and inline when it scrolls into view instead of scrubbing.

**Integrating a component** (Aceternity UI, React Bits, a CodePen):
- Identify its framework, dependencies, assets and license.
- Test it alone first.
- Restyle it to the tokens: strip its gradients, glows and default fonts.
- Add a touch fallback and a reduced-motion fallback.
- Add one component at a time.

**Prompts for other AI builders:** when the owner wants a prompt for Lovable, Framer, Bolt or v0, use `library/prompting-playbook.txt` (purpose, audience, visual direction, structure, 3D, motion, constraints). Always append this skill's constraints: no gradients, one typeface, a black pill CTA, no emoji, no fake content.

## Scroll hygiene

- **Overscroll:** set `html { background: var(--canvas) }` so rubber-band overscroll matches the page. This fixes "it's black on top when I scroll up". Also set `<meta name="theme-color">` for light and dark.
- **Bars:** no fixed bar that turns into a solid block on scroll; the nav stays floating glass.
- **Scrollbars:** hide them only on horizontal rails, and give rails `scroll-snap`.
- **Images:**
  - give every image width and height, or an `aspect-ratio`;
  - with `object-fit: cover`, set `object-position` so faces and subjects are never cut at the top.

## Web apps (product UI) in Quiet Glass

A web app (accounts, dashboard, settings, plans and billing) uses the same tokens as the marketing site, so the two feel like one product. Marketing lives at `/`; the app lives at `/app` or on an `app.` subdomain.

**Shell:**
- Canvas background.
- A quiet left sidebar (about 240 px) on desktop: canvas-colored, items as pills. The selected item is a surface pill with `--shadow-1`, exactly like `.segmented`.
- Top bar:
  - a two-tone page title (name in ink, context in gray);
  - a glass search or command pill (⌘K);
  - one black pill for the page's main action;
  - an avatar circle.
- On phones, the sidebar becomes a glass bottom tab bar, or a "Menu" glass pill.

**Content:** solid white cards (radius 20-24, `--shadow-2`) on the canvas. No glass on content.

**Tables:**
- Hairline rows, no zebra stripes, rows about 52 px tall.
- Tabular, right-aligned numbers; mono for IDs and amounts.
- Status shown as a word plus a small dot, never color alone.

**Dashboards:**
- Summary first, then detail.
- Stat tiles only when the numbers are the point.
- Charts: one ink or accent series. An area fill is the same solid color at 8-12% opacity, never a gradient.

**Forms:**
- Visible labels above every field.
- Inputs 44 px tall, radius 12, surface fill, hairline ring, and a 2 px accent focus ring.
- Inline validation that says how to fix the problem.
- Primary action as the black pill; secondary as glass.

**Overlays:**
- Modals and sheets: glass panels (radius 24-28) over a flat ink scrim at 30%.
- Toasts: a glass pill at the bottom center.
- Command palette: spacefs's "launcher". A glass panel with a 0.5 px rim and inner highlight; the selected result row sits on ink at 6%.

**Plans and pricing (inside the app):**
- A Monthly/Annual segmented control.
- 2-3 plan cards; the current plan carries a "Current plan" chip, and the recommended plan gets a 1 px ink ring (never a gradient badge).
- A feature comparison table with check marks.
- Usage meters: a solid bar on a 15% track.
- Upgrades and downgrades confirm in a glass sheet that shows the prorated price.
- Billing page: payment method card, invoices table, and "Manage billing" opening the Stripe Customer Portal.
- Cancelling is honest and one click away.

**Settings:**
- A section list on the left, forms in cards on the right.
- A danger zone at the bottom: red text buttons and a confirm sheet.

**Auth:**
- A centered solid card on the canvas.
- The stipple field may sit behind it (it's a marketing surface).
- Standard Sign in with Apple and Google buttons.

**Empty states:** one line saying what will appear, plus the primary action. No illustrations.

**Inside the app:** no stipple, no dot-matrix wordmark, no scroll effects. Those belong to marketing pages.

**Stack:**
- Vite + React + TypeScript for a pure app; Next.js when the app needs server rendering, SEO or server-side auth.
- `tokens.css` as CSS variables. If the project uses Tailwind, map the tokens into its theme instead of using Tailwind's default palette.
- Payments: Stripe Checkout plus the Customer Portal.
- Backend at $0 to start: Cloudflare (Workers or Pages Functions, D1, R2), or Supabase if the owner prefers.

## App marketing site blueprint (one per app)

1. **Floating nav:** the app icon (rounded, never in a white box), links, and a "Download" black pill linking to the App Store.
2. **Hero:**
   - the same message as the first App Store screenshot: what the app does, in plain words, as a two-tone headline;
   - a lede with who it's for and the difference;
   - the official black App Store badge;
   - real app screens in an iPhone frame, showing a real moment, never a zero state.

   Light, with real photos or the product. Never 3D renders or a dark glow.
   - Download the badge artwork from developer.apple.com/app-store/marketing/guidelines and keep the SVG in the site. Never redraw or recolor it.
3. **Features:** 3-5 sections, each with one real screen and one sentence. Alternate sides, or use sticky scrollytelling. Features come from the app; never invent them.
4. **Pricing** mirrors the paywall:
   - annual with its trial, highlighted;
   - monthly;
   - lifetime;
   - a strike-through "was" price only for a price that was actually charged before, never monthly x 12.
   - Use the real prices from the paywall or App Store Connect; if they're unknown, use placeholders and list them.
   - Use a Monthly/Annual toggle only when one card switches period. With all plans side by side, no toggle.
5. **FAQ and footer:** footer links to Privacy, Terms and Support. App Store Connect needs the privacy and support URLs.
   - The FAQ answers the questions strangers really ask: the free alternative ("doesn't my phone already do this?"), how it works and whether it can be fooled, what happens if it fails them, what happens to their data, and how to cancel.
6. **Palette:** spacefs's canvas, ink and grays; only the accent, the icon, the photos and the screens come from the app.
7. **Founder line:** one short, true sentence about why it was built, if the owner has one. Real stories beat "built with love".
8. **Timing:** publish pages that show new prices or features only once the App Store version that carries them is live.

## Accessibility and performance

- **Focus:** a visible focus ring (2 px accent, 2 px offset).
- **Targets:** at least 44 px.
- **Preferences:** handle `prefers-reduced-motion`, `prefers-reduced-transparency` and `prefers-color-scheme`.
- **Fonts:** load with `display=swap` and a full fallback stack.
- **Images:** AVIF or WebP, lazy-loaded below the fold.
- **Layout shift:** none from fonts or images.
