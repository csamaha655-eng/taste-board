# The clothing-brand blueprint (store websites)

The owner's reference for any clothing or fashion brand website: reframedclothing.com, "very, very professional; copy it, the animations and everything". Recorded on 2026-10-11 at 1440 and 390 px wide.

**Use it for** a clothing, streetwear, accessories or fashion store website, unless the owner names another reference or style. Copy the design system and the interactions closely. Never copy their logo, brand name, photos, product names, copy, or their paid fonts. The owner gives:
- the brand's name and logo;
- the products, with their prices.

Never research the market or suggest prices for a brand site: he picks them. Anything missing gets a visible placeholder listed at the end.

**This blueprint overrides these defaults, on the owner's word ("copy it, the animations and everything"):**
- strictly black and white (the photos carry all the color);
- blurred see-through glass, not Liquid Glass;
- square-cornered rectangle buttons, not pills;
- the reference's small type: 14 px body text in the store UI and tracked uppercase labels of at least 11 px;
- a slow footer ticker (it stops under Reduce Motion).

Everything else in the laws still holds: one type family, no gradients, no emoji, no fake reviews, plain words, phones first.

## The look in one line

A white page with near-black type, light-gray product backgrounds and one solid black block. Small tracked uppercase labels, a wide bold display face for big titles, and large real photography. The UI is quiet so the clothes are the color.

**Tokens:**
- **Colors:** page #FFFFFF; ink #0B0B0B (body text #333333); muted #6F6F6F; product backgrounds #F4F4F4 to #F5F5F5; hairlines #E5E5E5; the black block #0B0B0B with white type.
- **Type, one family:** Archivo (free, variable width and weight), never the reference's paid font.
  - **Display:** width 125 at weight 800 for the hero title and the logo-like headings.
  - **Headings:** normal width at 700, tight.
  - **Body and UI:** normal width at 400-500, 14 px.
  - **Labels:** 11-13 px, uppercase, tracking 0.1-0.15em.
- **Shape:** square corners almost everywhere (0-4 px). Buttons are rectangles, never pills.
- **Glass:**
  - the header: white at 45% with `backdrop-filter: blur(16px)`;
  - the menu drawer: a dark frosted panel (black at about 40% over a blurred page) with white type;
  - other drawers: solid white panels over a black overlay at 40%.

## Page structure, top to bottom (home)

1. **Header (52 px, sticky and "smart").** Menu icon on the left, logo centered, search and bag icons on the right, all thin line icons in ink.
   - It slides up out of view while you scroll down and returns when you scroll up: `transform 0.35s cubic-bezier(.4,0,.2,1)`, about -57 px when hidden.
   - It stays see-through glass over the hero.
2. **Hero (full width, about 85% of the viewport).** One large lifestyle photo, the whole of it a link. At the bottom left sit:
   - an eyebrow (12 px, uppercase, tracked, white: "LIMITED QUANTITY · RESTOCKED");
   - the product or drop name in the wide display face (28 px, uppercase, white);
   - an outlined white rectangle button, "DISCOVER" (11 px, tracked).
3. **Featured rail.**
   - **Top row:** tabs on the left (12 px uppercase; the active one ink with an underline, the others gray), "VIEW ALL" (underlined) and small arrows on the right.
   - **Cards:** a sideways-scrolling row, 4 visible on desktop and 2.3 on phones.
4. **Collection grids** (one per category: "Hats", "T-shirts").
   - A 20 px title on the left, "SORT" and "FILTERS" on the right, and a hairline under the row.
   - 6 columns on desktop and 2 on phones, with numbered pagination (a black active square).
5. **Shop by category.** 4 tall image tiles, each with an uppercase label and an arrow at the bottom left.
6. **Lookbook carousel.** A tiny uppercase title, a toggle between 2-up and grid views, large model photos, and a "3/6" counter with a thin progress line.
7. **Club sign-up (the one black block).**
   - a tiny eyebrow and a bold two-line headline (38 px, white);
   - one line, then an underlined input (email, or phone with a country code) with "JOIN";
   - the legal line in 11 px.
8. **Footer.** Columns (BRAND, LINKS) of small links, which become accordions with "+" on phones. Social icons, payment icons, a country and currency selector, and the copyright at 11 px.
9. **Ticker.** A thin black bar at the very bottom with white words scrolling sideways ("Worldwide × For Creators ×").

## The product card

- **Photo:** the product on a #F4F4F4 ground, aspect 4:5.
- **Hover (desktop):** the second photo crossfades in (`opacity .3s`), and a white "QUICK ADD — SIZE" bar with square size boxes appears at the bottom of the image.
- **On phones:** a small "+" square at the image's bottom-right opens the sizes.
- **Under the image** (14 px): the name, then the color in gray, then the price. Extra colors read "Black 1 more".
- **Badges** ("SOLD OUT", "NEW"): tiny uppercase, top-right, on white.

## Product page

- **Desktop layout:** two columns. On the left, large product photos on the gray ground, scrolling. On the right, a sticky column with:
  - the product name (16-18 px);
  - "Colors" as photo-thumbnail swatches (the selected one with an ink border);
  - "Select your size" as a dropdown or square size buttons (sold-out sizes crossed or grayed);
  - a "Size Chart" link (it opens a drawer);
  - a full-width black bar, "Add to cart", with the price right-aligned inside it;
  - an express payment button;
  - tabs (Description, Care Guide, Refund & Exchange) with "See more".
- **On phones:** the photos become a swipe carousel with dots, and everything else stacks.

## Interactions

- **Menu drawer (left):**
  - It slides in from the left (`transform .35s cubic-bezier(.4,0,.2,1)`, about 650 px wide on desktop, full width on phones), and the page dims behind it.
  - It is dark frosted glass with white words: main rows (Shop ›, New Arrivals, Collections ›) separated by hairlines. A "›" row slides in its own sub-panel (Shop All, Tees, Hoodies) with a back arrow.
  - At the bottom: an email field with "SUBSCRIBE", then small links (Tracking, Contact, Refunds and Exchange).
  - It closes with ×, Escape or a tap on the dimmed page.
- **Search drawer (right):** a white 480 px panel slides in (.35 s) over a 40% black overlay. It has an input with an underline and live results as small cards.
- **Add to cart:** a white notification card slides down at the top right (`transform .4s`). It reads "Product added to cart" and shows the item (photo, name, variant, quantity), with "Proceed to checkout" (black) and an express payment button. The bag icon shows the count.
- **Cart drawer:**
  - a right panel listing the items with quantity steppers and remove links;
  - the subtotal, a note that shipping is calculated at checkout, and a black "Checkout" bar.
- **Motion:** quiet. Crossfades and slides at 0.3-0.4 s, an ease-in-out curve, no bounce. The ticker runs slowly. Under Reduce Motion everything appears without moving, and the ticker stops.

## When the owner asks for a showcase effect

Only when he asks ("make the hoodie turn when I scroll", "parallax header"):
- **Product turning on scroll:** a sticky stage pins the product while a scroll-scrubbed sequence of 24-48 photos of it turning plays on a `<canvas>`. Shoot it on a turntable, or render it from a real 3D model of the garment. Without photos, use `<model-viewer>` with the product's GLB, its rotation driven by scroll progress.
  - Keep the photo and the type sharp, and pin it for about 150-200% of the viewport.
  - Under Reduce Motion, show one still photo.
- **Parallax header:** the hero photo drifts slower than the page (the `web.md` recipe), and the title rises at a different rate.

These sit inside this blueprint's black-and-white system. The rest of the page stays as above.

## What a brand site needs to work (test all of it)

- **Pages:** home, collection with filter and sort, product, cart drawer, search, about or story, size guide, contact, the policies (shipping, returns, privacy, terms), and a 404.
- **Stock:** variants (color, size) with sold-out states and stock that updates the button ("Sold out", "Notify me").
- **Cart:** add, change the quantity and remove; the count and subtotal update everywhere; the cart is kept in `localStorage` for a static site. The real checkout is Shopify or Stripe (the owner decides).
- **Text:** prices in the owner's currency, exactly as he gave them.
- **Speed:** responsive, compressed, lazy-loaded images (AVIF or WebP), and no layout shift while photos load.
