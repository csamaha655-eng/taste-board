# The spacefs blueprint (product websites)

The owner's favorite website: "I love, love, love it. Copy it." Measured and recorded on 2026-10-11 at 1440 and 390 px wide.

**Use it for** every website or web app for a product the owner makes (an app, a tool, a download page, a SaaS), and for any website request that names no style. Copy about 90%: the structure, the components, the measurements, the motion and the feel. Never copy its words, logo, product name, Finder screens, investor chip or images; those are always the owner's own product.

**Don't use it for** a site whose subject wants its own look: a clothing brand, a restaurant, a hotel, a portfolio, an event. Those follow `themes.md` and the matching industry brief in `library/`, keeping the laws and these components where they fit. When the owner asks for something spacefs doesn't have (parallax, 3D, dark), build that with its recipe and keep spacefs's type, colors, nav and buttons around it.

## The look in one line

A cool off-white page (#F7F8FA) with ink type (#0E0F12), gray second lines (#686D78), white frosted glass for every floating control, one black pill for the main action, and the product itself as the hero. Google Sans throughout. No colored sections, no illustrations, no gradients on anything visible.

## Page structure, top to bottom

1. **Floating nav (80 px tall, three separate pieces, no bar).**
   - Left: a 52 px glass circle holding the logo. It spins 180° on hover (500 ms, ease).
   - Center: a glass "Menu" pill (hamburger icon plus "Menu"). It morphs into the menu panel (below).
   - Right: the black "Download" pill (40 px tall), hidden on phones because the hero has its own.
   - Behind the nav, a feathered blur band (7rem tall, blur 20 and saturate 1.08, masked from opaque to clear) so content softens under it without a visible edge.
2. **Hero (full viewport height, at least 640 px, centered).** From top to bottom:
   - a small glass chip, for one true fact only;
   - the two-tone headline (line one ink, line two gray);
   - a lede of about 480 px;
   - the black Download pill (48 px tall);
   - a meta line (12 px, platforms or availability);
   - behind it, a quiet stippled dot field.

   On load, each piece rises in turn ("hero-rise": CSS only, opacity 0 to 1 and a 20 px rise, 1.1 s on the ease-out curve, 50-400 ms apart, none under Reduce Motion). It is the only load animation allowed, and the nav never waits for JavaScript to appear. On scroll, the whole group drifts up at about 0.09 times the scroll distance, up to 40 px, and fades. This is the gentle parallax at the top the owner loves.
3. **The product story (sticky, about 3 viewports tall).** A centered two-tone headline and lede. Then the real product window (macOS here) rises from below into the center as you scroll and changes state step by step: a selection, a context menu, an info panel highlighting the key fact. Finally it drifts away. This is the page's one big moment. For an iOS app, use an iPhone frame showing the app's real screens changing state. Use it only when there are at least three real states of the product to show; otherwise one still product shot on a glass card.
4. **Features, editorial rows.** A left-aligned section title and lede. Numbered rows (01-05), each with a title on the left, a two-line gray description on the right and hairlines between rows. The section ends with two glass link cards (radius 24, padding 28 by 32, a circle arrow that nudges on hover).
5. **A feature on a photo.** A centered two-tone title, a glass segmented strip of tabs, and a large real photograph used as a desktop wallpaper with the product's glass panels floating on it. Switching tabs changes the panel.
6. **Use cases.** A section title, then a 2-column grid of white cards, each with a product screenshot on top, a small category label, a one-line title and "Learn more →".
7. **Pricing.** A centered "Simple pricing" with a one-line note, a Monthly/Annual segmented control, and three white cards. The middle one has the black pill; the others are white pills. Checkmark lists sit under the price.
   - **For an app, mirror the paywall instead:** yearly (highlighted, black pill), monthly and lifetime side by side, no toggle, and the billed amount is the largest price (`app-launch.md`), never spacefs's monthly equivalent.
8. **FAQ.** On the left, a sticky title with "Still have a question? Write to the team." On the right, accordion rows with circular plus buttons and hairlines.
9. **Final call to action (about 86% of the viewport tall).** A fanned stack of real product cards, a two-tone question headline, one line, and the black Download pill.
10. **Footer.** Logo, one-line description and Download pill on the left; columns (Product, Company, Legal, Social) on the right; the copyright line; and a giant wordmark cropped at the bottom edge in a light tint.

Sections have 96 px of vertical padding inside a 1200 px column. Only the product story and the hero move with scroll; everything else just reveals gently.

## Components (measured)

- **Glass control** (nav pieces, chips, segmented strips, the menu):
  - background white at 66%;
  - `backdrop-filter: blur(20px) saturate(1.5)`;
  - border `1px solid rgb(15 23 42 / .09)`;
  - box-shadow `inset 0 1px 0 rgb(255 255 255 / .9), 0 1px 2px rgb(15 23 42 / .05)`;
  - on hover, background white at 90% and border at .14.
- **Ink button** (the black pill):
  - background ink, text the canvas color;
  - box-shadow `inset 0 1px 0 rgb(255 255 255 / .16), 0 8px 20px -10px rgb(15 23 42 / .5)`;
  - on hover, opacity .86.
  - Sizes: 40 px tall with padding 0 16 (nav), 48 px with padding 0 28 (hero), 14 px words at weight 500.
- **Glass link card:** blur 28, saturate 1.6, radius 24, padding 28 by 32; shadow `inset 0 1px 0 rgb(255 255 255 / .95), 0 24px 60px -28px rgb(15 23 42 / .28)`.
- **Type:** `web.md`, "Type" (hero 76 px, sections 60 and 54 px, rows 34 px, lede 17 px).
- **Shadows use slate** (15 23 42), never pure black.
- **Dark mode** exists (glass at 6% white with a 12% white border), but the page is designed and shown light.

## The menu: a pill that becomes a panel

The signature interaction. The owner wants it whenever a site has a menu.

- **Closed:** the centered glass pill, 52 px tall like the logo circle, with "≡ Menu".
- **Opening:** the pill grows in place into a frosted panel anchored at the top center (520 px wide on desktop; the screen width minus 16 px gutters on phones, about 630 px tall there).
  - The growth takes about 450 ms on an ease-out curve, fast at first and settling softly.
  - The pill's row becomes the panel's header, reading "× Close".
- **Panel content (desktop):** two columns.
  - A small uppercase label over each group (PRODUCT, SOLUTIONS).
  - Main links at 26 px, weight 500, in ink. Secondary links at 15 px in gray, slightly indented.
  - A hairline, then a "SOCIAL MEDIA" label with small links, and small FAQ and Changelog links on the right.
  - On phones, one column in the same order.
- **Content reveal:** each link starts 18 px lower at opacity 0 and rises into place, in sequence (about 40 ms apart, starting as the panel nears full size).
- **Closing:** faster, about 250 ms, the panel shrinking back into the pill, with links fading first.
- **Reduce Motion:** the panel appears and disappears without growing or staggering.

**The working code** is `.menu-morph` in `assets/web/tokens.css`, used live in the style board's nav (`specimen.html`): one element with the glass control look, 112 by 52 px, that grows to the panel.
- **Open:** the panel fill is white at 92% (so the words read), `backdrop-filter: blur(32px) saturate(1.7)`, shadow `0 32px 80px -32px rgb(30 45 80 / .4)`, radius 28.
- **The content** is laid out at the open width all the time and centered, so it never reflows while the panel grows.
- **JavaScript sets** `--menu-h` from the content's height on open, `--i` per item, `inert` on the links while closed, and `aria-expanded` on the toggle. Clicking outside, Escape or a link closes it.

(On spacefs itself the 52 px pill sits in a 128 by 68 px wrapper with 8 px padding; the single element gives the same look.)

**A site that promises no scripts** (Toll's privacy text says so) keeps the same menu without JavaScript: the panel is a `popover` opened by the pill's `popovertarget` (Escape, a tap outside and Close work natively), it grows with `@starting-style` and `interpolate-size: allow-keywords`, and its in-page links add a query (`./?to=plans#plans`) so the page reloads at the section with the panel closed. The product story runs on CSS view timelines (`timeline-scope`), stacked steps where unsupported, and the font is served from the site.

## Phones (390 px)

Everything in `web.md`, "Phones first". The spacefs specifics: the nav's Download pill hides below 640 px (the hero has its own), the hero headline is `clamp(40px, 10vw, 48px)` and stays two-tone, and the menu panel is one column at the screen width minus 16 px gutters.
