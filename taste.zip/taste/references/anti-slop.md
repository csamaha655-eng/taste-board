# Anti-slop

"AI slop" is the owner's word for generic, machine-made design, and it is the fastest way to lose their trust. Run this file before showing anything.

## What strangers actually call AI slop

In October 2026 about 85 developers and users on Reddit judged one of the owner's apps in public. Several called it AI slop or vibe-coded (every comment, as a rule, is in `real-users.md`). These are the patterns behind what they named. They apply to apps, store pages and websites alike.

1. **Dark ground with colored light.** Strangers read a black or near-black screen with a purple, blue or neon glow as a sign of an AI-generated app. Two separate comments said it was too dark and others agreed. **Default to light.** Dark follows the dark rule in `themes.md` (only when the owner asks, or for a dark-room product) and is always flat: no glow, no colored light.
2. **Rendered 3D and fake materials.** These read as generated even when made by hand:
   - ray-marched or Blender objects;
   - terrain and landscape renders;
   - glossy flames;
   - metal coins, medals and badges;
   - embossed seals;
   - "studio" product renders of things that aren't the product.

   Use flat marks drawn in code (SF Symbols, simple shapes, one solid color) or real photographs.
3. **Generic stock imagery.** Dumbbells on a floor, a laptop on a desk, a sunrise: things that could be in any app. Use real photos specific to the moment the product creates, and the product itself.
4. **Metaphors the reader must decode.** "The gate opens", "pay the toll", "your apps wait", "enter the portal", "begin your journey". Strangers asked what the metaphor even meant and called the tagline AI-written. Say the mechanic plainly, so a 10-year-old understands it: who does what, and what happens.
5. **Taglines that say nothing.** Broad headers, moods and slogans. People want, in a few words:
   - what it does;
   - for whom;
   - what pain it removes.
6. **Gray UI with tiny text and no personality.** In screenshots and heroes, an app that looks like a settings menu reads as cheap. Show the outcome and the feeling with big type and real content.
7. **Zero states and meaningless numbers.** A "0", an empty list, or a placeholder in a screenshot or a hero tells the viewer nothing works yet.
8. **Unclear at a glance.** People could not tell what the app was from the icon, the name and the first screenshot, and guessed wrong (a gym app, a religious app). Clarity beats style; see the 2-second test below.
9. **Half-finished details.** A faded see-through tile, a crowded row of tiny icons, a raw system error shown to users, or a screen that still wears the old style. Inconsistency is how people spot a "vibe-coded" app.
10. **Prices that look generated.** A round .99 ladder with no logic reads as machine-made; prices come from `app-strategy` (`references/model-and-price.md`).
11. **A symbol that misreads.** Arches and light rays read as religious imagery, and a domed door as a bank or a museum. Blind-test every icon and hero symbol.

The rule under all of them: real, plain and specific reads as made by a person; decorative, metaphorical and generic reads as made by a machine.

## The gradient rule

The owner's words: "AI slop is literally gradient colors. I don't want that."

**Banned:**
- any blend between two or more hues (purple to pink, blue to teal, orange to pink, aurora, mesh, holographic, rainbow);
- any gradient on buttons, text, icons, chips, cards, borders, rings, progress bars, tab bars or whole-page backgrounds;
- glow blobs and colored halos behind elements (the one atmosphere below is the only exception).

**Allowed, because they read as light or function, not as color:**
- shadows and the system's own Liquid Glass;
- opacity fades used as masks (a scroll-edge feather, the progressive blur under a floating nav);
- a white specular highlight on a glass edge;
- CSS gradient functions that draw hard-edged patterns (dots, hairlines);
- the iOS app design's atmosphere only (the owner's style-board phones): one light, desaturated hue used as soft light at the top, behind the frosted sheets, falling into the neutral canvas. One per screen. Never on anything tappable, never behind a card, button or element as a glow, never in a dark palette except Midnight when the owner names it, and never on websites (spacefs has no atmosphere; its ornament is the hard-edged dot field);
- a logo the owner already loves keeps its own art.

When in doubt, go flat.

## Visual slop

**Generic looks** (the full list of AI-made palettes is in `themes.md`, "Looks that read as AI-made"):
- a dark ground lit by purple or blue glow;
- purple or violet as the brand color;
- the purple-to-blue hero on white;
- warm cream with a serif and a terracotta accent;
- near-black with an acid-green pop;
- Inter, Poppins or Space Grotesk as the default face;
- several typefaces on one page.

**Type and emoji:**
- thin or light weights ("skinny text");
- emoji anywhere in the UI;
- sparkle icons for AI, stock 3D blobs, meaningless dashboard charts.

**Templated structure:**
- the repeated "icon in a tinted circle" row;
- three identical feature cards with icons;
- badges and pills sprinkled around;
- cards inside cards;
- the same radius and shadow on every box;
- everything centered (a centered hero is fine, as on spacefs; the sections below it are left-aligned editorial rows);
- accent bars on card edges;
- numbered markers (01/02/03) on things that are not a sequence (spacefs's numbered feature rows are the one exception).

**Color:**
- gold that looks like medals, coins or stone, or like a "military" or "school" app;
- low-contrast gray-on-gray text, or decoration gray (`--ink-3`) used for words.

**Dead space:**
- empty bands, lone elements, the top 20% of a screen holding nothing.

**Art and images:**
- art pasted on as a rectangle with edges ("looks screenshotted");
- a logo sitting in a white box;
- images cropped at the top or bottom.

**Scrolling artifacts:**
- a band or black block that appears on scroll;
- a dark floor under the tab bar;
- black overscroll;
- visible scroll indicators.

## Copy slop

- Hype words: "unlock" (as a hype word; "your apps unlock" as a plain fact is fine), "unleash", "elevate", "supercharge", "seamless", "revolutionize", "next-level", "all-in-one", "journey", "embark".
- Motivational lines that could belong to any app, filler subtitles, exclamation marks.
- Invented metaphors for how the product works ("the gate", "the toll", "the vault"). Name the real thing ("your locked apps").
- Childish framing for adults: cookies, levels and trophies in the first impression. Adults want their own rule and their own commitment (games and kids' apps differ).
- Raw error text from the system ("The operation couldn't be completed"). Every error says what happened and what to do, in the product's voice.
- Several words for one thing ("free week", "trial", "your week"). Pick one and use it everywhere.
- Fake testimonials, user counts or customer logos.
- Copy borrowed word for word from the reference app.

Write in the product's own vocabulary, short and concrete.

## Motion slop

- Animated splash screens, confetti, bouncy springs everywhere.
- Parallax on every element, auto-advancing carousels, scroll-jacking.
- Typing-effect headlines.
- Content left invisible until an observer fires.

## Before you show: the checklist

1. Is any fill a gradient? Search the code for `gradient`, `LinearGradient`, `RadialGradient`, `AngularGradient`, `MeshGradient`, and any `.blur(` or `filter: blur` on a colored shape, and justify every hit against the allowances above.
2. Is any text thinner than 400, or any heading thinner than 500?
3. Is there more than one typeface family, or more than one accent? (Exceptions: the mono sibling, and SF Pro inside iOS device mockups.)
4. Is any screen or section empty? Is any cluttered?
5. Is there any emoji, sparkle, fake data or lorem? Is any feature, price, stat or link invented without being listed under "To replace"?
6. Does it scroll cleanly: no bands, no black overscroll, no cropped images, no indicators?
7. Is all text at least 4.5:1 contrast, and is every touch target at least 44 pt?
8. Have you checked light, dark (if supported), phone width, large text, Reduce Motion and Reduce Transparency?
9. Would a stranger guess it was made by AI? Would the owner call it "AI slop"? Fix that part.
10. Is it better than the version before? If not, keep the old one.
11. Did you look at every screen, sheet, state and email or notification text, not just the main screens? Old art hides in sheets.
12. Is any image a 3D render, a metal or glossy object, a glow, or generic stock? Each image must be a real photo or flat art.
13. Is the screen light? If it's dark, does the dark rule in `themes.md` allow it?
14. Is there a word the reader has to decode (a metaphor, an invented term, jargon)? Replace it with plain words.
15. Does the first screen (hero, onboarding page 1, first store screenshot) pass the 2-second test below?

## Quality tests (from the owner's website guides)

- **2-second test (apps and store pages):** from the icon, the name, the subtitle and the first screenshot alone, a stranger can say what the app does in one sentence. If people guess wrong (for example "a gym app" for an app blocker), the category word must come first.
- **5-second test:** after 5 seconds on the first screen, a stranger knows what it is, who it's for and what to tap.
- **Squint test:** blur your eyes. You should still see one dominant element, then the secondary ones, then the CTA.
- **No-animation test:** with every animation off, the page still looks finished. Motion must not hide weak design.
- **No-3D and slow-network test:** before the 3D or video loads, or without it, the hero still communicates and nothing jumps.
- **Mobile test:** nothing depends on hover or the cursor; there's no horizontal overflow; targets are at least 44 px.
- **Pre-launch (web):**
  - a title of 60 characters or fewer and a meta description of 160 or fewer;
  - a favicon and an OG image;
  - compressed images;
  - every link working;
  - privacy and terms pages;
  - HTTPS on the custom domain.
