# App ideas: is it worth building?

When the owner asks for a new app, or asks whether an idea is good, crowded or "saturated", research it before writing code and give him a one-screen verdict.
- **He asked to create the app:** for "Build" or "Build with a twist", start building straight away with the design defaults; he doesn't want to be asked. For "Don't build", stop and wait for his word.
- **He only asked a question:** answer with the verdict and don't start building.
- **He says "just build it":** skip the research and say in one line which twist you are betting on.

**Why this exists:** Toll was built from one person's own pain. It launched into the most crowded category on the App Store, and the most-upvoted replies on Reddit were about the idea, not the app:
- many apps already do this, so why this one;
- it looked like the first idea anyone (or any AI) has;
- a sample of one, the founder, is not validation;
- competitors, keywords, screenshots, paywalls and prices were never checked before coding.

The design could be fixed in days; the idea's position is much harder to change after launch. Research takes 20 to 40 minutes. Use web search and the App Store itself, plus the owner's Chrome if he allows it. Never rely on what you remember: AI research misses key players, so search the store for each term.

## The research, in this order

1. **Name the job in one sentence:** the person, the pain, and the outcome they want. If you can't, the idea isn't clear yet. Sharpen it first.
2. **Is it already free?** Check whether iOS, Android or a big free app already does it: Screen Time, Reminders, Health, Notes, Photos, Google Keep, ChatGPT. If one does, the app needs a reason a stranger understands in one line. Toll's was "Screen Time has an Ignore button; this doesn't." If no such line exists, stop.
3. **Count and study the competitors.** Search the App Store (US, plus any market the owner targets) for the 5 to 10 phrases a user would type. For the top 10 results per phrase, note:
   - the name and how long it's been out;
   - the rating count and the stars;
   - the price model and the latest update.

   Look at the category's top free and top grossing charts too. For the top 3, save their first three screenshots, their onboarding length and their paywall type: the category's proven conventions to follow. **Saturation signs:**
   - 10 or more apps with over 1,000 ratings for the main phrase;
   - leaders with over 50,000 ratings that still ship updates;
   - new clones every week on Reddit and Product Hunt;
   - store names that all sound alike.
4. **Check the money: do people already pay?**
   - the leaders' prices and paywall types;
   - their top-grossing ranks;
   - public revenue estimates (Sensor Tower and Appfigures pages, founders' posts, RevenueCat's yearly report).

   No paying competitor is a warning sign, not a verdict. Find out whether demand is weak, the money is hard to get, or a group is underserved. Also ask what people already pay for offline that does the same job (a coach, a trainer, a class).
5. **Read the reviews.** Read 1- to 3-star reviews of the top 3 to 5 apps for what is missing and what makes people angry. Read 5-star reviews for what they love. A gap that many angry reviews share is an opening.
6. **Find demand outside the store:** Reddit threads, TikTok and YouTube, Google Trends, and keyword popularity in Apple Ads (popularity 1-5) for the main phrases.
7. **Plan how the first 1,000 users arrive.** Options:
   - organic short video (it grew app blockers like Brick and Pushscroll);
   - communities;
   - creators;
   - a search phrase with low competition;
   - SEO.

   If the only answer is paid ads, that is a risk. Compare cost per install with the money each install brings: Toll paid $5.54 per install and earned $0.
8. **Find the one axis a solo developer can win on.** It must be:
   - visible in the first screenshot;
   - wanted (the reviews ask for it);
   - not trivial for the leaders to copy.

   Never fight a leader on its core: don't take on Boostcamp at gym tracking or Yazio at calories. Go where the leaders are weak, or to a group they ignore.
9. **Test the recurring behavior.** Ask whether people want to do what the app requires again and again: a photo every day, a check-in, logging. Several strangers rejected Toll's mechanic itself ("too much friction", "I'm not twelve", "the proof belongs to the user"). If the core action feels like a chore or a punishment to the target group, rethink the mechanic before the design.
10. **Real people, done by the owner.** Before months of work, put the idea in front of 10 to 50 people in the target group who have no reason to be nice. Use a landing page with a waitlist, a TestFlight for 25 users, or direct messages in a community. One person, the owner, is not validation.

## How sure to be

Competitor counts, rating thresholds and the crowded list below are signals, not verdicts. In the verdict:
- cite dated sources and the storefront for every number;
- label estimates, and say what you couldn't see;
- state your confidence;
- name the cheapest test that would change your mind.

## Treat these as crowded unless the twist is strong

These categories got the "another one?" reaction:
- habit trackers, to-do lists, notes and journaling;
- calorie and macro counters, water reminders, workout loggers;
- focus timers, app blockers, budget trackers, meditation;
- AI chat wrappers;
- wallpaper, QR, flashlight and other utility apps;
- horoscopes and flashcards.

They are not banned. But the difference must be visible at a glance and wanted by real people, and the owner must know it before building.

## Signs an idea is worth it

- A specific person with a costly pain that comes back often.
- Paying competitors whose bad reviews share one fixable gap.
- A way to reach users that the owner controls.
- An idea he can explain in five words.
- An outcome that shows in one screenshot.
- People already pay for the same job offline.

## The verdict to send (one screen, plain words)

- **Verdict:** Build, Build with a twist, or Don't build, with why in two lines.
- **Market:** crowded or open, with the 3 to 5 leaders, their rating counts and prices.
- **The free alternative** and the one-line answer to it.
- **The difference that sells,** written as the first screenshot's caption.
- **The name:** searchable, free on the store, not misread as another category, and paired with the category word in the store title.
- **Who pays and how much,** with starting prices (see `app-launch.md`).
- **How the first 1,000 users arrive.**
- **The biggest risk** and the cheapest test of it. Build that test (a waitlist page or a 25-person TestFlight) in the first phase.
- **App Review risk:** in a crowded category, guideline 4.3(b) (spam) can reject an app that looks like one more of the same. The twist must be obvious on the first screen and in the review notes.
- **If "Don't build":** the better idea next door, if there is one.

If he asked to create the app and the verdict is "Build" or "Build with a twist", build. Carry the difference into onboarding screen 1, the first store screenshot and the website hero. For "Don't build", or a question only, stop after the verdict.
