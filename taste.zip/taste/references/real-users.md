# What real people said, turned into rules

In October 2026 the owner posted his app's launch numbers on r/AppBusiness and r/AppStoreOptimization and asked what was wrong:
- 5 days live;
- $294 of Apple Ads;
- 57 downloads;
- 0 paying users.

About 85 developers and users answered in public. Every comment was read, and each concept is below. The comments are paraphrased, never pasted, next to the rule it gives and where the skill applies it.

This is the owner's most valuable outside signal. Read it when starting a new app, when a decision feels like taste versus evidence, and when updating the skill. When new feedback arrives (more comments, App Store reviews, testers), add its concepts here the same way and push them into the matching reference.

How to weigh them:
- Many people saying the same thing independently is strong evidence. One clever comment is a hypothesis.
- Hostile one-liners still count when they repeat a theme ("slop" five times is a signal about the look).
- Comments that attack the concept are about the idea, not the design. Read them as market research (`app-idea.md`) and as presentation lessons, and let the owner decide on the concept.

## 1. The idea and the market (`app-idea.md`)

| What people said, in short | The rule |
|---|---|
| Many said a thousand apps already do this, that new ones appear daily, and asked why this one is better. | Before building, count the competitors and name the one difference. If it can't be said in one line, don't build yet. |
| The top-voted comment asked why so many people build habit apps, and whether it's the first idea any AI suggests. | Treat the ideas an AI suggests first (habit trackers, to-do lists, journals, calorie counters, blockers) as crowded by default. Building one needs a twist strangers can see at a glance. |
| Several said these apps are easy to build (no backend), so everyone builds them. | Easy to build means easy to copy and crowded. Prefer ideas with a moat: data, a network, hard tech, a niche the big apps ignore, or distribution the owner controls. |
| One said the founder built it for his own pain, which is a sample of one; real validation is asking about 50 people with no reason to lie. | Validate with strangers in the target group before months of work: a waitlist page, a 25-person TestFlight, direct questions in a community. The owner's own need is a start, not proof. |
| One asked whether market research, competitor checks, keyword research, screenshot and paywall comparisons and pricing were done before any code. Another said AI research had missed key players. | Run the full research in `app-idea.md`, with real App Store searches per keyword and per storefront, not memory. Cite sources. |
| One advised studying competitors, downloading them, following their proven core and doing a few things better. | Copy the category's proven conventions (onboarding length, paywall type, screenshot style) and differ on one axis. |
| One said you can't beat the established gym or food trackers at their own core, so you'll never win those users. | Never fight a leader on its main feature. Go where leaders are weak, or to a group they ignore. |
| Several asked whether the free built-in Screen Time already does this, and why an app is needed when it's in Settings. | Check the free built-in alternative first. The product must say, in one line, what the built-in can't do, on screen 1, store frame 2 and the website. |
| Several asked who would pay, especially a subscription, to lock their own phone, and whether any real-world parallel exists. | Check willingness to pay: do people pay competitors, or pay offline for the same job (coaches, trainers, classes)? Use that parallel in the positioning. |
| Some said the mechanic itself adds friction: they want to build habits, not send photos, and the proof belongs to the user. | Test whether target users want to do the core action again and again. A chore or a punishment kills retention. |
| One said the core idea (live photo verification) was genuinely interesting, and the bottleneck was the onboarding. | Find the part strangers praise and lead with it everywhere. |
| A few said it's a trend that will pass, and to solve a real problem instead. | Prefer lasting, specific problems over trends. If the idea rides a trend, know the exit. |
| Several advised dropping it and building something more original. | When the verdict is weak, say so plainly and suggest the better idea next door. The owner decides. |
| One said the market had simply answered: nobody pays for a generic, AI-looking tracker. | Silence after a fair test is the market's verdict. Write the success bar and the stop rule before launch, then follow it instead of polishing forever. |
| One said 5 days is too early to judge. | Give a launch 2-4 weeks and about 100 paywall views before judging the price or the model. Judge the funnel step by step. |
| One agency said that in a saturated category with polished leaders, an app with no truly new feature will be buried. | The verdict states the realistic ceiling. A crowded category also risks rejection under App Review guideline 4.3(b) (spam) unless the app is clearly unique and of high quality. |

## 2. Clarity: can a stranger tell what it is? (`anti-slop.md`, `app-launch.md`)

| What people said, in short | The rule |
|---|---|
| Many could not tell what the app does from the icon, the name, the screenshots or the description, or lost interest at first glance. Several said so in other languages. | The 2-second test: from the icon, the name, the subtitle and the first screenshot, a stranger can say what it does in one sentence. |
| One guessed it was a gym app until reading the description. | The category word comes first (the name says "App Blocker"); the example (the gym) comes second. |
| Several said the first screen should sell the value: why I'd want it, what it does, what pain it removes, in as few words as possible. | Screen 1 of the onboarding, store frame 1 and the website hero each answer those three questions. |
| One said the first screenshot made no sense, but the second was the aha moment, and the set had no single message. | Put the aha first. Every other frame supports that one message. |
| One said the first gallery image must really pop. | Frame 1 gets the strongest contrast, the biggest caption and a real moment. |
| One said a screenshot showing a 0 means nothing, and the Home screen should show the aha moment. | Never a 0, an empty state or "Day 0" in a screenshot. Home leads with the user's next action and its result. |
| One said the header text was too broad, not direct. | Captions and headlines say the concrete thing, not a mood. |
| One said the name doesn't sound like self-improvement and suggested rethinking it. | Names should hint at the benefit or category. If the name doesn't, the store title carries the category word ("Toll: App Blocker for Habits"). |

## 3. The look (`anti-slop.md`, `themes.md`, `ios.md`)

| What people said, in short | The rule |
|---|---|
| Two separate comments said it was too dark, others agreed, and one called dark a giveaway of AI-generated apps. | Light by default for apps, store pages and websites. Dark only when asked or for truly dark-room products, and then flat with no colored light. |
| A developer said that in his A/B tests, light screenshots won clearly more impressions than dark. | Store screenshots and website visuals are light. |
| About six people called it "slop" or "AI slop", and three called it vibe-coded. | The design must not look generated. See the full list of tells in `anti-slop.md`. |
| One said the screenshots were functional but had zero personality: gray UI, tiny text, like a settings menu. | Big type, real moments and the product's feeling. Never a settings screen or a list of features. |
| One said the gates and light looked like religious imagery, beside generic dumbbells. | Symbols must not misread. Blind-test icons and hero art. Generic stock objects read as filler. |
| One said all the store images look the same. Another said three of the first four frames looked alike. | One message, but different moments and layouts per frame; never two frames on the same screen. |
| A founder said he only understood the concept after reading the title, about 7 seconds in; the screenshots left him asking how it works and whether it suits him, though he liked the idea. | Frame 1 must be understood without the title. One early frame shows how it works in 2-3 steps, and the set answers "is this for me?". |
| One said it looks amazing (after the light redesign started). | Light, clean and real works. Keep going in that direction. |

## 4. Words (`anti-slop.md`)

| What people said, in short | The rule |
|---|---|
| One said the tagline was pure AI slop. Another said to turn off AI copywriting and explain it as if to a child, because the writing was esoteric and fluffy, and asked what the gate was and who gates it. | Plain words, who does what, no invented metaphors. Write a glossary early and use it in every string. |
| One said the carrot-and-stick framing is infantilising for adults (proving homework to get a cookie). | Adult framing: their rule, their commitment. No kid rewards in the first impression (games and kids' apps differ). |
| One asked who wants such an intrusive app in their life. | Show control and consent: you pick what's locked, calls and messages stay open, and there is always a way out. |
| One asked how the proof works: can I upload a picture of weights, and who decides it's proven? | Answer the skeptic on screen 1-2 and on the store page: where the check happens, what counts, what happens on a failure. |

## 5. Onboarding (`app-launch.md`)

| What people said, in short | The rule |
|---|---|
| Many said 15 screens before the price is far too long; people leave after about 3 swipes; 3-5 screens max. | At most 4 tap-only screens before the price, each building value. |
| A former product manager disagreed: successful apps (Cal AI and others) use about 25 screens to build value before the paywall. | Long works only with strong intent and screens that each build value (a plan, a projection, a personal result). Measure, and add a screen only when the data asks for it. |
| Several said: get them to the permission and their first habit in 3-4 screens, and let them feel the core thing before asking for money. | An interactive demo of the core result comes before the price. Real setup comes right after it. |
| One said to show what the app does before the Screen Time ask. | Never ask a permission before the user knows why. Each permission has a primer. |
| One said: find which screens lose people, and have onboarding analytics. | Log every onboarding screen from the first build. Fix the biggest drop first. |

## 6. Paywall and price (`app-launch.md`)

| What people said, in short | The rule |
|---|---|
| Several said the price was steep for an unproven app with zero reviews. One said the $39.99 / $9.99 / $119.99 ladder looked like an AI made it. | Price below the leaders while the app has no ratings, on a ladder with a reason. Never a generic round ladder. |
| One said seven paywall views are too few to judge the price; fix the drop-off first. | Don't judge the price before about 100 paywall views. |
| One said: track paywall actions. About half of those who start a purchase should finish. If many start and few finish, look for a bug or a price mismatch; if nobody starts, redesign the paywall. | Log paywall view, purchase started and purchased, then diagnose with those three numbers. |
| Several said to sell the user's success and feeling, not features. | The paywall and the screenshots sell the outcome. |
| Several said to push the free trial harder. | The free trial is the main path, shown honestly (the billed price stays most prominent). |
| One said people expect free apps and avoid paying, and suggested subscriptions or feature paywalls. Another said to charge only after the first proved habit. A third, a founder, said a hard paywall is very bad for a habit app: he would leave the moment he saw one. | Pick the model from the category's norms. Where the leaders give a free core (habit trackers, journals, to-do lists), a hard paywall before any use loses people: let them use the core free, at least until the first real success, then sell Pro. A hard paywall with a trial suits utilities whose value shows in the first minute. Three or more strangers objecting to the same model is a signal to test the other one. |

## 7. Store page and search (`app-launch.md`)

| What people said, in short | The rule |
|---|---|
| Several said: put the category ("App Blocker", "Screen Time") in the title, since the subtitle had no search terms. | The title is "Name: category words"; the subtitle and keywords carry searched terms. |
| One said a 1.9% tap-through rate means people don't understand the app at a glance. | A low tap-through rate means the icon, name and first frame are unclear. Fix the store page before spending on ads. |
| One said to fix the store listing before ads. | Order: store page, onboarding, paywall, then traffic. |
| Several said the page needs honest reviews (friends, or the first 25 target users getting it free for feedback) because zero ratings looks abandoned. | Get early honest ratings without conditions. Ask for a rating after the first real success. |

## 8. Ads and distribution (`app-launch.md`)

| What people said, in short | The rule |
|---|---|
| Many said to stop the ads: $5.54 per install with $0 revenue loses money on every install. | No paid ads until the funnel converts. Compare cost per install with revenue per install. |
| Several said the ads were working; the leak was after the install. | Find the leaking step before changing traffic. |
| One said to read the search-terms report, since broad terms like "screen time" bring people who wanted Apple's built-in feature. | Exact match on intent terms only; exclude terms that name a free built-in feature. |
| One said to look for cheaper keywords. | Long-tail terms a new app can win, not head terms. |
| One said ad algorithms need $1,000-3,000 to learn. | True for Meta and TikTok, not for Apple Search Ads (a keyword auction). Don't start social ads without that budget. |
| A developer making about $10,000 a month said Apple Ads were unprofitable for him too. | Don't count on Apple Ads for a low-price app. |
| Several said organic marketing (short video, Reddit) is the way. One said that in a saturated niche, the money should go to UGC (creators' short videos), not ads. | Plan organic launch posts and short videos from the start. With a budget in a crowded niche, pay small creators for short videos before paying for ads. |
| One suggested $300 a day. | Never scale spend on a funnel that doesn't convert. |
| Some wrote in other languages; the ads had bought French traffic for an English-only app. | Localize the store page for every market you target, or exclude it from ads. |

## 9. Trust and conduct

| What people said, in short | The rule |
|---|---|
| Several assumed it was a vibe-coded app built only to make money, and that such founders don't support their apps. | Show care: a real founder story, a support page, timely updates and consistent polish. Inconsistent screens are how people spot a vibe-coded app. |
| A stranger offered a 50/50 split to publish their app on the owner's developer account. | Never publish strangers' apps on your account; it puts every app on it at risk. Decline politely. |
| One noted how desperate wording loses trust. | Public replies stay calm, short and specific. |
| A growth-tool founder gave useful advice while promoting his tool. | Take the advice and ignore the pitch. |

## 10. The owner's own reactions on his phone (as binding as any comment)

| What he saw | The rule |
|---|---|
| A dark, rendered 3D flame on the streak screen that didn't match the light app. | No rendered 3D. Every sheet must match the theme; check every sheet before shipping. |
| The rest day's purple metal coin. | No metal, coins or medals; flat marks drawn in code. |
| A faded see-through padlock tile on the first page. | Solid, crisp marks. Dimmed reads as disabled or unfinished. |
| His own gym photo in the app. | Never use the owner's personal photos unless he hands them over for that use. |
| A build was submitted after checking only the main screens. | Before any submission, capture and look at every screen and sheet, and send him the contact sheet. |

## 11. App Review (`app-launch.md`)

| What happened | The rule |
|---|---|
| Toll 1.1 was rejected under 3.1.2(c): the free trial was more prominent than the billed price. | The billed amount is the most prominent price element. Trial terms are readable and placed under it. |
