# What real people said, turned into rules (design and building)

In October 2026 the owner posted his app's launch on Reddit (r/AppBusiness, r/AppStoreOptimization); about 85 developers and users answered in public. Each comment was read and weighed. This file keeps the lessons about how apps look, read and flow, paraphrased, never pasted. Business lessons are in `app-strategy`, marketing lessons in `app-marketing`, and how a comment earns a place is in `app-strategy`'s `references/feedback.md`.

## 1. Clarity: can a stranger tell what it is? (`anti-slop.md`, `app-launch.md`)

| What people said, in short | The rule |
|---|---|
| Many could not tell what the app does from the icon, the name, the screenshots or the description, or lost interest at first glance. Several said so in other languages. | The 2-second test: from the icon, the name, the subtitle and the first screenshot, a stranger can say what it does in one sentence. |
| One guessed it was a gym app until reading the description. | The first impression names the category (an app blocker) before the example (the gym). |
| Several said the first screen should sell the value: why I'd want it, what it does, what pain it removes, in as few words as possible. | Screen 1 of the onboarding, store frame 1 and the website hero each answer those three questions. |
| One said the first screenshot made no sense, but the second was the aha moment, and the set had no single message. | Put the aha first. Every other frame supports that one message. |
| One said a screenshot showing a 0 means nothing, and the Home screen should show the aha moment. | Never a 0, an empty state or "Day 0" in a screenshot. Home leads with the user's next action and its result. |
| One said the header text was too broad, not direct. | Captions and headlines say the concrete thing, not a mood. |

## 2. The look (`anti-slop.md`, `themes.md`, `ios.md`)

| What people said, in short | The rule |
|---|---|
| Two separate comments said it was too dark, others agreed, and one called dark a giveaway of AI-generated apps. | Light by default for apps, store pages and websites. Dark only when asked or for truly dark-room products, and then flat with no colored light. |
| A developer said that in his A/B tests, light screenshots won clearly more impressions than dark (one person's claim; it agrees with the row above). | Store screenshots and website visuals are light. |
| About six people called it "slop" or "AI slop", and three called it vibe-coded. | The design must not look generated. See the full list of tells in `anti-slop.md`. |
| One said the screenshots were functional but had zero personality: gray UI, tiny text, like a settings menu. | Big type, real moments and the product's feeling. Never a settings screen or a list of features. |
| One said the gates and light looked like religious imagery, beside generic dumbbells. | Symbols must not misread. Blind-test icons and hero art. Generic stock objects read as filler. |
| One said all the store images look the same. Another said three of the first four frames looked alike. | One message, but different moments and layouts per frame; never two frames on the same screen. |
| A founder said he only understood the concept after reading the title, about 7 seconds in; the screenshots left him asking how it works and whether it suits him, though he liked the idea. | Frame 1 must be understood without the title. One early frame shows how it works in 2-3 steps, and the set answers "is this for me?". |

## 3. Words (`anti-slop.md`)

| What people said, in short | The rule |
|---|---|
| One said the tagline was pure AI slop. Another said to turn off AI copywriting and explain it as if to a child, because the writing was esoteric and fluffy, and asked what the gate was and who gates it. | Plain words, who does what, no invented metaphors. Write a glossary early and use it in every string. |
| One said the carrot-and-stick framing is infantilising for adults (proving homework to get a cookie). | Adult framing: their rule, their commitment. No kid rewards in the first impression (games and kids' apps differ). |
| One asked how the proof works: can I upload a picture of weights, and who decides it's proven? | Answer the skeptic on screen 1-2 and on the store page: where the check happens, what counts, what happens on a failure. |

## 4. Onboarding (`app-launch.md`)

| What people said, in short | The rule |
|---|---|
| Many said 15 screens before the paywall is far too long; people leave after about 3 swipes; 3-5 screens max. Toll's own funnel agreed: 25 started, 7 reached the price. | At most 4 tap-only screens before the paywall, each building value. |
| A former product manager disagreed: successful apps (Cal AI and others) use about 25 screens to build value before the paywall. | Long works only with strong intent and screens that each build value (a plan, a projection, a personal result). Measure, and add a screen only when the data asks for it. |
| Several said: get them to the permission and their first habit in 3-4 screens, and let them feel the core thing before asking for money. | An interactive demo of the core result comes before the paywall. Real setup comes right after it. |
| One said to show what the app does before the Screen Time ask. | Never ask a permission before the user knows why. Each permission has a primer. |
| One said: find which screens lose people, and have onboarding analytics. | Log every onboarding screen from the first build. Fix the biggest drop first. |

## 5. The owner's own reactions on his phone (as binding as any comment)

| What he saw | The rule |
|---|---|
| A dark, rendered 3D flame on the streak screen that didn't match the light app. | No rendered 3D. Every sheet must match the theme; check every sheet before shipping. |
| The rest day's purple metal coin. | No metal, coins or medals; flat marks drawn in code. |
| A faded see-through padlock tile on the first page. | Solid, crisp marks. Dimmed reads as disabled or unfinished. |
| His own gym photo in the app. | Never use the owner's personal photos unless he hands them over for that use. |
| A build was submitted after checking only the main screens. | Before any submission, capture and look at every screen and sheet, and send him the contact sheet. |

## 6. App Review (`app-launch.md`)

| What happened | The rule |
|---|---|
| Toll 1.1 was rejected under 3.1.2(c): the free trial was more prominent than the billed price. | The billed amount is the most prominent price element. Trial terms are readable and placed under it. |
