# Shipping an app: onboarding, paywall, price, store page

What real people taught the owner when Toll (an iOS app blocker) launched in October 2026. The evidence:
- about 85 comments from developers and users on r/AppBusiness and r/AppStoreOptimization (each one, as a rule, in `real-users.md`);
- Toll's own funnel data (TelemetryDeck, App Store Connect, Apple Ads);
- 7,836 reviews of 20 competitors;
- one App Review rejection.

Load this file for every new app and every onboarding, paywall, price or store page, and before any App Store submission. It sits on top of the laws in `SKILL.md`. Where the owner's newest words differ, follow them.

**How to read it:** these are observations and working defaults from one launch, not proven results. Strangers' opinions, the owner's preferences, outside benchmarks and Toll's measured numbers are labeled as such. Start from these defaults, adjust them to each app's market, and measure. When you report numbers, keep source, dates and denominator together, and never mix counts from different windows into one funnel.

## What strangers read as AI-made

The full list of tells is in `anti-slop.md`, and the evidence, comment by comment, is in `real-users.md`. The ones that cost Toll most:
- a dark screen lit by colored glow;
- rendered 3D and metal art;
- invented metaphors in the copy;
- taglines that say nothing;
- gray screenshots with tiny text and zero states;
- an icon that didn't say what the app does;
- a price ladder with no logic.

The shared rule: if a stranger has to decode it, or it looks generated, it reads as AI. Real, plain and specific reads as made by a person.

## Onboarding

Toll's first onboarding had 15 screens before the price. In-app analytics (8-10 October) showed 25 people starting it, 7 reaching the price and 1 starting a trial. It was rebuilt like this:

- **At most 4 screens before the price,** tap-only, with one decision per screen and nothing typed.
- **Screen 1 says what the app does and the difference.** It also answers the objection every visitor has. "Doesn't Apple's free Screen Time do this?" became "Screen Time limits have an Ignore button. Toll unlocks with proof of your habit."
- **They feel the core result before any permission or price.** Use an interactive demo: they tap the shutter, see the verdict, and watch the apps unlock. Never take a real, hard-to-undo action before they commit (locking apps, sending, charging): it earns the angriest 1-star reviews.
- **Personalize with one tap** (a habit, or an hours chip with "a guess is fine"), then show their own choice back to them as a result (Toll: their own days a year). Skip it if no honest number exists.
- **Answer the skeptic before they ask:** how it knows, whether it can be fooled, what happens to their data, and how little it asks each day (one photo, five seconds). Do it on screens 1-3, in one store caption and in the website's FAQ.
- **No name, age or identity questions** unless the answer changes something they see. Typing and identity questions are where people left.
- **Ask each permission when its purpose is clear** (in Toll's flow, right after the paywall), one per page. If the product is useless without a permission, make sure it can be granted before taking money, or give a clear refund path. Never impose a real restriction without informed consent and a way out. Each permission gets a primer:
  - name the system's buttons (for Screen Time: "Apple asks twice: tap Continue, then Face ID or your passcode");
  - say what it is not (for Screen Time: "your own Screen Time, not parental control");
  - if they decline, show a calm page with Try again and the Settings path, never a dead end or a scolding.
- **End the setup on a one-card summary of their plan,** then the first real action on day 0.
- **Ask for a rating only after the first real success.** Never ask in the onboarding.
- **Long onboardings** can work (Cal AI uses about 25 screens) when traffic has strong intent and every screen builds value: a plan, a projection, a personal result. Start short, measure, and add a screen only when the data asks for it.
- **The first Home a new user sees** leads with their own plan and the one first action. Never a "0", "Day 0" or an empty chart.
- **Measure every screen from the first build.** Use TelemetryDeck with fixed event names and no user text. Judge after about 100 starts. If many more people see the price but convert worse, add back at most one tap-only screen that builds value.

## Paywall (what App Review checks, plus the owner's preferences; never an approval guarantee)

- **The default for a subscription app: a hard paywall right after the onboarding,** with the 7-day free trial on the yearly plan as the main path. RevenueCat's yearly report shows hard paywalls converting better per download on average (an aggregate, not a guarantee). Choose the model from the app's value, competitors and costs, and judge it on conversion, retention, refunds and net revenue together, not on a handful of views.
- **The trial is shown only to people who are eligible for it** (StoreKit or RevenueCat introductory-offer eligibility). Returning subscribers usually aren't.
- **The billed amount is the largest price element** ("$29.99 a year"), with the trial terms readable under it ("After 7 days free. Cancel 24 hours before ... to pay nothing."). Toll 1.1 was rejected under 3.1.2(c) because the trial was more prominent than the price. Always state the renewal price, the period and that it renews automatically.
- **Never "free" on the button or the headline** (the owner's rule since the rejection). The button says "Start Toll Pro" or "Buy once".
- **A dated timeline of the free week:** Today, then the reminder day, then the charge day. Derive the dates from verified subscription data. Promise a notification only once it is authorized and scheduled. Keep the reminder promise with a notification, a Home card and a line in Settings.
- **The plans:** yearly preselected, with monthly and lifetime visible. A "Save X%" chip only with a percentage computed from the real prices (yearly against monthly x 12).
- **Always on the page:** Restore purchases, "Have a code?", Terms and Privacy.
- **Banned:** countdowns, exit offers, trial toggles, a second purchase flow after a decline (App Review flags these), and fake strike-through prices (the owner's rule). Handle success, cancellation, pending, failure and restore separately; show "Nothing was charged." only when the purchase was cancelled.
- **Prices come from StoreKit,** never from text in the code.
- **Sell the outcome** (time back, apps that open when the habit is done), not a feature list.

## Pricing an app with no ratings yet

- **Price from the market, never from a generic ladder.** A round $39.99 / $9.99 / $119.99 ladder looked machine-made to strangers, and $39.99 a year felt steep for an app with no ratings.
- **Price a notch below the category leaders while the app has no ratings,** on a ladder with a reason:
  - monthly x 12 is about 2 to 2.5 times the yearly price;
  - lifetime is about 2.5 times the yearly price.

  Toll's ladder, for example: $29.99 a year with the 7-day trial, $5.99 a month, $79.99 lifetime.
- **If the app needs other people or content to be useful, or the leaders are freemium or paid up front,** follow the leaders' model instead of a hard paywall.
- **Set euro storefronts by hand** to clean prices (€29.99). Automatic conversion turned $39.99 into €44.99 in France.
- **An approved subscription's price can only change from a future date:** use the earliest date App Store Connect allows for each storefront. Make sure the app version, store text and website that quote the new price go live no earlier than the price does. Check what existing subscribers keep.
- **Enroll in the App Store Small Business Program (15%)** before the first sale.

## Store page

- **The 2-second test:** a stranger who sees only the icon, the title, the subtitle and the first screenshot can say what the app does ("it locks my apps until I take a photo of my habit").
- **Words:**
  - the title is "Name: what it does in search words" ("Toll: App Blocker for Habits");
  - the subtitle carries more search terms ("Lock In: Earn Your Screen Time");
  - the keyword field is filled to 100 characters (commas, no spaces) with no words already in the title or subtitle;
  - the title and subtitle are 30 characters each, and never stuffed with keywords (guideline 2.3.7);
  - a new app with no ratings won't rank for head terms, so aim at 3 to 5 long-tail phrases where it can reach the top 10, and check those ranks a week after release.
- **Screenshots:**
  - 6 to 8 frames on light, solid backgrounds;
  - a big two-line caption in ink and gray about the outcome and the feeling;
  - frame 1 is the core moment, then the pain it removes, then the result over time or a second key feature (Toll's: "Locks your apps until you work out.", "No ignore button.", "Day 14. Still showing up.");
  - frame 1 must be understood without reading the title: its caption states the mechanic in plain words;
  - one early frame shows how it works in 2-3 steps, and the set answers "is this for me?" (who it's for, what it asks of them each day);
  - each frame shows a different moment and layout, so no two frames look alike (not two frames on the same screen);
  - real sample data: never a zero state, a price or a settings screen;
  - one message across the set, with captions localized for every language the page sells in.
- **Light screenshots won more impressions than dark** in one developer's A/B tests.
- **Description:** the first lines say what it does, the difference and the honest price ("7 days free, then $29.99 a year"), then a short, real founder story. No hype words.
- **Photos in the app and the screenshots** must be real and licensed (the Unsplash License allows commercial use), or made for the app. Choose photos specific to the product's moment (this gym, this plate), never generic objects.
  - Never use the owner's personal photos unless he hands them over for that use. He refused his own gym photos.
  - Never use 3D renders.
  - Keep a credits file.
- **Get honest ratings early:** friends, and free codes for the first 25 people in the target group in exchange for feedback, never conditioned on a review. A page with 0 ratings looks abandoned.

## Icons

- **Every icon change passes a blind test before it ships.** Show the icon alone to an image model or a stranger and ask what the app does. Toll's door icon read as a bank or a museum; the T-lock read straight away as an app locker.
- **Check the icon next to the category's leaders** at real search size, in light and dark.

## Distribution

- **Fix the funnel before buying ads.** Toll spent $294 on Apple Ads for 53 installs and earned $0. Separately, in-app analytics over a shorter window showed only 7 of 25 onboarding starters reaching the price.
- **Apple Ads:**
  - exact match, Search Match off;
  - English storefronts only until the page is localized (47% of Toll's ad money went to France, for an English-only app).
- **In a crowded category, lead every surface with the one thing only this app does.**
- **Read the Apple Ads search-terms report.** Broad terms that name a free built-in feature ("screen time") bring people who wanted Apple's own tool. Exclude them.
- **Meta and TikTok ads need a learning budget** (about $1,000-3,000) before they find buyers; Apple Search Ads is a keyword auction and doesn't. Some developers earning $10,000 a month still found Apple Ads unprofitable at a low price.
- **Organic short video** grows app blockers (Brick, Pushscroll, touch grass).
- **Comments that say "this concept won't work"** get weighed, not dismissed. Some are only taste. Others question the recurring effort, the user's autonomy, whether the proof can be trusted, or paying for a restriction. Those can justify changing the mechanic, the positioning or the business model. Present the evidence and a recommendation to the owner; he decides. Always keep their presentation lessons.

## Features that verify or restrict

If the app checks people (a photo proof, a location, a step count) or restricts them (locked apps, a timer they can't stop), say plainly:
- where the check happens (on the iPhone or on a server);
- what counts and what doesn't;
- what happens when it fails;
- how to get out (delete the app, a rest day, a support link).

Strangers asked whether an uploaded picture would pass, and who decides what counts. Answer these on screen 1 or 2 and on the store page. Show control and consent (you pick the apps; calls and messages stay open), and never sound punitive.

## Find the leak before changing anything

Fix the biggest leak first, in this order:
1. **The store page** (tap-through and conversion rates).
2. **The onboarding** (each screen's drop).
3. **The paywall:** views, purchases started and purchases completed. About half of those who start a purchase should finish. If many start and few finish, look for a bug or a price mismatch. If nobody starts, redesign the paywall to sell the outcome.
4. **The price.**
5. **Traffic.**

Don't judge the price on fewer than about 100 paywall views, or a launch before 2 to 4 weeks.

**Write the stop rule before launch.** Name the success bar and the date (for example: "by 4 weeks after release, at least 2 active trials or $100, from organic posts only"). If the bar is met, keep going; if not, stop and move to the next idea. Don't keep polishing a product the market has answered.

## Before every submission

1. **Capture every screen, sheet and state** in the Simulator:
   - every debug root and every sheet;
   - empty, sample and done states;
   - every onboarding page and every paywall;
   - widgets and block screens;
   - AX5 text and the smallest phone.

   Look at each one at full size. Main tabs alone miss old art in sheets: Toll 1.4 reached App Review with a dark 3D flame and a purple metal coin.
2. **List every image the code still references.** Each must be a real photo or flat art; delete the rest.
3. **Search user-facing strings** for banned words, exclamation marks and emoji.
4. **Send the owner the contact sheet before submitting.**
5. **Run all unit and UI tests.** The RevenueCat Test Store is slow: re-run a failing purchase test on a fresh install before calling it a bug.
6. **Check the legal and privacy parts:**
   - the description, or the EULA field, links the Terms of Use and the Privacy Policy (3.1.2 for subscriptions);
   - the privacy label lists the analytics;
   - every permission has a plain purpose string;
   - the review notes explain any special entitlement and how to test the paid parts.
7. **In a crowded category, make the difference obvious to the reviewer too** (first screen and review notes). Guideline 4.3(b) can reject an app that looks like one more of the same.
