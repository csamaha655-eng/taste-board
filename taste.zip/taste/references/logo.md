# Logos

When the owner asks for a logo, or a project needs one and the owner hasn't given one, make a mark in the spirit of the spacefs.com logo. Take its qualities, never its shapes: the owner says "not the exact same". If the owner has a logo, use it exactly (transparent SVG or PNG, never in a white box).

**App icons must say what the app does.** On Reddit, strangers could not tell what Toll was from its icon: an arched door read as a bank, a museum or a religious gate. The fix was a padlock whose keyhole is the T, which a blind test read as "an app locker, immediately".
- For an app icon, lead with a recognizable image of the core action (a lock for a blocker, a plate for a meal app, a wave for a sleep app), drawn with spacefs-style craft: flat, bold, one ink color on one solid ground.
- Carry the initial inside it where it fits, as the T in Toll's keyhole.
- A pure letter mark is for a brand wordmark or a website logo, not for an app icon that must sell in search results.
- Blind-test every icon before it ships: show only the icon to an image model and to a person, and ask what the app does. A model's reading is a first check, not proof.

## What the owner likes in the spacefs logo (captured 2026-10-04)

- **Two solid shapes, one rotated 180° from the other.** The letter (an S) appears in the negative space between them; it isn't drawn.
- **Organic, calligraphic curves.** Each shape is a full rounded body that tapers to a sharp point, like a brush stroke, a petal or a seed.
- **One flat color.** Ink black on white, or white on black. No gradient, outline, bevel, shadow, 3D or second color inside the mark.
- **Compact and nearly square,** with generous padding. It still reads at 16 px.
- **Presented quietly:** in a white circle with a soft shadow (the floating nav button), with the name set in the product's own typeface.

**Not the owner's taste:**
- multicolor logos like Chrome's;
- gradients, glossy 3D, mascots, detailed illustration.

**Clichés to avoid:**
- AI sparkles, lightbulbs, rockets, gears, globes, swooshes, brains;
- chat bubbles, hearts, leaves, shields, crowns;
- a letter in a box.

## How to make one

1. **The idea.** Start from the product's initial or one concept from its world (a drop for water, an orbit for travel). Express it with 1-3 simple solid shapes. Prefer symmetry (180° rotation or a mirror) and let negative space carry the letter.
2. **Draw it as SVG** in a `0 0 100 100` viewBox:
   - build one shape from cubic Bézier curves, then reuse it with `<use>` and `transform="rotate(180 50 50)"` so the symmetry is exact;
   - keep 10-14 units of padding;
   - use one `fill="currentColor"`.
   ```svg
   <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" fill="currentColor">
     <path id="a" d="M… Z"/>
     <use href="#a" transform="rotate(180 50 50)"/>
   </svg>
   ```
3. **Three concepts:** three different ideas, not three variants of one.
   - Render each at 512 px and at 16 px, on white and on black, with the headless browser, and look at them at full size.
   - Drop any that blurs at 16 px or needs a second color.
   - Drop any that resembles a famous logo. Check spacefs's specifically: different shapes, different letter.
4. **Refine the winner:**
   - smooth curvature with no kinks (keep handles tangent where curves join);
   - optically balanced weight;
   - consistent thickness, as if made by one brush.
5. **Deliver:**
   - `logo-mark.svg` (currentColor);
   - `logo-lockup.svg`: the mark plus the name in the product typeface, medium or semibold, tight tracking;
   - favicons: SVG, 32 px, 180 px apple-touch and 512 px;
   - for iOS, a 1024 px app icon: the mark centered at about 55% width on one solid fill (white on ink, ink on white or fog, or the palette's hue), never a gradient. Also export the mark as its own layer for Icon Composer, so the system's Liquid Glass treatment works on iOS 26+.
6. **Show the owner:** the three concepts side by side (white and black backgrounds, large and favicon size), each with a one-line idea, and recommend one.

Hand-drawn SVG is the default, because it is crisp and editable. If the owner prefers an image model, write the prompt with these same rules. Logos are never animated on launch: a static mark that fades out is all.
