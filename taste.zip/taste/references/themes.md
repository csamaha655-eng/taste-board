# Themes

There are four themes; don't invent extra ones unless the owner sends a new reference for one. Light is the default everywhere. Toll, a screen-time app, shipped dark under an older version of this file, and strangers read it as AI slop. Never pick dark because a subject sounds serious, nocturnal or "focused".

**Websites and web apps**

| When | Theme |
|---|---|
| Every website and web app, any subject (app sites, SaaS, AI tools, travel, food, portfolios) | Quiet Glass: spacefs.com copied exactly. The subject changes only the accent, the photos and the words. |
| The owner asks for parallax or a photo-led page | Parallax Journey, keeping spacefs's type, nav, pills and spacing |
| The owner asks for dark | Nocturne |

The subject alone never switches a website to another theme, and never adds parallax, 3D or dark.

**iOS apps**

| When | Design |
|---|---|
| Every app (planners, AI assistants, focus, screen time and app blockers, habits, health, utilities) | The style board's phone design (the Atmos Glass layout) in a light palette picked by subject; see "iOS apps" below |
| A travel or places app | The same design with the Photo palette |
| The owner asks for dark, or the app is used mostly in a dark room (sleep, astronomy, cinema) | A flat dark palette (Graphite night, or Midnight when he asks for the night phone) |

An app's marketing site is Quiet Glass (spacefs) with the app's accent, icon and screens. State the chosen theme and the reason in one line of your plan.

## When the owner names no theme (choose automatically, never ask)

- **A website or web app:** Quiet Glass (spacefs.com, copied exactly), light, with one accent from the library below picked by the subject.
- **An iOS app:** the style board's day phone in a light palette. Pick the atmosphere and the accent from the library by the subject; Steel when nothing fits better.
- State the choice in one line ("Quiet Glass, forest accent, because it's a plant shop") and build.

**Accent for a new product.** One hue from the subject's own world, deep and calm, used only for selection, links, focus and state. Never purple, and never generic SaaS blue unless the owner asks. Start from this library. Every hue was checked at 4.5:1 or better on white, on the canvas (#F7F8FA) and on the fog (#EEF0F3), so it can carry words and a white label.

| Accent | Hex | Subjects |
|---|---|---|
| Ink blue | #1F4E79 | finance, tools, productivity, B2B |
| Steel | #3E6E91 | planners, calendars, focus, AI assistants |
| Ocean | #1E5F99 | health, water, daytime sleep and recovery |
| Fjord teal | #0F6B6B | travel, outdoors, maps |
| Forest | #2F6B3F | plants, nature, food, money saved |
| Moss | #4F6B2F | wellness, calm, slow living |
| Ember | #B84A18 | habits, energy, fitness, blockers (Toll) |
| Clay red | #B3261E | sport, urgency, deadlines |
| Brown | #6B3E2E | books, culture, coffee, craft |
| Graphite | #3A3D42 | neutral premium, when no hue fits |

For an iOS atmosphere, use a lighter, desaturated tint of the same hue (Toll: accent #D9581F, text #B84A18, atmosphere peach #FFBE8C). Words in the accent use the deep value above.

## Looks that read as AI-made (never, whatever the subject seems to suggest)

These are the palettes and treatments strangers associate with generated apps and sites. Never use them unless the owner asks for them by name:
- **A dark ground lit by purple, violet, blue or neon glow.** This is the look strangers named outright, Toll's first design.
- **Purple or violet as the brand or accent color:** indigo #6366F1, violet #8B5CF6, lilac, lavender. It is the default color of AI products. The one exception is the owner's own logo, if it is purple.
- **Any color-to-color blend:** purple to pink, blue to purple, teal to blue, orange to pink, aurora, mesh, holographic, iridescent.
- **Neon or acid green, cyan or magenta on black** (the crypto, "hacker" and cyberpunk look).
- **Glass floating over colorful blurred blobs** (the generic glassmorphism shot). Here, glass is neutral and only for navigation.
- **The generic "premium" defaults:** warm cream with a serif and a terracotta accent; beige and gold "luxury"; near-black with one acid accent.
- **Generic SaaS blue** (#0A84FF, Tailwind blue-500) as the whole brand.
- **Rainbow and multicolor:** multicolor icon sets, candy pastels everywhere, every chart series a different hue.
- **Effects:** gradient text, glowing buttons, sparkle icons.

Green is fine as a deep, natural subject hue (Forest, Moss) for plants, nature, food or money. Never neon, never on black, and never sprinkled everywhere as "success" decoration.

## Are the four themes safe? (checked 2026-10-11 against the real-user feedback in `real-users.md`)

- **Quiet Glass (spacefs): yes, and it is the safest.** Light, neutral, flat and product-first: exactly what strangers read as made by a person. It is the default for every website.
- **Atmos Glass, day (the style board's day phone): yes,** in a light palette with one quiet atmosphere hue. It is the default for every app. Keep the atmosphere subtle, never a glow behind elements.
- **Atmos Glass, night (Midnight: black falling into blue light): risky.** It is the closest thing in this skill to the look strangers called AI slop. Use it only when the owner asks for the night phone by name; any other request for dark gets Graphite night or flat Nocturne.
- **Parallax Journey: yes,** when the photos are real and specific to the place, and only when the owner asks for parallax or a photo-led page.
- **Nocturne: yes when asked.** It is dark but flat, with one accent and no colored light. Never pick it by subject.

Web tokens: `assets/web/tokens.css`. Quiet Glass is the default; switch with `theme-atmos` or `theme-nocturne` on `<html>`. The iOS palette lives in `assets/ios/Theme.swift`.

## iOS apps: one design, any palette

Every iOS app uses the style board's phone design (the Atmos Glass layout), whatever the subject. The owner: "that's how I want all my apps to look," while the colors may change. Pick a palette by subject, or from the owner's words ("grey, black and white" means Graphite).

| Palette | Look | In code |
|---|---|---|
| Steel | soft steel-blue light (the day phone) | `.steel` |
| Midnight | black falling into blue (the night phone); only when the owner asks for it by name. For any other "make it dark", use Graphite night or a flat Nocturne-style palette, with no colored light | `.midnight` |
| Graphite | grey, black and white | `.graphite` |
| Graphite night | black falling into grey; only when asked | `.graphiteNight` |
| Paper | no atmosphere, only the fog canvas | `.paper` |
| Photo | a real photo as the atmosphere (travel, places) | fog plus a photo behind the sheets |
| Custom | one hue from the subject (deep green for a plant app, peach for Toll) | copy `.steel`; change `atmosphere` and `accent` |

**Pick a light palette by default.** Midnight and Graphite night are for when the owner asks for dark, or the subject is truly night-time. Strangers read a dark app lit by colored glow as AI-made. Even then, the atmosphere stays one quiet hue, never a glow on content.

The themes below (Quiet Glass, Parallax Journey, Nocturne) are mainly for websites. On iOS, a dark app is Midnight or Graphite night, and a travel app is the Photo palette.

## Quiet Glass (the default: spacefs.com, copied exactly)

Apple-native realism on a cool off-white page. The product itself is the hero.

**The owner's rule (2026-10-11):** "I love, love, love spacefs.com. Copy its design exactly." For every website and web app, reproduce spacefs's design system exactly by default:
- type scale, weights, tracking and line heights;
- colors and the 1200 px column;
- section rhythm;
- the three-piece floating nav;
- pills, glass cards and shadows;
- hover motion and the scroll story.

The measured values are below and in `inspiration.md`, and `assets/web/tokens.css` carries them. Copy the design, never its content: not its words, logo, product name, Finder screens or images.

**When the owner asks for something spacefs doesn't have** (parallax, a photo-led travel page, 3D, scroll storytelling beyond the Finder pattern, dark), build that with its recipe (Parallax Journey, the `web.md` recipes, Nocturne). Keep spacefs's type, colors, nav, buttons and spacing everywhere the new effect doesn't need to change them.

The style board (`assets/web/specimen.html`) is the owner's working implementation; when it and spacefs disagree, spacefs wins.

| Token | Light | Dark |
|---|---|---|
| canvas | #F7F8FA (spacefs, measured) | #0C0D10 |
| surface (cards) | #FFFFFF | #15171B |
| ink | #0E0F12 | #F4F5F7 |
| ink-2 (second headline line, body, captions) | #686D78 | #9AA0AB |
| ink-3 (decoration only: icons, rings, disabled) | #8A8F99 | #737A86 |
| hairline | #E0E3E8 | #24272D |
| shadow color | rgb(15 23 42) (slate, never pure black) | rgb(0 0 0) |
| accent (selection, focus, links only) | #0A84FF | #3B9BFF |

Type: Google Sans, plus Google Sans Code for small numbers and labels. The spacefs type scale (measured at 1512 px wide; scale it down with `clamp()`):

| Role | spacefs | Use |
|---|---|---|
| hero h1 | 76 px, line height 1.02, tracking -0.035em | 400, exactly as spacefs (the one heading at 400; never Thin or Light) |
| big section h2 | 60 px, line height 1.04, tracking -0.035em | 500 |
| section h2 | 54 px, line height 1.04, tracking -0.03em, 500 | 500 |
| row title h3 | 34 px, line height 1.25, tracking -0.025em, 500 | 500 |
| lede | 17 px, line height 1.625, ink-2, about 480 px wide | 400 |
| row text | 15 px, line height 1.625, ink-2, about 336 px wide | 400 |
| meta line | 12 px, line height 16 px, tracking 0.3px, ink at 80% | 400 |
| buttons and pills | 14 px, line height 20 px | 500 |

**Measured components:**
- **Layout:** a 1200 px column; sections have 96 px of vertical padding.
- **The nav (80 px tall), three separate pieces:**
  - a 52 px circular glass logo button (white at 66%, blur 20, saturate 1.5, an inset white top line, `0 1px 2px` slate at 5%);
  - a centered "Menu" glass pill (32 px tall, padding 6 by 12);
  - a black "Download" pill (40 px tall, padding 0 16, an inset white top line at 16%, `0 8px 20px -10px` slate at 50%).
- **Hero CTA:** a black pill, 48 px tall, padding 0 28.
- **Link cards:** glass (blur 28, saturate 1.6), radius 24, padding 28 by 32, an inset white top line at 95%, and `0 24px 60px -28px` slate at 28%.
- **Chips:** glass pills 32 px tall with 12 px words in ink-2.
- **Segmented buttons:** 36 px tall, padding 8 by 16.

Signature moves:
- **Floating nav, no bar.** A white circle logo button on the left, a glass pill with links (or "Menu") in the center, the black pill CTA on the right. Content blurs under a feathered band at the top.
- **Hero.** Two-tone headline, short gray lede, one black pill CTA, one mono meta line under it ("macOS · Linux · Windows coming soon"). A small trust chip above the headline only if it is true.
- **The product as hero.** A pixel-faithful mockup (macOS window, iPhone) that changes state as you scroll (sticky scrollytelling): a selection, then a context menu, then an info panel.
- **Editorial rows.** Title on the left, a two-line description on the right, hairline dividers.
- **Link cards** with a circular arrow button; the arrow nudges 4 px on hover.
- **Pricing** on white cards. **FAQ** in two columns: a sticky heading on the left, rows with circular plus buttons on the right.
- **One ornament family.** A stippled dot field (solid dots in two hues, never blended) behind the hero, and a giant dot-matrix wordmark cropped at the bottom of the footer. The two count as one ornament.

Avoid: colored section backgrounds, icon grids, illustrations.

## Atmos Glass (from Gleb Kuznetsov's "Agentic calendar AI experience")

Frosted sheets floating in soft light. Calm, personal, AI-native. Best for iOS. Locked to light.

| Token | Value |
|---|---|
| fog (canvas) | #EEF0F3 |
| sheet | white at 55-80% opacity (more opaque toward the front), blur 24-30, saturate 1.5 |
| ink / ink-2 | #111214 / #6B7280 |
| primary pill | #0A0A0B with white label |
| atmosphere, day | steel blue #6F95B2 |
| atmosphere, night | midnight #070B16 with blue light #4566D8 |
| radii | sheets 30-36, inner elements 18-22, pills full |

Signature moves:
- **Two-tone header.** "Today" in ink with the date in gray below it. On a dark atmosphere, use white with the date in a lightened atmosphere hue.
- **A stack of sheets with depth.** The progress sheet peeks out behind the focus sheet, and "Next up" peeks out below it. Layering replaces borders.
- **Focus card.** A small label, a big title (28-32 pt, medium or semibold), a two-line body, a black pill CTA with a leading icon, and meta such as "2h" with a clock glyph on the right.
- **Week strip.** Weekday letters over dates. The selected day is raised as a glass capsule; dots mark days with items.
- **Prompt capsule.** A small floating glass capsule at the bottom is the AI entry point.
- **Progress ring.** A thin single solid stroke.

The atmosphere is one hue, used as light behind the glass and falling into fog (the rule is in `anti-slop.md`). Never put it on a control, and never use two hues.

## Parallax Journey

You travel through the place. Photography carries the color while the UI stays neutral and quiet. Uses Quiet Glass neutrals, locked to light (`data-theme="light"`); night photography is fine.

Signature moves:
- **Hero.** The only theme allowed a near-full-height, full-bleed photo hero (about `88svh`, so the next section peeks). The photo scales from 1.08 to 1.0 and drifts slower than the page.
- **Layered depth.** Background, midground and foreground move at different speeds (for example 0.2, 0.5 and 1.0); see `.journey` in specimen.html.
- **Sticky chapters.** A place or a day stays pinned while its details scroll past, with big confident type.
- **Glass over photos.** Caption cards float over the imagery.
- **Snapping photo rails.** Scrollbars are hidden on rails only.
- **Real data.** Itineraries and maps carry real times, distances and prices.

**Text over photos:**
- Choose photos with a calm, darker area where the text will sit.
- Test contrast against the brightest pixel under the text.
- If it fails, put the text on a glass plate or a flat 24-32% ink overlay, or pick another photo. Never use a dark-to-clear gradient scrim.

**Nav over photos:**
- All three nav pieces become glass.
- While over a dark photo, the CTA is a white pill with an ink label. Back over the canvas, it returns to the black pill.
- Use `.feather.clear` (blur, no tint) so no pale band appears over the photo.

**Photos:**
- Licensed photos (Unsplash) or photos made for the product, specific to its places and moments, never generic objects. The owner's own photos only when he hands them over for that use.
- Keep one grade: the same time of day and color temperature throughout.
- Reject a photo whose sky clashes with the rest (a pink sunset next to cool daylight).
- Don't fake a grade with heavy CSS filters.
- Never crop a subject at the top.

**Restraint:** 2-4 parallax layers per scene, not every element. Under Reduce Motion the page is static and still beautiful.

## Nocturne (dark)

| Token | Value |
|---|---|
| canvas / surface | #0A0A0A / #141416 |
| ink / ink-2 | #F2F2F0 / #9B9BA1 |
| hairline | #232326 |
| accent | one solid hue chosen per product (see "Accent for a new product") |

Signature moves:
- Chrome is flat; life comes from real photography or a landscape moment, not from color washes.
- Secondary buttons are transparent with a 1 px white outline.
- Sign in with Apple uses the standard white button.
- No dark floor under the tab bar.

Locked to dark. Choose it only when the subject or the owner asks for dark.

## Pending

The owner will send two iOS apps they like. When they arrive, analyze them (SKILL.md, "New references") and add each one here, as a new theme or as a refinement of an existing one.
