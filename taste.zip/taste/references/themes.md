# Themes

Four themes and two blueprints (`spacefs.md` for product sites, `fashion.md` for clothing brands); don't invent more unless the owner sends a new reference. Light is the default everywhere.

**Websites: pick in this order, and say why in one line**
1. **He names a style or a reference:** that.
2. **A product he makes** (an app, a tool, a download page, a SaaS, a web app): the spacefs blueprint (`spacefs.md`), about 90%.
3. **A clothing, streetwear or fashion brand store:** the clothing-brand blueprint (`fashion.md`). It is black and white with blurred see-through glass, and he gives the products and prices.
4. **A subject with its own world** (food, hospitality, travel, events, real estate, a portfolio): the look that serves it.
   - The industry brief in `library/` gives the story and sections.
   - Photography leads; use Parallax Journey when the site is photo-led.
   - From spacefs, keep only the tokens, type, three-piece nav and menu, pills and spacing, never its product story, use cases or pricing.
5. **Anything else, or unclear:** spacefs.

Light, no gradients, one accent and phones-first apply to all of them.

**iOS apps**

| When | Design |
|---|---|
| Every app (planners, AI assistants, focus, screen time and app blockers, habits, health, utilities) | The style board's phone design (the Atmos Glass layout) in a light palette picked by subject; see "iOS apps" below |
| A travel or places app | The same design with the Photo palette |
| Under the dark rule (below) | Graphite night; Midnight only when he names the night phone |

**The dark rule:** dark only when the owner asks, or for a product used mostly in a dark room (sleep, astronomy, cinema; never focus, screen time, finance or "premium"). Dark is always flat: Nocturne on the web, Graphite night on iOS. Never pick dark because a subject sounds serious or "focused": Toll, a screen-time app, shipped dark under an older version of this file and strangers read it as AI slop.

When the owner names no theme, choose with the order above (websites) or the table (apps) and an accent from the library below, state it in one line ("spacefs, forest accent, because it's a plant-care app"), and build.

## Accent library

**Accent for a new product.** One hue from the subject's own world, deep and calm, used only for selection, links, focus and state. Never purple, and never generic SaaS blue unless the owner asks. Start from this library. Every hue was checked at 4.5:1 or better on white, on the canvas (#F7F8FA) and on the fog (#EEF0F3), so it can carry words and a white label.

| Accent | Hex | Subjects |
|---|---|---|
| Ink blue | #1F4E79 | finance, tools, productivity, B2B |
| Steel | #3E6E91 | planners, calendars, focus, AI assistants |
| Ocean | #1E5F99 | health, water, daytime sleep and recovery |
| Fjord teal | #0F6B6B | travel, outdoors, maps |
| Forest | #2F6B3F | plants, nature, food, money saved |
| Moss | #4F6B2F | wellness, calm, slow living |
| Ember | #B84A18 | habits, energy, fitness, blockers (Toll) |
| Clay red | #B3261E | sport, urgency, deadlines |
| Brown | #6B3E2E | books, culture, coffee, craft |
| Graphite | #3A3D42 | neutral premium, when no hue fits |

For an iOS atmosphere, use a lighter, desaturated tint of the same hue (Toll: accent #D9581F, text #B84A18, atmosphere peach #FFBE8C). Words in the accent use the deep value above.

## Colors that work together

A palette is calm when one hue does the talking and everything else is neutral.
- **The base is always neutral:** ink, one gray and a canvas (cool off-white for light, near-black for dark). Then one accent. A second hue is allowed only inside photography or product screens.
- **Keep one temperature.** A warm accent (ember, clay) goes with warm-neutral photos and canvas; a cool accent (steel, teal, ink blue) with cool ones. Don't mix a warm accent with a cool tinted canvas.
- **Blue and black work** when black is the ink (type, the pill) and blue is one small accent, as spacefs uses blue only inside its product screens. They clash when both are large, saturated fields.
- **Saturation stays low on big areas** (backgrounds, atmospheres, cards) and higher only on small things (a dot, a selected state).
- **Never two saturated hues side by side** (red with green, blue with orange, purple with yellow), and never vibrating pairs at equal brightness.
- **Contrast decides, not taste:** words at 4.5:1 or better, large titles at 3:1, controls' edges at 3:1. Check every pair.
- **Dark themes:** a near-black canvas (never pure black), off-white ink, and one desaturated accent. No colored light.
- **Photos must agree with the palette.** One grade across the page, and the accent picked from the photos when the site is photo-led.

## Looks that read as AI-made (never, whatever the subject seems to suggest)

These are the palettes and treatments strangers associate with generated apps and sites. Never use them unless the owner asks for them by name:
- **A dark ground lit by purple, violet, blue or neon glow.** This is the look strangers named outright, Toll's first design.
- **Purple or violet as the brand or accent color:** indigo #6366F1, violet #8B5CF6, lilac, lavender. It is the default color of AI products. The one exception is the owner's own logo, if it is purple.
- **Any color-to-color blend:** purple to pink, blue to purple, teal to blue, orange to pink, aurora, mesh, holographic, iridescent.
- **Neon or acid green, cyan or magenta on black** (the crypto, "hacker" and cyberpunk look).
- **Glass floating over colorful blurred blobs** (the generic glassmorphism shot). Here, glass is neutral and only for navigation.
- **The generic "premium" defaults:** warm cream with a serif and a terracotta accent; beige and gold "luxury"; near-black with one acid accent.
- **Generic SaaS blue** (#0A84FF, Tailwind blue-500) as the whole brand.
- **Rainbow and multicolor:** multicolor icon sets, candy pastels everywhere, every chart series a different hue.
- **Effects:** gradient text, glowing buttons, sparkle icons.

Green is fine as a deep, natural subject hue (Forest, Moss) for plants, nature, food or money. Never neon, never on black, and never sprinkled everywhere as "success" decoration.

## iOS apps: one design, any palette

Every iOS app uses the style board's phone design (the Atmos Glass layout), whatever the subject. The owner: "that's how I want all my apps to look," while the colors may change. Pick a palette by subject, or from the owner's words ("grey, black and white" means Graphite).

| Palette | Look | In code |
|---|---|---|
| Steel | soft steel-blue light (the day phone) | `.steel` |
| Midnight | black falling into blue (the night phone); only when the owner names it | `.midnight` |
| Graphite | grey, black and white | `.graphite` |
| Graphite night | black falling into grey; the dark palette under the dark rule | `.graphiteNight` |
| Paper | no atmosphere, only the fog canvas | `.paper` |
| Photo | a real photo as the atmosphere (travel, places) | fog plus a photo behind the sheets |
| Custom | one hue from the subject (deep green for a plant app, peach for Toll) | copy `.steel`; change `atmosphere` and `accent` |

**Pick a light palette by default;** dark only under the dark rule above.

The themes below (Quiet Glass, Parallax Journey, Nocturne) are for websites. On iOS, a dark app is Graphite night (Midnight only when he names it), and a travel app is the Photo palette.

## Quiet Glass (spacefs.com, about 90%)

Apple-native realism on a cool off-white page. The product itself is the hero.

**The owner's rule (2026-10-11):** "I love, love, love spacefs.com. Copy it, about 90%." The blueprint (the page section by section, the menu, the hero parallax, phones) is `spacefs.md`; the tokens are below and in `assets/web/tokens.css`. Copy the design, never its content: not its words, logo, product name, Finder screens or images.

**When the owner asks for something spacefs doesn't have** (parallax, a photo-led travel page, 3D, scroll storytelling beyond the Finder pattern, dark), build that with its recipe (Parallax Journey, the `web.md` recipes, Nocturne). Keep spacefs's type, colors, nav, buttons and spacing everywhere the new effect doesn't need to change them.

The style board (`assets/web/specimen.html`) is the owner's working implementation; when it and spacefs disagree, spacefs wins.

| Token | Light | Dark |
|---|---|---|
| canvas | #F7F8FA (spacefs, measured) | #0C0D10 |
| surface (cards) | #FFFFFF | #15171B |
| ink | #0E0F12 | #F4F5F7 |
| ink-2 (second headline line, body, captions) | #686D78 | #9AA0AB |
| ink-3 (decoration only: icons, rings, disabled) | #8A8F99 | #737A86 |
| hairline | #E0E3E8 | #24272D |
| shadow color | rgb(15 23 42) (slate, never pure black) | rgb(0 0 0) |
| accent (selection and focus; words only from the accent library at 4.5:1) | #1F4E79 (ink blue; replace per product) | #7FA7D6 |

Type: Google Sans, plus Google Sans Code for small numbers and labels. The type scale is in `web.md`; the page, components, menu and phone layout are in `spacefs.md`.

Signature moves:
- **Floating nav, no bar.** A white circle logo button on the left, the glass Menu pill that grows into the panel (`spacefs.md`) in the center, the black pill CTA on the right. Content blurs under a feathered band at the top.
- **Hero.** Two-tone headline, short gray lede, one black pill CTA, one small meta line under it ("macOS · Linux · Windows coming soon"). A small trust chip above the headline only if it is true.
- **The product as hero.** A pixel-faithful mockup (macOS window, iPhone) that changes state as you scroll (sticky scrollytelling): a selection, then a context menu, then an info panel.
- **Editorial rows.** Title on the left, a two-line description on the right, hairline dividers.
- **Link cards** with a circular arrow button; the arrow nudges 4 px on hover.
- **Pricing** on white cards. **FAQ** in two columns: a sticky heading on the left, rows with circular plus buttons on the right.
- **One ornament family.** A stippled dot field (solid dots in two hues, never blended) behind the hero, and a giant dot-matrix wordmark cropped at the bottom of the footer. The two count as one ornament.

Avoid: colored section backgrounds, icon grids, illustrations.

## Atmos Glass (from Gleb Kuznetsov's "Agentic calendar AI experience")

Frosted sheets floating in soft light. Calm, personal, AI-native. Best for iOS. Locked to light.

| Token | Value |
|---|---|
| fog (canvas) | #EEF0F3 |
| sheet | white at 55-80% opacity (more opaque toward the front), blur 24-30, saturate 1.5 |
| ink / ink-2 | #111214 / #6B7280 |
| primary pill | #0A0A0B with white label |
| atmosphere, day | steel blue #6F95B2 |
| atmosphere, night (only when he names the night phone) | midnight #070B16 with blue light #4566D8 |
| radii | sheets 30-36, inner elements 18-22, pills full |

Signature moves:
- **Two-tone header.** "Today" in ink with the date in gray below it. On a dark atmosphere, use white with the date in a lightened atmosphere hue.
- **A stack of sheets with depth.** The progress sheet peeks out behind the focus sheet, and "Next up" peeks out below it. Layering replaces borders.
- **Focus card.** A small label, a big title (28-32 pt, medium or semibold), a two-line body, a black pill CTA with a leading icon, and meta such as "2h" with a clock glyph on the right.
- **Week strip.** Weekday letters over dates. The selected day is raised as a glass capsule; dots mark days with items.
- **Prompt capsule.** A small floating glass capsule at the bottom is the AI entry point.
- **Progress ring.** A thin single solid stroke.

The atmosphere is one hue, used as light behind the glass and falling into fog (the rule is in `anti-slop.md`). Never put it on a control, and never use two hues.

## Parallax Journey

**Use it** with real photos specific to the place, for photo-led subjects (travel, food, fashion, places) or when he asks for parallax.

You travel through the place. Photography carries the color while the UI stays neutral and quiet. Uses Quiet Glass neutrals, locked to light (`data-theme="light"`); night photography is fine.

Signature moves:
- **Hero.** The only theme allowed a near-full-height, full-bleed photo hero (about `88svh`, so the next section peeks). The photo scales from 1.08 to 1.0 and drifts slower than the page.
- **Layered depth.** Background, midground and foreground move at different speeds (for example 0.2, 0.5 and 1.0); see `.journey` in specimen.html.
- **Sticky chapters.** A place or a day stays pinned while its details scroll past, with big confident type.
- **Glass over photos.** Caption cards float over the imagery.
- **Snapping photo rails.** Scrollbars are hidden on rails only.
- **Real data.** Itineraries and maps carry real times, distances and prices.

**Text over photos:**
- Choose photos with a calm, darker area where the text will sit.
- Test contrast against the brightest pixel under the text.
- If it fails, put the text on a glass plate or a flat 24-32% ink overlay, or pick another photo. Never use a dark-to-clear gradient scrim.

**Nav over photos:**
- All three nav pieces become glass.
- While over a dark photo, the CTA is a white pill with an ink label. Back over the canvas, it returns to the black pill.
- Use `.feather.clear` (blur, no tint) so no pale band appears over the photo.

**Photos:**
- Licensed photos (Unsplash) or photos made for the product, specific to its places and moments, never generic objects. The owner's own photos only when he hands them over for that use.
- Keep one grade: the same time of day and color temperature throughout.
- Reject a photo whose sky clashes with the rest (a pink sunset next to cool daylight).
- Don't fake a grade with heavy CSS filters.
- Never crop a subject at the top.

**Restraint:** 2-4 parallax layers per scene, not every element. Under Reduce Motion the page is static and still beautiful.

## Nocturne (dark)

| Token | Value |
|---|---|
| canvas / surface | #0A0A0A / #141416 |
| ink / ink-2 | #F2F2F0 / #9B9BA1 |
| hairline | #232326 |
| accent | one solid hue chosen per product (see "Accent library") |

Signature moves:
- Chrome is flat; life comes from real photography or a landscape moment, not from color washes.
- Secondary buttons are transparent with a 1 px white outline.
- Sign in with Apple uses the standard white button.
- No dark floor under the tab bar.

Locked to dark, and only under the dark rule. Flat, one accent, no colored light.

## Pending

The owner will send two iOS apps they like. When they arrive, analyze them (SKILL.md, "New references") and add each one here, as a new theme or as a refinement of an existing one.
