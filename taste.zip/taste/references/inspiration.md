# Inspiration log

Each entry records what makes the reference premium, which theme it feeds, and what never to copy. Add new references at the top of "References".

## References

### Taste style board (built 2026-10-04; the quality bar)

`assets/web/specimen.html`, published at https://claude.ai/artifact/EUqU72opYptW16qZtzu5aB. The owner: "it's so nice, I love it" and "really, really, really good". Every website should reach this level. It is Quiet Glass in practice, built as plain HTML, CSS and a little JS with Google Sans:
- the two-tone "Quiet glass. / Built to feel expensive." hero over the stipple wave;
- Atmos Glass phones;
- editorial rows;
- the component board;
- the parallax scene;
- the dot-matrix footer.

The owner disliked the brand-color look (a logo blue with beige) and was lukewarm on ivory and gold. Neither is a theme. The owner's own past apps are not design references.

### spacefs.com (website; IS Quiet Glass)

Captured 2026-10-04 and measured again on 2026-10-11 (exact type scale, nav, buttons and cards in `themes.md`, Quiet Glass). Built with Gatsby and Tailwind; type is Google Sans and Google Sans Code.

**The owner's rule (2026-10-11):** "I love, love, love this website. Copy its design exactly." It is the default design for every website and web app, reproduced exactly. That covers:
- the type scale;
- colors and spacing;
- the three-piece floating nav;
- pills, glass cards and shadows;
- motion;
- the two-tone headlines;
- the product-as-hero scroll story.

The one exception: when the owner asks for an effect spacefs doesn't have (parallax, 3D, a photo-led travel page, dark), build that, keeping spacefs's tokens, type and components around it. This entry overrides the general "take layout and quality, not the whole thing" rule for references.

**Tokens:**
- canvas rgb(247 248 250), ink rgb(14 15 18), muted rgb(104 109 120), border rgb(224 227 232);
- dark-mode canvas rgb(12 13 16);
- the system blue #0A84FF appears only inside the product mockups.

**Glass and shadows:**
- glass: blur 20-40 px with saturate 1.4-1.8;
- 0.5 px hairline rings everywhere;
- cards: `0 0 0 .5px rgb(0 0 0/.08), 0 1px 3px rgb(0 0 0/.08), 0 4px 12px -4px rgb(0 0 0/.1), inset 0 .5px 0 #fff`;
- floating windows: `0 0 0 .5px rgb(0 0 0/.12), 0 30px 70px -18px rgb(0 0 0/.26), 0 10px 24px -12px rgb(0 0 0/.14)`.

**Motion:** easing `cubic-bezier(.22,1,.36,1)`; arrows translate-x on hover; color transitions at 200 ms.

**Tracking:** headlines -0.025 to -0.05em; tiny uppercase labels +0.12 to +0.18em.

**Why it feels premium:**
- one black pill, and a floating nav made of three separate pieces;
- the product rendered pixel-perfect as the hero;
- a scroll story in which the Finder window changes state (selection, then context menu, then Get Info: "Zero bytes on disk");
- two-tone headlines;
- a single ornament family: a stippled wave of blue and terracotta dots, and a dot-matrix wordmark in the footer;
- lots of content, very little chrome.

**Don't copy:** its wording, logo, product name, Finder content or images. The design is copied; the content is always the owner's own product.

### Reddit, r/AppBusiness and r/AppStoreOptimization (2026-10-10 and 11; feeds `anti-slop.md`, `app-launch.md`, `app-idea.md`)

About 90 public comments from developers and users on Toll's launch post: the strongest outside signal the owner has had. The lessons are in those three files. The patterns, briefly:
- dark with colored light reads as AI-made;
- metaphors and vague taglines read as AI copy;
- 15 onboarding screens before the price lose most people;
- the first screenshot and the icon must say what the app does;
- "why this one, when so many exist?" and "doesn't the phone already do this?" are the first questions any idea must answer.

The raw comments are in the Toll project (`work/redesign/reddit/all/`). Never paste comments into the skill; record the concept behind them.

### "Agentic calendar AI experience" by Gleb Kuznetsov (Dribbble shot 26722657; feeds Atmos Glass)

**What it shows:**
- two phones, day and night;
- frosted white sheets stacked with depth over a single-hue atmosphere (steel blue for day; midnight into periwinkle for night) that falls into fog-white;
- a two-tone header, "Today" over "Wed, Aug 4";
- a focus card with a big medium-weight title, a short body, a black pill "Start task" with an icon, and "2h" meta;
- a week strip in which the selected day is a raised glass capsule;
- a tiny floating prompt capsule at the bottom;
- a thin progress ring on the night variant.

**Why it feels premium:** restraint (monochrome plus one hue), layering instead of borders, generous radii, and a black CTA against soft glass.

**Don't copy:** the layout one-to-one, or its text.

## Known favorites from past projects

- **Opal:** "one of, if not the best, app I've ever seen". The model for spacing, type sizes, glass and paywall polish. Not a model for its onboarding length, its dark backgrounds or its 3D gem, cave and stars art. Never use its words, its gem, cave or stars art, or its names.
- **Tide Guide:** the onboarding and paywall structure.
- **Revolut, Cal AI, Apple Fitness, Withings, Airbnb, Flow:** calm, premium, information-rich layouts.

## Pending

The owner is sending two iOS apps they like for their design. They don't apply to everything; use them when the subject fits. For each one, add:
- where its screenshots are saved;
- what makes it premium;
- which theme it feeds, or a new theme for `themes.md`;
- what never to copy.
