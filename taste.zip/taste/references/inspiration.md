# Inspiration log

Each entry records what makes the reference premium, which theme it feeds, and what never to copy. Add new references at the top of "References".

## References

### Taste style board (built 2026-10-04; the quality bar)

`assets/web/specimen.html`, published at https://claude.ai/artifact/EUqU72opYptW16qZtzu5aB. The owner: "it's so nice, I love it" and "really, really, really good". Every website should reach this level. It is Quiet Glass in practice, built as plain HTML, CSS and a little JS with Google Sans:
- the two-tone "Quiet glass. / Built to feel expensive." hero over the stipple wave;
- Atmos Glass phones;
- editorial rows;
- the component board;
- the parallax scene;
- the dot-matrix footer.

The owner disliked the brand-color look (a logo blue with beige) and was lukewarm on ivory and gold. Neither is a theme. The owner's own past apps are not design references.

### spacefs.com (website; IS Quiet Glass)

Captured 2026-10-04 and measured again on 2026-10-11 (the page, nav, menu, buttons and cards in `spacefs.md`; the type scale in `web.md`). Built with Gatsby and Tailwind; type is Google Sans and Google Sans Code.

**The owner's rule (2026-10-11):** "I love, love, love this website. Copy it, about 90%." It is the default design for every product website and web app, and for any website request that names no style. The full page blueprint (sections, the menu morph, the hero parallax, phones) is in `spacefs.md`. That covers:
- the type scale;
- colors and spacing;
- the three-piece floating nav;
- pills, glass cards and shadows;
- motion;
- the two-tone headlines;
- the product-as-hero scroll story.

Not for every site: a clothing brand, a restaurant or a portfolio gets the look that serves its subject. When the owner asks for an effect spacefs doesn't have (parallax, 3D, a photo-led travel page, dark), build that, keeping spacefs's tokens, type and components around it. This entry overrides the general "take layout and quality, not the whole thing" rule for references.

**Tokens:**
- canvas rgb(247 248 250), ink rgb(14 15 18), muted rgb(104 109 120), border rgb(224 227 232);
- dark-mode canvas rgb(12 13 16);
- the system blue #0A84FF appears only inside the product mockups.

**Glass and shadows:**
- glass: blur 20-40 px with saturate 1.4-1.8;
- 0.5 px hairline rings everywhere;
- cards: `0 0 0 .5px rgb(0 0 0/.08), 0 1px 3px rgb(0 0 0/.08), 0 4px 12px -4px rgb(0 0 0/.1), inset 0 .5px 0 #fff`;
- floating windows: `0 0 0 .5px rgb(0 0 0/.12), 0 30px 70px -18px rgb(0 0 0/.26), 0 10px 24px -12px rgb(0 0 0/.14)`.

**Motion:** easing `cubic-bezier(.22,1,.36,1)`; arrows translate-x on hover; color transitions at 200 ms.

**Tracking:** headlines -0.025 to -0.05em; tiny uppercase labels +0.12 to +0.18em.

**Why it feels premium:**
- one black pill, and a floating nav made of three separate pieces;
- the product rendered pixel-perfect as the hero;
- a scroll story in which the Finder window changes state (selection, then context menu, then Get Info: "Zero bytes on disk");
- two-tone headlines;
- a single ornament family: a stippled wave of blue and terracotta dots, and a dot-matrix wordmark in the footer;
- lots of content, very little chrome.

**Don't copy:** its wording, logo, product name, Finder content or images. The design is copied; the content is always the owner's own product.

### reframedclothing.com (website; the clothing-brand blueprint)

Captured and measured 2026-10-11 at 1440 and 390 px. The owner: "very, very professional; copy it, the animations and everything" for any clothing brand site. The blueprint is `fashion.md`: a white page, ink type, gray product grounds, one black block, a smart-hiding glass header, dark frosted menu drawer, quick-add cards and a black add-to-cart bar. Black and white only, blurred see-through glass, not Liquid Glass.

Never copy: its logo, name, photos, product names, copy or paid display font.

### "Agentic calendar AI experience" by Gleb Kuznetsov (Dribbble shot 26722657; feeds Atmos Glass)

**What it shows:**
- two phones, day and night;
- frosted white sheets stacked with depth over a single-hue atmosphere (steel blue for day; midnight into periwinkle for night) that falls into fog-white;
- a two-tone header, "Today" over "Wed, Aug 4";
- a focus card with a big medium-weight title, a short body, a black pill "Start task" with an icon, and "2h" meta;
- a week strip in which the selected day is a raised glass capsule;
- a tiny floating prompt capsule at the bottom;
- a thin progress ring on the night variant.

**Why it feels premium:** restraint (monochrome plus one hue), layering instead of borders, generous radii, and a black CTA against soft glass.

**Don't copy:** the layout one-to-one, or its text.

## Known favorites from past projects

- **Opal:** "one of, if not the best, app I've ever seen". The model for spacing, type sizes, glass and paywall polish. Not a model for its onboarding length, its dark backgrounds or its 3D gem, cave and stars art. Never use its words, its gem, cave or stars art, or its names.
- **Tide Guide:** the onboarding and paywall structure.
- **Revolut, Cal AI, Apple Fitness, Withings, Airbnb, Flow:** calm, premium, information-rich layouts.

## Pending

The owner is sending two iOS apps they like for their design. They don't apply to everything; use them when the subject fits. For each one, add:
- where its screenshots are saved;
- what makes it premium;
- which theme it feeds, or a new theme for `themes.md`;
- what never to copy.
